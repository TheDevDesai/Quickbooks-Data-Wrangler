/**
 * Writes a flattened table to a sheet tab, replacing what was there.
 */

var NUMBER_FORMATS_ = {
  text: '@',
  number: '#,##0.00;(#,##0.00);-',
  date: 'yyyy-mm-dd',
  rate: '0.0000##'
};
var WRITE_CHUNK_ROWS_ = 5000;

/**
 * @param {string} sheetName Destination tab (created if missing, otherwise overwritten).
 * @param {Object} result {header, rows, types, rowKinds?, title?}
 * @param {Object} opts {titled: show title lines and bold header/total rows, note, filter: add a filter to the table}
 * @return {number} Number of data rows written.
 */
function writeResult_(sheetName, result, opts) {
  opts = opts || {};
  var ss = SpreadsheetApp.getActive();
  var tz = ss.getSpreadsheetTimeZone();
  var isReport = !!opts.titled;
  var titleRows = isReport && result.title ? result.title.length + 1 : 0;
  var width = Math.max(1, result.header.length);
  var height = titleRows + 1 + result.rows.length;

  if (width * height > QBW.MAX_CELLS_PER_PULL) {
    throw new Error('This pull returned ' + result.rows.length + ' rows x ' + width +
      ' columns, which is too large for one tab. Narrow the date range or add filters.');
  }

  var sheet = ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);
  if (sheet.getFilter()) sheet.getFilter().remove();
  sheet.clear();
  sheet.clearNotes();
  sheet.setFrozenRows(0);
  ensureSize_(sheet, height, width);

  var row = 1;
  if (titleRows) {
    var titleValues = result.title.map(function (t) { return padRow_([t], width); });
    sheet.getRange(1, 1, titleValues.length, width).setValues(titleValues);
    sheet.getRange(1, 1).setFontWeight('bold').setFontSize(12);
    row = titleRows + 1;
  }

  var headerRow = row;
  // Text format before values, so labels like "Sep 2026" aren't turned into dates.
  sheet.getRange(headerRow, 1, 1, width).setNumberFormat('@').setValues([padRow_(result.header, width)])
    .setFontWeight('bold').setBackground('#f1f3f4');
  if (opts.note) sheet.getRange(headerRow, 1).setNote(opts.note);
  row++;

  var n = result.rows.length;
  if (n) {
    // Formats go on before values so text columns (doc numbers, ids) keep leading zeros.
    result.types.forEach(function (type, c) {
      sheet.getRange(row, c + 1, n, 1).setNumberFormat(NUMBER_FORMATS_[type] || '@');
    });
    for (var i = 0; i < n; i += WRITE_CHUNK_ROWS_) {
      var chunk = result.rows.slice(i, i + WRITE_CHUNK_ROWS_).map(function (r) {
        return toSheetRow_(r, result.types, width, tz);
      });
      sheet.getRange(row + i, 1, chunk.length, width).setValues(chunk);
    }
  }

  if (isReport && result.rowKinds) styleReportRows_(sheet, row, width, result.rowKinds);
  sheet.setFrozenRows(headerRow);
  if (opts.filter && n) sheet.getRange(headerRow, 1, n + 1, width).createFilter();
  if (width <= 30 && n <= 20000) sheet.autoResizeColumns(1, width);
  return n;
}

function ensureSize_(sheet, rows, cols) {
  if (sheet.getMaxRows() < rows) sheet.insertRowsAfter(sheet.getMaxRows(), rows - sheet.getMaxRows());
  if (sheet.getMaxColumns() < cols) sheet.insertColumnsAfter(sheet.getMaxColumns(), cols - sheet.getMaxColumns());
}

function padRow_(row, width) {
  var out = row.slice(0, width);
  while (out.length < width) out.push('');
  return out;
}

function toSheetRow_(row, types, width, tz) {
  var out = padRow_(row, width);
  for (var c = 0; c < out.length; c++) {
    var v = out[c];
    if (types[c] === 'date' && typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) {
      out[c] = Utilities.parseDate(v, tz, 'yyyy-MM-dd');
    } else if (v === null || v === undefined) {
      out[c] = '';
    }
  }
  return out;
}

function styleReportRows_(sheet, firstRow, width, rowKinds) {
  var bold = [], totals = [];
  rowKinds.forEach(function (kind, i) {
    if (kind === 'header' || kind === 'summary' || kind === 'subtotal') bold.push(i);
    if (kind === 'summary') totals.push(i);
  });
  function a1(i) { return sheet.getRange(firstRow + i, 1, 1, width).getA1Notation(); }
  if (bold.length) sheet.getRangeList(bold.map(a1)).setFontWeight('bold');
  if (totals.length) {
    sheet.getRangeList(totals.map(a1)).setBorder(true, null, null, null, null, null, '#5f6368', SpreadsheetApp.BorderStyle.SOLID);
  }
}
