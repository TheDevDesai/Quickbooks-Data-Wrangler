/**
 * Prepaid roll forward by vendor: opening balance + additions - amortization
 * = ending balance, per period, for prepaid asset accounts (e.g. 1310
 * Prepaid – Service Subscriptions, 1320 Prepaid – Annual Executive Summit).
 *
 * Additions are debits to the prepaid account (usually the vendor's bill,
 * which carries its Name); amortization is credits (journal entries whose
 * vendor is recovered from the memo by VendorResolver). The opening balance
 * per vendor sums every earlier line on those accounts. The total ending
 * balance is checked against the Trial Balance.
 *
 * Only prepaid-account lines are used, so this never overlaps with the GL
 * actuals view, which only reads expense accounts.
 */

var PREPAID_HISTORY_START_ = '2000-01-01';

/** Prepaid accounts: the ones picked, else asset accounts with "prepaid" in the name. */
function prepaidScope_(allAccounts, selected) {
  return allAccounts.filter(function (a) {
    if (selected && selected.length) return selected.indexOf(String(a.Id)) !== -1;
    return a.Classification === 'Asset' && /prepaid/i.test(a.FullyQualifiedName || a.Name || '');
  });
}

/** Sums resolved lines into {vendor: {inc, dec}} (debits add, credits amortize). */
function prepaidActivity_(lines) {
  var act = {};
  lines.forEach(function (l) {
    var v = l.vendor || l.name || UNRESOLVED_JE_;
    var a = act[v] || (act[v] = { inc: 0, dec: 0 });
    a.inc += l.debit;
    a.dec += l.credit;
  });
  return act;
}

function buildPrepaidRollForward_(pull, range, conn) {
  var realmId = pull.realmId;
  var fsm = conn.fiscalStartMonth || 1;
  var periods = buildPeriods_(range.start, range.end, pull.period || 'Month', fsm);
  var method = pull.accountingMethod || 'Accrual';
  var dayBefore = addDays_(range.start, -1);
  var all = qboQueryAll_(realmId, 'Account', 'SELECT * FROM Account WHERE Active IN (true, false)');
  var scope = prepaidScope_(all, pull.filters && pull.filters.account);
  if (!scope.length) {
    throw new Error('No prepaid accounts found. Pick them under More options → Accounts (e.g. 1310 and 1320).');
  }
  var ids = scope.map(function (a) { return String(a.Id); });
  var columns = 'tx_date,txn_type,doc_num,name,memo,' +
    (companyUsesMultiCurrency_(realmId) ? 'debt_home_amt,credit_home_amt' : 'debt_amt,credit_amt');
  var ctx = loadVendorContext_(realmId);
  var fetch = function (start, end) {
    var lines = fetchGeneralLedgerLines_(realmId,
      { start_date: start, end_date: end, columns: columns, accounting_method: method }, ids, all);
    lines.forEach(function (l) {
      var r = resolveVendor_(l, ctx);
      l.vendor = r.vendor;
      l.vendorSource = r.source;
    });
    return lines;
  };

  var history = prepaidActivity_(fetch(PREPAID_HISTORY_START_, dayBefore));
  var beginning = {};
  Object.keys(history).forEach(function (v) { beginning[v] = ROUND_(history[v].inc - history[v].dec); });
  periods.forEach(function (p) { p.activity = prepaidActivity_(fetch(p.start, p.end)); });

  var entities = {};
  var addVendor = function (v) { if (!entities[v]) entities[v] = { cols: [v], sort: (v.charAt(0) === '(' || v.indexOf('Unresolved') === 0 ? '~' : '') + v.toLowerCase() }; };
  Object.keys(beginning).forEach(addVendor);
  periods.forEach(function (p) { Object.keys(p.activity).forEach(addVendor); });
  var results = computeRollForward_({ entities: entities, beginning: beginning, periods: periods, closeYears: false });

  // Total ending balance vs the Trial Balance for the same accounts.
  var tb = parseTrialBalance_(qboReport_(realmId, 'TrialBalance', {
    start_date: fiscalYearStart_(range.end, fsm), end_date: range.end, accounting_method: method
  }), function () { return ''; });
  var tbTotal = ROUND_(ids.reduce(function (s, id) { return s + (tb[id] || 0); }, 0));
  var ours = ROUND_(Object.keys(results).reduce(function (s, v) { var r = results[v]; return s + r[r.length - 1].ending; }, 0));

  var result = layoutRollForward_({
    dimension: 'prepaid', layout: pull.layout, entityHeader: ['Vendor'], entities: entities,
    results: results, periods: periods, includeZero: !!pull.includeZero,
    title: ['Prepaid Roll Forward by Vendor', conn.companyName, range.start + ' to ' + range.end,
      method + ' basis - accounts: ' + scope.map(accountLabel_).join(', ')]
  });
  result.warning = Math.abs(ours - tbTotal) >= 0.01
    ? 'Total ending prepaid balance ' + ours.toFixed(2) + ' differs from the Trial Balance ' + tbTotal.toFixed(2) + '.'
    : '';
  return result;
}
