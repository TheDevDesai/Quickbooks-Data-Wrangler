/**
 * Resolves a vendor for every GL line, including journal-entry lines where
 * QuickBooks leaves Name blank (prepaid amortization, reclasses, payroll).
 *
 * Order, first match wins:
 *   a. Name on the line                         -> "QBO Name"
 *   b. Memo matches an alias in "Vendor Aliases" -> "Memo – alias"
 *   c. Memo parsed with the amortization/reclass
 *      patterns (or a vendor-only first line),
 *      fuzzy-matched to the QuickBooks vendors   -> "Memo – parsed"
 *   d. Rule for entries that aren't vendor spend
 *      (Rippling and other payroll, AES/ACS
 *      events, commissions, amortization of
 *      intangibles, write-offs, bank charges,
 *      reimbursements)                           -> "Rule"
 *   e. A QuickBooks vendor named anywhere in the
 *      memo ("accrue ... Kessler Brandt")       -> "Memo – parsed"
 *   f. Accrual / reversal / reclass with no
 *      vendor named                              -> "Rule"
 *   g. Parsed text that matches no vendor        -> "Memo – parsed (not in vendor list)"
 *   h. Nothing                                  -> "Unresolved JE" / "Unresolved"
 *
 * Alias and parsed names are mapped onto the exact QuickBooks vendor name when
 * one matches, so a vendor's named bills and its amortization JEs land on one row.
 */

var VENDOR_SOURCE = {
  NAME: 'QBO Name',
  ALIAS: 'Memo – alias',
  PARSED: 'Memo – parsed',
  PARSED_UNMATCHED: 'Memo – parsed (not in vendor list)',
  RULE: 'Rule',
  NONE: 'Unresolved'
};
var UNRESOLVED_JE_ = 'Unresolved JE';
var UNRESOLVED_ = 'Unresolved';
var FUZZY_THRESHOLD_ = 0.8;
var MONTH_WORD_RE_ = /^(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?(\s*[-'’]?\s*\d{2,4})?$/i;

// Words that don't identify a vendor: legal suffixes and QuickBooks' "(V)" marker.
var VENDOR_NOISE_WORDS_ = {
  inc: 1, incorporated: 1, llc: 1, llp: 1, lp: 1, pllc: 1, pc: 1, ltd: 1, limited: 1, corp: 1, corporation: 1, co: 1, company: 1,
  plc: 1, gmbh: 1, pte: 1, pvt: 1, private: 1, sa: 1, ag: 1, bv: 1, the: 1, v: 1
};

/** Lower-case words only: "LinkedIn Corp. (V)" -> "linkedin corp v". */
function looseText_(s) {
  return String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim();
}

/** Vendor key without legal suffixes: "Signalwise Insights Inc." -> "signalwise insights". */
function normalizeVendor_(s) {
  var words = looseText_(s).split(' ').filter(Boolean);
  var kept = words.filter(function (w) { return !VENDOR_NOISE_WORDS_[w]; });
  return (kept.length ? kept : words).join(' ');
}

function bigrams_(s) {
  var out = [];
  for (var i = 0; i < s.length - 1; i++) out.push(s.substr(i, 2));
  return out;
}

/** Dice similarity of letter pairs, 0..1. */
function diceScore_(a, b) {
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  var pa = bigrams_(a), pb = bigrams_(b), counts = {}, hits = 0;
  pa.forEach(function (g) { counts[g] = (counts[g] || 0) + 1; });
  pb.forEach(function (g) { if (counts[g]) { counts[g]--; hits++; } });
  return (2 * hits) / (pa.length + pb.length);
}

/** Prepares the QuickBooks vendor list for matching. */
function buildVendorIndex_(names) {
  var seen = {};
  return (names || []).filter(function (n) {
    if (!n || seen[n]) return false;
    seen[n] = true;
    return true;
  }).map(function (n) {
    var norm = normalizeVendor_(n);
    return { name: n, norm: norm, compact: norm.replace(/ /g, '') };
  });
}

/**
 * Best QuickBooks vendor for some text, or '' below the threshold.
 * Exact key match scores 1; the text being the leading words of a vendor
 * ("datacrate" -> "DataCrate Technologies LLC") scores 0.9; otherwise letter-pair similarity.
 */
function fuzzyMatchVendor_(text, index) {
  var norm = normalizeVendor_(text);
  if (!norm) return '';
  var compact = norm.replace(/ /g, '');
  var best = '', bestScore = 0, bestLen = 0;
  (index || []).forEach(function (v) {
    var score;
    if (v.norm === norm) score = 1;
    else if (compact.length >= 5 && (v.norm.indexOf(norm + ' ') === 0 || norm.indexOf(v.norm + ' ') === 0)) score = 0.9;
    else score = diceScore_(compact, v.compact);
    if (score > bestScore || (score === bestScore && score > 0 && v.name.length < bestLen)) {
      best = v.name; bestScore = score; bestLen = v.name.length;
    }
  });
  return bestScore >= FUZZY_THRESHOLD_ ? best : '';
}

/**
 * Alias rows from the "Vendor Aliases" tab: [alias, vendor, notes]. An alias
 * matches whole words in the memo, ignoring case and punctuation; wrap it in
 * slashes (/hub ?spot/) to use a regular expression. Longer aliases win.
 */
function parseAliasRows_(rows) {
  var out = [];
  (rows || []).forEach(function (r) {
    var pattern = String(r[0] || '').trim(), vendor = String(r[1] || '').trim();
    if (!pattern || !vendor) return;
    var m = /^\/(.+)\/([gimsuy]*)$/.exec(pattern);
    if (m) {
      try { out.push({ re: new RegExp(m[1], m[2].indexOf('i') === -1 ? m[2] + 'i' : m[2]), vendor: vendor, weight: pattern.length }); } catch (e) { /* bad regex: skip */ }
      return;
    }
    var key = looseText_(pattern);
    if (key) out.push({ key: key, vendor: vendor, weight: key.length });
  });
  return out.sort(function (a, b) { return b.weight - a.weight; });
}

/** Vendor names long or specific enough to look for anywhere in a memo, longest first. */
function buildMentionIndex_(vendorIndex) {
  return (vendorIndex || [])
    .filter(function (v) { return v.norm.length >= 6 || v.norm.indexOf(' ') !== -1; })
    .map(function (v) { return { name: v.name, key: v.norm }; })
    .sort(function (a, b) { return b.key.length - a.key.length; });
}

function findVendorMention_(mentions, memo) {
  var text = ' ' + looseText_(memo) + ' ';
  for (var i = 0; i < (mentions || []).length; i++) {
    if (text.indexOf(' ' + mentions[i].key + ' ') !== -1) return mentions[i].name;
  }
  return '';
}

/**
 * "Report vendor under GL account" overrides from the aliases tab, keyed by
 * vendor (exact QuickBooks name when one matches): {normalized vendor: account text}.
 */
function buildVendorOverrides_(rows, vendorIndex) {
  var out = {};
  (rows || []).forEach(function (r) {
    var vendor = String(r[1] || '').trim(), account = String(r[2] || '').trim();
    if (!vendor || !account) return;
    out[normalizeVendor_(exactVendor_(vendor, vendorIndex) || vendor)] = account;
  });
  return out;
}

function vendorAccountOverride_(ctx, vendor) {
  return (ctx.overrides || {})[normalizeVendor_(vendor)] || '';
}

/** The QuickBooks vendor whose name is the same apart from case, punctuation and legal suffixes. */
function exactVendor_(text, index) {
  var norm = normalizeVendor_(text);
  for (var i = 0; i < (index || []).length; i++) if (index[i].norm === norm) return index[i].name;
  return '';
}

/**
 * The account an override names: "7260", "7260 Finance Contractors", or the
 * account's name. Returns the QuickBooks Account or null.
 */
function findAccountByText_(accounts, text) {
  var t = String(text || '').trim();
  var num = (/^(\d{3,})\b/.exec(t) || [])[1];
  var lower = looseText_(t);
  for (var i = 0; i < accounts.length; i++) {
    var a = accounts[i];
    if (num && String(a.AcctNum || '') === num) return a;
  }
  for (var j = 0; j < accounts.length; j++) {
    var b = accounts[j];
    var names = [b.Name, b.FullyQualifiedName, b.AcctNum && b.AcctNum + ' ' + b.Name].filter(Boolean).map(looseText_);
    if (names.indexOf(lower) !== -1) return b;
  }
  return null;
}

function matchAlias_(aliases, memo) {
  var text = ' ' + looseText_(memo) + ' ';
  for (var i = 0; i < aliases.length; i++) {
    var a = aliases[i];
    if (a.re ? a.re.test(memo) : text.indexOf(' ' + a.key + ' ') !== -1) return a.vendor;
  }
  return '';
}

var MEMO_PATTERNS_ = [
  // "Amortisation for HubSpot for Jan 26", "Amortization of Signalwise Insights Inc. for Feb 26"
  /amorti[sz]ation\s+(?:for|of)\s+(.+?)\s+for\s+(?:the\s+month\s+of\s+)?[a-z]{3,9}\.?[\s\-'’]*\d{2,4}\s*$/i,
  // "Hubspot - Amortization for April 2026", "DataCrate Technologies LLC-Amortization ..."
  /^(.+?)\s*[-–—:]\s*amorti[sz]ation\b/i,
  // "[Jun 2026] 06/12/2026 Expense DeviceDesk Software" (card / bank line reclassed by JE)
  /^\[[^\]]*\]\s*(?:\d{1,2}\/\d{1,2}\/\d{2,4}\s+)?(?:expense|bill|purchase|check|credit card(?: charge)?)\s+(.+)$/i,
  // "[Jan to Jun 2026] Google Ad Charges"
  /^\[[^\]]*\]\s*(.+?)\s+(?:charges?|transactions?|fees?|expenses?|invoices?|subscriptions?)\b/i,
  // "July - Google Ads transaction reclass"
  /^[a-z]+\.?\s*[-–—]\s*(.+?)\s+(?:transactions?\s+)?re-?class/i,
  // "Amortization for Figma" (no period at the end)
  /amorti[sz]ation\s+(?:for|of)\s+(.+?)(?:\s+for\b|\s*$)/i
];

/** Text that can't be a vendor: dates, months, bare numbers. */
function isNotVendorText_(text) {
  return !/[a-z]{2}/i.test(text) || MONTH_WORD_RE_.test(text) || /^(the\s+)?month\b/i.test(text) ||
    /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(text);
}

/** The vendor-looking text in a memo, or ''. Multi-line memos are read as one line. */
function parseMemoVendor_(memo) {
  var s = String(memo || '').replace(/\s*[\r\n]+\s*/g, ' ').trim();
  for (var i = 0; i < MEMO_PATTERNS_.length; i++) {
    var m = MEMO_PATTERNS_[i].exec(s);
    if (!m) continue;
    var text = m[1].replace(/\(\s*v\s*\)/ig, ' ').replace(/[\s\-–—:,.]+$/, '').replace(/\s+/g, ' ').trim();
    if (text && !isNotVendorText_(text)) return text;
  }
  return '';
}

/** In "Vendor name<newline>Amortisation for Aug" the first line is the vendor. */
function firstLineVendor_(memo, vendors) {
  var parts = String(memo || '').split(/[\r\n]+/);
  if (parts.length < 2) return '';
  var first = parts[0].replace(/[\s\-–—:,]+$/, '').trim();
  return first && !isNotVendorText_(first) ? fuzzyMatchVendor_(first, vendors) : '';
}

var MONTHS_SHORT_ = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "Mar-26" from text like "March 2026" / "Mar 26", else from the line date. */
function monthTag_(memo, date) {
  var m = /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-'’]*(\d{4}|\d{2})\b/i.exec(memo || '');
  if (m) {
    var mon = MONTHS_SHORT_[['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(m[1].toLowerCase())];
    return mon + '-' + m[2].slice(-2);
  }
  var d = /^(\d{4})-(\d{2})/.exec(date || '');
  return d ? MONTHS_SHORT_[+d[2] - 1] + '-' + d[1].slice(-2) : '';
}

/** Tags for entries that aren't vendor spend. Checked before looking for vendor names in the memo. */
function ruleTag_(memo, date) {
  var s = String(memo || '');
  if (/rippling/i.test(s)) return 'Rippling (payroll)';
  var ev = /\b(AES|ACS)\b/.exec(s);
  if (ev) {
    var tag = monthTag_(s, date);
    return 'Event – ' + ev[1] + (tag ? ' ' + tag : '');
  }
  if (/_sum of\b|\bpayroll\b|\bsalar(y|ies)\b|\bwages\b|\bPTO\b|\bbonus\b|employer tax|(^|[^a-z])er tax|\bdeductions?\b/i.test(s)) return 'Payroll';
  if (/commission/i.test(s)) return 'Commissions (deferred / amortized)';
  if (/\bintangible|\bdepreciation\b|^dep\b|capitali[sz]ed software/i.test(s)) return 'Amortization / depreciation';
  if (/write[\s-]?off|\bbad debt\b/i.test(s)) return 'Bad debt / write-off';
  if (/sender charges|\bwire (fee|charge)|\bbank (fee|charge)/i.test(s)) return 'Bank charges';
  if (/reimbur/i.test(s)) return 'Employee reimbursements';
  if (/\brent\b/i.test(s)) return 'Rent';
  return '';
}

/** Last resort for lines with nothing useful in the memo: what the account itself says. */
function accountTag_(accountName, txnType) {
  var s = String(accountName || '');
  if (/bad debt/i.test(s)) return 'Bad debt / write-off';
  if (/depreciation|amorti[sz]ation/i.test(s)) return 'Amortization / depreciation';
  // Card charges with no payee on meals / travel accounts are reimbursed business development dinners.
  if (txnType !== 'Journal Entry' && /meal|travel|entertainment/i.test(s)) return 'Hosted BD dinners & travel (reimbursed)';
  return '';
}

/** Generic adjustments, used only when the memo names no vendor. */
function weakRuleTag_(memo) {
  var s = String(memo || '');
  if (/\b(accru\w*|revers\w*)\b/i.test(s)) return 'Accrual / reversal';
  if (/\bre-?class/i.test(s)) return 'Reclass (JE)';
  return '';
}

/**
 * @param {Object} line GL line {name, memo, txnType, date}
 * @param {Object} ctx {aliases: parseAliasRows_(), vendors: buildVendorIndex_(), mentions: buildMentionIndex_()}
 * @return {{vendor: string, source: string, parsed: string}}
 */
function resolveVendor_(line, ctx) {
  if (line.name) return { vendor: line.name, source: VENDOR_SOURCE.NAME, parsed: '' };
  var memo = line.memo || '';
  var alias = memo && matchAlias_(ctx.aliases || [], memo);
  // An alias names its vendor on purpose ("GlobalPay (intercompany)"), so only an exact name match is swapped in.
  if (alias) return { vendor: exactVendor_(alias, ctx.vendors) || alias, source: VENDOR_SOURCE.ALIAS, parsed: '' };
  var parsed = memo ? parseMemoVendor_(memo) : '';
  var matched = (parsed && fuzzyMatchVendor_(parsed, ctx.vendors)) || firstLineVendor_(memo, ctx.vendors);
  if (matched) return { vendor: matched, source: VENDOR_SOURCE.PARSED, parsed: parsed };
  var rule = memo && ruleTag_(memo, line.date);
  if (rule) return { vendor: rule, source: VENDOR_SOURCE.RULE, parsed: parsed };
  var mentioned = memo && findVendorMention_(ctx.mentions || buildMentionIndex_(ctx.vendors), memo);
  if (mentioned) return { vendor: mentioned, source: VENDOR_SOURCE.PARSED, parsed: parsed };
  var weak = memo && weakRuleTag_(memo);
  if (weak) return { vendor: weak, source: VENDOR_SOURCE.RULE, parsed: parsed };
  if (parsed) return { vendor: parsed, source: VENDOR_SOURCE.PARSED_UNMATCHED, parsed: parsed };
  var byAccount = accountTag_(line.accountName, line.txnType);
  if (byAccount) return { vendor: byAccount, source: VENDOR_SOURCE.RULE, parsed: '' };
  return { vendor: line.txnType === 'Journal Entry' ? UNRESOLVED_JE_ : UNRESOLVED_, source: VENDOR_SOURCE.NONE, parsed: '' };
}

/** Lines whose vendor needs a person's attention. */
function isVendorException_(source) {
  return source === VENDOR_SOURCE.NONE || source === VENDOR_SOURCE.PARSED_UNMATCHED;
}

// ---------------------------------------------------------------------------
// Spreadsheet and QuickBooks
// ---------------------------------------------------------------------------

var ALIASES_TAB_ = 'Vendor Aliases';
var ALIASES_HEADER_ = ['Alias (text in memo)', 'Vendor', 'Report vendor under GL account (optional)', 'Notes'];
// Starting aliases (illustrative examples only; replace them with your own in the tab).
var DEFAULT_VENDOR_ALIASES_ = [
  ['HubSpot', 'HubSpot, Inc.'], ['Google Ad', 'Google Ads'], ['Google Ads', 'Google Ads'],
  ['LinkedIn', 'LinkedIn Corporation'], ['Slack', 'Slack Technologies'],
  // A plain alias, a /regex/ alias that tolerates misspellings, and an alias that keeps its own label.
  ['Hartwell', 'Hartwell & Lowe LLP'], ['/qu[iy]ll[oa]n tech/', 'Quillon Tech'], ['GlobalPay', 'GlobalPay (intercompany)'],
  // Aliases with an account override: all of that vendor's spend is reported under the account named.
  ['Jordan Rivera', 'Jordan A Rivera', '7260 Finance Contractors'],
  ['LASI', 'Ledger Assist Services Inc.', '7420 Audit/Accounting'],
  // Miscoded event ticket (should have been event revenue); the JE and its reversal net to 0.
  ['/event ticket accid/', 'Event revenue (miscoded)'],
  // Wires back from a contractor's bank quoting their invoice numbers: reversals of their payments.
  ['/first example bank.*inv(oice)?\\s*0*\\d/', 'Casey Lin']
];

/** Reads the aliases tab, creating it with starting aliases the first time. */
function readVendorAliases_() {
  var ss = SpreadsheetApp.getActive();
  var sheet = ss.getSheetByName(ALIASES_TAB_);
  if (!sheet) {
    sheet = ss.insertSheet(ALIASES_TAB_);
    sheet.getRange(1, 1).setValue('Vendor aliases: when a line has no Name, a memo containing the alias is credited to the vendor. ' +
      'Matching ignores case and punctuation; wrap an alias in /slashes/ for a regular expression. ' +
      'Fill in the GL account column to report all of a vendor\'s spend under that account.').setFontStyle('italic');
    sheet.getRange(2, 1, 1, 4).setValues([ALIASES_HEADER_]).setFontWeight('bold').setBackground('#f1f3f4');
    sheet.getRange(3, 1, DEFAULT_VENDOR_ALIASES_.length, 4).setNumberFormat('@')
      .setValues(DEFAULT_VENDOR_ALIASES_.map(function (r) { return [r[0], r[1], r[2] || '', '']; }));
    sheet.setFrozenRows(2);
  } else if (String(sheet.getRange(2, 3).getValue()).indexOf('Notes') === 0) {
    // Tab from the first version (Alias, Vendor, Notes): add the account column before Notes.
    sheet.insertColumnBefore(3);
    sheet.getRange(2, 3).setValue(ALIASES_HEADER_[2]).setFontWeight('bold').setBackground('#f1f3f4');
  }
  var last = sheet.getLastRow();
  return last > 2 ? sheet.getRange(3, 1, last - 2, 4).getValues() : [];
}

/** Aliases plus the QuickBooks vendor list, ready for resolveVendor_. */
function loadVendorContext_(realmId) {
  var vendors = qboQueryAll_(realmId, 'Vendor', 'SELECT * FROM Vendor WHERE Active IN (true, false)')
    .map(function (v) { return v.DisplayName || v.CompanyName || ''; });
  var index = buildVendorIndex_(vendors);
  var rows = readVendorAliases_();
  return { aliases: parseAliasRows_(rows), vendors: index, mentions: buildMentionIndex_(index), overrides: buildVendorOverrides_(rows, index) };
}
