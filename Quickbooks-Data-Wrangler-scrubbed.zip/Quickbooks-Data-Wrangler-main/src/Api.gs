/**
 * QuickBooks Online Accounting API client with token refresh, retries
 * and query pagination.
 */

var RETRYABLE_STATUS_ = { 429: 1, 500: 1, 502: 1, 503: 1, 504: 1 };

function apiBase_(realmId) {
  var env = getConnection_(realmId).environment || 'production';
  return QBW.API_BASE[env] + '/v3/company/' + encodeURIComponent(realmId);
}

function toQueryString_(params) {
  return Object.keys(params)
    .filter(function (k) { return params[k] !== undefined && params[k] !== null && params[k] !== ''; })
    .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); })
    .join('&');
}

/** GET a QuickBooks API path (relative to /v3/company/{realmId}) and return parsed JSON. */
function qboGet_(realmId, path, params) {
  var query = toQueryString_(Object.assign({ minorversion: QBW.MINOR_VERSION }, params || {}));
  var url = apiBase_(realmId) + path + '?' + query;
  var refreshed = false;

  for (var attempt = 0; attempt < 5; attempt++) {
    var res = UrlFetchApp.fetch(url, {
      method: 'get',
      headers: {
        Authorization: 'Bearer ' + getAccessToken_(realmId, false),
        Accept: 'application/json'
      },
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    if (code === 401 && !refreshed) {
      getAccessToken_(realmId, true);
      refreshed = true;
      attempt--;
      continue;
    }
    if (RETRYABLE_STATUS_[code] && attempt < 4) {
      Utilities.sleep(Math.min(30000, 1000 * Math.pow(2, attempt)) + Math.floor(Math.random() * 500));
      continue;
    }
    var text = res.getContentText();
    var body;
    try { body = JSON.parse(text); } catch (e) { body = null; }
    if (code !== 200 || !body || body.Fault) {
      throw new Error('QuickBooks API error (' + code + '): ' + describeFault_(body, text));
    }
    return body;
  }
  throw new Error('QuickBooks API kept failing after several retries. Try again in a minute.');
}

function describeFault_(body, text) {
  var fault = body && (body.Fault || (body.fault));
  var errors = fault && (fault.Error || fault.error);
  if (errors && errors.length) {
    return errors.map(function (e) { return (e.Message || e.message || '') + (e.Detail || e.detail ? ' - ' + (e.Detail || e.detail) : ''); }).join('; ');
  }
  return String(text || '').slice(0, 300);
}

/** Runs a report. `params` are QuickBooks report query parameters. */
function qboReport_(realmId, reportName, params) {
  return qboGet_(realmId, '/reports/' + reportName, params);
}

/** Runs a query and follows pagination, returning every matching entity. */
function qboQueryAll_(realmId, entity, statement, maxRows) {
  var all = [];
  var start = 1;
  var size = QBW.QUERY_PAGE_SIZE;
  while (true) {
    var body = qboGet_(realmId, '/query', {
      query: statement + ' STARTPOSITION ' + start + ' MAXRESULTS ' + size
    });
    var page = (body.QueryResponse && body.QueryResponse[entity]) || [];
    Array.prototype.push.apply(all, page);
    if (page.length < size) break;
    if (maxRows && all.length >= maxRows) break;
    start += size;
  }
  return all;
}

/** Called from the sidebar: id/name pairs for filter pickers. */
function listDimension(realmId, entity) {
  var allowed = { Class: 1, Department: 1, Customer: 1, Vendor: 1, Account: 1, BankAccount: 1 };
  if (!allowed[entity]) throw new Error('Unsupported filter: ' + entity);
  var statement = entity === 'BankAccount'
    ? "SELECT * FROM Account WHERE AccountType IN ('Bank', 'Credit Card')"
    : 'SELECT * FROM ' + entity;
  return qboQueryAll_(realmId, entity === 'BankAccount' ? 'Account' : entity, statement, 20000)
    .map(function (r) {
      return { id: String(r.Id), name: r.FullyQualifiedName || r.DisplayName || r.Name || String(r.Id) };
    })
    .sort(function (a, b) { return a.name.localeCompare(b.name); });
}
