/**
 * Static configuration: Intuit endpoints and the catalog of reports and
 * entities the sidebar offers.
 */

var QBW = {
  // Name shown under Extensions. Use the same name for the Marketplace listing
  // (or the Apps Script project, for a spreadsheet-bound copy).
  ADDON_NAME: 'QuickBooks Data Wrangler',
  // Shown at the bottom of the panel, so anyone can tell which version a spreadsheet is running. Bump with each release.
  BUILD: '2026.10.29 · straight-line forecast',
  AUTH_URL: 'https://appcenter.intuit.com/connect/oauth2',
  TOKEN_URL: 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
  REVOKE_URL: 'https://developer.api.intuit.com/v2/oauth2/tokens/revoke',
  API_BASE: {
    production: 'https://quickbooks.api.intuit.com',
    sandbox: 'https://sandbox-quickbooks.api.intuit.com'
  },
  SCOPE: 'com.intuit.quickbooks.accounting',
  MINOR_VERSION: '75',
  QUERY_PAGE_SIZE: 1000,
  // Google Sheets hard limit is 10M cells per spreadsheet; stay well under it per tab.
  MAX_CELLS_PER_PULL: 5000000
};

/**
 * Reports available through the QuickBooks Reports API.
 * `params` lists which sidebar controls apply to the report.
 *   dateRange  -> start_date / end_date
 *   asOf       -> report_date (aging reports)
 *   method     -> accounting_method (Cash / Accrual)
 *   summarize  -> summarize_column_by (Month, Quarter, Class, ...)
 *   class, department, customer, vendor, account -> id filters
 *   columns    -> custom column list (detail reports)
 * `accountsInSheet` marks reports QuickBooks cannot filter by account; the
 * add-on filters their rows after fetching (see filterReportByAccounts).
 */
var REPORT_CATALOG = {
  ProfitAndLoss: {
    label: 'Profit and Loss',
    params: ['dateRange', 'method', 'summarize', 'class', 'department', 'customer', 'vendor', 'account'],
    accountsInSheet: true
  },
  ProfitAndLossDetail: {
    label: 'Profit and Loss Detail',
    params: ['dateRange', 'method', 'class', 'department', 'customer', 'vendor', 'account', 'columns']
  },
  BalanceSheet: {
    label: 'Balance Sheet',
    params: ['dateRange', 'method', 'summarize', 'class', 'department', 'customer', 'vendor', 'account'],
    accountsInSheet: true
  },
  TrialBalance: {
    label: 'Trial Balance',
    params: ['dateRange', 'method', 'summarize', 'account'],
    accountsInSheet: true
  },
  CashFlow: {
    label: 'Statement of Cash Flows',
    params: ['dateRange', 'summarize', 'class', 'department', 'customer', 'vendor']
  },
  GeneralLedger: {
    label: 'General Ledger',
    params: ['dateRange', 'method', 'class', 'department', 'customer', 'vendor', 'account', 'columns'],
    defaultColumns: 'tx_date,txn_type,doc_num,name,memo,split_acc,subt_nat_amount,rbal_nat_amount'
  },
  TransactionList: {
    label: 'Transaction List by Date',
    params: ['dateRange', 'method', 'class', 'department', 'customer', 'vendor', 'columns']
  },
  AgedReceivables: {
    label: 'A/R Aging Summary',
    params: ['asOf', 'customer']
  },
  AgedReceivableDetail: {
    label: 'A/R Aging Detail',
    params: ['asOf', 'customer', 'columns']
  },
  AgedPayables: {
    label: 'A/P Aging Summary',
    params: ['asOf', 'vendor']
  },
  AgedPayableDetail: {
    label: 'A/P Aging Detail',
    params: ['asOf', 'vendor', 'columns']
  },
  CustomerSales: {
    label: 'Sales by Customer',
    params: ['dateRange', 'method', 'summarize', 'class', 'department', 'customer']
  },
  ItemSales: {
    label: 'Sales by Product/Service',
    params: ['dateRange', 'method', 'summarize', 'class', 'department', 'customer']
  },
  VendorExpenses: {
    label: 'Expenses by Vendor',
    params: ['dateRange', 'method', 'summarize', 'class', 'department', 'vendor']
  }
};

/** Values QuickBooks accepts for summarize_column_by. */
var SUMMARIZE_OPTIONS = [
  'Total', 'Month', 'Quarter', 'Year', 'Week', 'Days',
  'Classes', 'Departments', 'Customers', 'Vendors', 'ProductsAndServices'
];

/**
 * Entities available through the QuickBooks query endpoint.
 * `dateField` is used for the date-range filter (omitted for list entities).
 */
var ENTITY_CATALOG = {
  Account: { label: 'Chart of Accounts' },
  Customer: { label: 'Customers' },
  Vendor: { label: 'Vendors' },
  Employee: { label: 'Employees' },
  Item: { label: 'Products & Services' },
  Class: { label: 'Classes' },
  Department: { label: 'Locations / Departments' },
  Term: { label: 'Terms' },
  Invoice: { label: 'Invoices', dateField: 'TxnDate', hasLines: true },
  SalesReceipt: { label: 'Sales Receipts', dateField: 'TxnDate', hasLines: true },
  CreditMemo: { label: 'Credit Memos', dateField: 'TxnDate', hasLines: true },
  Payment: { label: 'Customer Payments', dateField: 'TxnDate', hasLines: true },
  Estimate: { label: 'Estimates', dateField: 'TxnDate', hasLines: true },
  Bill: { label: 'Bills', dateField: 'TxnDate', hasLines: true },
  BillPayment: { label: 'Bill Payments', dateField: 'TxnDate', hasLines: true },
  VendorCredit: { label: 'Vendor Credits', dateField: 'TxnDate', hasLines: true },
  Purchase: { label: 'Expenses / Checks / Card Charges', dateField: 'TxnDate', hasLines: true },
  PurchaseOrder: { label: 'Purchase Orders', dateField: 'TxnDate', hasLines: true },
  JournalEntry: { label: 'Journal Entries', dateField: 'TxnDate', hasLines: true },
  Deposit: { label: 'Deposits', dateField: 'TxnDate', hasLines: true },
  Transfer: { label: 'Transfers', dateField: 'TxnDate' }
};

/** Relative date presets. Stored in saved pulls so refreshes roll forward. */
var DATE_PRESETS = {
  this_month: 'This month',
  this_month_to_date: 'This month to date',
  last_month: 'Last month',
  this_quarter: 'This quarter',
  this_quarter_to_date: 'This quarter to date',
  last_quarter: 'Last quarter',
  this_year: 'This calendar year',
  this_year_to_date: 'This calendar year to date',
  last_year: 'Last calendar year',
  this_fiscal_year: 'This fiscal year',
  this_fiscal_year_to_date: 'This fiscal year to date',
  last_fiscal_year: 'Last fiscal year',
  last_12_months: 'Last 12 full months',
  trailing_12_months: 'Trailing 12 months (incl. this month)',
  all_dates: 'All dates',
  custom: 'Custom'
};
