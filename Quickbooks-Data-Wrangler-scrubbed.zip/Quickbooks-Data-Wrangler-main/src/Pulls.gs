/**
 * Saved pulls ("synced tabs"): a definition of what to fetch from QuickBooks
 * and which tab to write it to. Nothing syncs on its own: a pull runs only
 * when someone clicks Sync, so numbers never change under a reader.
 * Pulls are stored in Document Properties so they travel with the
 * spreadsheet and can be synced by anyone connected to the same company.
 *
 * Pull shape:
 * {
 *   id, name, realmId, companyName,
 *   source: 'report' | 'rollforward' | 'entity',
 *   report, entity,
 *   rollforwardBy: 'account' | 'bank' | 'customer' | 'vendor', period: 'Month' | 'Quarter' | 'Year' | 'Total',
 *   includeZero, byVendor, excludeJournalEntries, alsoRealmIds (GL actuals: other companies to consolidate),
 *   excludeVendors (GL actuals: vendor names to leave out; a trailing * matches names starting with it),
 *   forecastBasis ('' | '1' | '3' | '6' | 'ytd'), forecastThrough ('' = last completed month | 'yyyy-mm') (GL actuals),
 *   dateRange: {preset, start, end},
 *   accountingMethod: '' | 'Accrual' | 'Cash',
 *   summarizeBy, columns, layout: 'report' | 'table' | 'long' (reports) | 'schedule' | 'long' (roll forwards) | 'detail' (GL actuals),
 *   filters: {class, department, customer, vendor, account, bankAccount: [ids]},
 *   where, expandLines, sheetName,
 *   lastRun, lastStatus, lastRows, lastRange, lastWarning
 * }
 */

var PULL_PREFIX_ = 'qbw.pull.';
var FILTER_PARAMS_ = { class: 'class', department: 'department', customer: 'customer', vendor: 'vendor', account: 'account', bankAccount: 'account' };

function docProps_() {
  return PropertiesService.getDocumentProperties();
}

/** Called from the sidebar. */
function listPulls() {
  var props = docProps_().getProperties();
  return Object.keys(props)
    .filter(function (k) { return k.indexOf(PULL_PREFIX_) === 0; })
    .map(function (k) { return JSON.parse(props[k]); })
    .sort(function (a, b) { return a.name.localeCompare(b.name); });
}

function getPull_(id) {
  var raw = docProps_().getProperty(PULL_PREFIX_ + id);
  if (!raw) throw new Error('Saved pull not found. It may have been deleted.');
  return JSON.parse(raw);
}

function storePull_(pull) {
  docProps_().setProperty(PULL_PREFIX_ + pull.id, JSON.stringify(pull));
}

/** Normalizes and validates a pull coming from the sidebar. Pure apart from catalog lookups. */
function normalizePull_(input) {
  var p = JSON.parse(JSON.stringify(input || {}));
  if (!p.realmId) throw new Error('Choose a QuickBooks company.');
  if (p.source === 'report') {
    if (!REPORT_CATALOG[p.report]) throw new Error('Choose a report.');
    p.entity = '';
    if (['report', 'table', 'long'].indexOf(p.layout) === -1) p.layout = 'report';
  } else if (p.source === 'rollforward') {
    if (!ROLLFORWARD_CATALOG[p.rollforwardBy]) throw new Error('Choose what to roll forward by.');
    p.report = '';
    p.entity = '';
    if (ROLLFORWARD_PERIODS.indexOf(p.period) === -1) p.period = 'Month';
    var layouts = p.rollforwardBy === 'actuals' ? ['schedule', 'long', 'detail'] : ['schedule', 'long'];
    if (layouts.indexOf(p.layout) === -1) p.layout = 'schedule';
    p.includeZero = !!p.includeZero;
    p.byVendor = p.byVendor !== false;
    p.excludeJournalEntries = !!p.excludeJournalEntries;
    // GL actuals can consolidate other connected companies into the same tab.
    p.alsoRealmIds = p.rollforwardBy !== 'actuals' ? [] : (p.alsoRealmIds || []).map(String)
      .filter(function (id, i, arr) { return id && id !== p.realmId && arr.indexOf(id) === i; });
    // Straight-line forecast after the actuals month (GL actuals, grouped or pivot-ready layouts).
    p.forecastBasis = p.rollforwardBy === 'actuals' && p.layout !== 'detail' && FORECAST_BASES_[p.forecastBasis] ? String(p.forecastBasis) : '';
    p.forecastThrough = p.forecastBasis && /^\d{4}-\d{2}$/.test(p.forecastThrough || '') ? p.forecastThrough : '';
    // Vendors to leave out of a GL actuals tab; kept short so the saved pull fits in a document property.
    var chars = 0;
    p.excludeVendors = p.rollforwardBy !== 'actuals' ? [] : (p.excludeVendors || [])
      .map(function (v) { return String(v || '').trim(); })
      .filter(function (v, i, arr) { return v && arr.indexOf(v) === i && (chars += v.length + 3) <= 4000; });
    // Only the filter that matches the dimension applies; balances would not tie with others.
    var keepFilter = ROLLFORWARD_CATALOG[p.rollforwardBy].filter;
    var kept = {};
    if (p.filters && p.filters[keepFilter]) kept[keepFilter] = p.filters[keepFilter];
    p.filters = kept;
    if (p.dateRange && p.dateRange.preset === 'all_dates') throw new Error('A roll forward needs a date range with a start date.');
  } else if (p.source === 'entity') {
    if (!ENTITY_CATALOG[p.entity]) throw new Error('Choose a data type.');
    p.report = '';
    p.layout = 'table';
  } else {
    throw new Error('Choose Report, Roll forward or Data list.');
  }
  p.dateRange = p.dateRange || { preset: 'this_month' };
  if (!DATE_PRESETS[p.dateRange.preset]) throw new Error('Choose a date range.');
  // Basis is always explicit where it applies, so a refresh never depends on company settings.
  var usesMethod = p.source === 'rollforward' ||
    (p.source === 'report' && REPORT_CATALOG[p.report].params.indexOf('method') !== -1);
  p.accountingMethod = !usesMethod ? '' : (p.accountingMethod === 'Cash' ? 'Cash' : 'Accrual');
  p.filters = p.filters || {};
  Object.keys(p.filters).forEach(function (k) {
    if (!FILTER_PARAMS_[k]) delete p.filters[k];
    else p.filters[k] = (p.filters[k] || []).map(String).filter(Boolean);
  });
  p.sheetName = String(p.sheetName || '').trim();
  if (!p.sheetName) throw new Error('Enter a destination tab name.');
  if (/[\[\]*?\/\\:]/.test(p.sheetName) || p.sheetName.length > 100) {
    throw new Error('Tab names cannot contain [ ] * ? / \\ : and must be under 100 characters.');
  }
  p.name = String(p.name || '').trim() || defaultPullName_(p);
  return p;
}

function defaultPullName_(p) {
  var what = p.source === 'report' ? REPORT_CATALOG[p.report].label
    : p.source === 'rollforward' ? (p.rollforwardBy === 'actuals' ? 'GL actuals by month'
      : p.rollforwardBy === 'prepaid' ? 'Prepaid by vendor' : 'Roll forward by ' + ROLLFORWARD_CATALOG[p.rollforwardBy].label)
      : ENTITY_CATALOG[p.entity].label;
  return what + ' - ' + DATE_PRESETS[p.dateRange.preset] + (p.accountingMethod ? ' (' + p.accountingMethod + ')' : '');
}

/** Builds QuickBooks report query parameters for a pull and a resolved date range. */
function buildReportParams_(pull, range, today) {
  var def = REPORT_CATALOG[pull.report];
  var has = {};
  def.params.forEach(function (k) { has[k] = true; });
  var params = {};
  if (has.dateRange) {
    params.start_date = range.start || '1900-01-01';
    params.end_date = range.end || today;
  }
  if (has.asOf) params.report_date = range.end || today;
  if (has.method && pull.accountingMethod) params.accounting_method = pull.accountingMethod;
  if (has.summarize && pull.summarizeBy) params.summarize_column_by = pull.summarizeBy;
  Object.keys(FILTER_PARAMS_).forEach(function (k) {
    var ids = pull.filters && pull.filters[k];
    if (k === 'account' && def.accountsInSheet) return; // applied after fetching
    if (has[k] && ids && ids.length) params[FILTER_PARAMS_[k]] = ids.join(',');
  });
  // Filters travel in the request URL, which Apps Script caps at about 2,000 characters.
  var filterChars = Object.keys(FILTER_PARAMS_).reduce(function (n, k) {
    var v = params[FILTER_PARAMS_[k]];
    return n + (v ? encodeURIComponent(v).length : 0);
  }, 0);
  if (filterChars > MAX_ACCOUNT_PARAM_CHARS_) {
    throw new Error('Too many items are ticked in the filters for this report. Tick fewer, or leave a list empty to include everything.' +
      (has.account ? ' For many accounts, GL actuals by month handles any number.' : ''));
  }
  if (has.columns) {
    var cols = String(pull.columns || def.defaultColumns || '').replace(/\s+/g, '');
    if (cols) params.columns = cols;
  }
  return params;
}

/**
 * Called from the sidebar: saves (creates or updates) a pull and runs it.
 * Returns the saved pull; a failed run comes back with lastStatus 'error'
 * rather than throwing, so the sidebar can keep editing the saved pull.
 */
function saveAndRunPull(input) {
  var pull = normalizePull_(input);
  if (pull.id) {
    var existing = getPull_(pull.id);
    ['lastRun', 'lastStatus', 'lastRows', 'lastRange', 'lastWarning'].forEach(function (k) { pull[k] = existing[k]; });
  } else {
    pull.id = Utilities.getUuid();
  }
  var clash = listPulls().filter(function (o) { return o.id !== pull.id && o.sheetName === pull.sheetName; })[0];
  if (clash) throw new Error('The tab "' + pull.sheetName + '" is already used by the pull "' + clash.name + '".');
  storePull_(pull);
  try {
    return runPull(pull.id);
  } catch (e) {
    return getPull_(pull.id);
  }
}

/** Called from the sidebar / menu: refreshes one saved pull. */
function runPull(id) {
  var pull = getPull_(id);
  try {
    var outcome = executePull_(pull);
    pull.lastStatus = 'ok';
    pull.lastRows = outcome.rows;
    pull.lastRange = outcome.range;
    pull.lastWarning = outcome.warning || '';
    pull.lastError = '';
  } catch (e) {
    pull.lastStatus = 'error';
    pull.lastError = e.message;
  }
  pull.lastRun = new Date().toISOString();
  storePull_(pull);
  if (pull.lastStatus === 'error') throw new Error(pull.name + ': ' + pull.lastError);
  return pull;
}

function executePull_(pull) {
  var ss = SpreadsheetApp.getActive();
  var tz = ss.getSpreadsheetTimeZone();
  var today = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
  var conn = getConnection_(pull.realmId);
  var range = resolveDateRange(pull.dateRange, today, conn.fiscalStartMonth);
  range.today = today;
  var rangeLabel = range.start || range.end ? (range.start || 'beginning') + ' to ' + (range.end || today) : 'All dates';
  var result;

  if (pull.source === 'report') {
    var params = buildReportParams_(pull, range, today);
    var report = qboReport_(pull.realmId, pull.report, params);
    var accountIds = REPORT_CATALOG[pull.report].accountsInSheet && pull.filters && pull.filters.account;
    if (accountIds && accountIds.length) report = filterReportByAccounts(report, accountIds);
    result = flattenReport(report, pull.layout, { companyName: conn.companyName });
    if (accountIds && accountIds.length) {
      result.title.push('Selected accounts only (' + accountIds.length + ' chosen, sub-accounts included)');
    }
    if (params.report_date) rangeLabel = 'As of ' + params.report_date;
  } else if (pull.source === 'rollforward') {
    result = buildRollForward_(pull, range, conn);
  } else {
    var statement = buildEntityQuery(pull.entity, { start: range.start, end: range.end, where: pull.where });
    var records = qboQueryAll_(pull.realmId, pull.entity, statement);
    result = flattenEntities(records, { expandLines: !!pull.expandLines });
    if (!ENTITY_CATALOG[pull.entity].dateField) rangeLabel = 'All records';
  }

  if (!result.header.length) result.header = ['No data returned for ' + rangeLabel];
  var note = 'QuickBooks Data Wrangler\n' + pull.name + '\n' + conn.companyName + '\n' + rangeLabel +
    (pull.accountingMethod ? '\n' + pull.accountingMethod + ' basis' : '') +
    '\nRefreshed ' + Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd HH:mm z');
  var titled = pull.layout === 'report' || (pull.source === 'rollforward' && pull.layout === 'schedule');
  var rows = writeResult_(pull.sheetName, result, { titled: titled, note: note, filter: pull.layout === 'detail' });
  return { rows: rows, range: rangeLabel, warning: result.warning || '' };
}

/** Called from the sidebar. */
function deletePull(id) {
  docProps_().deleteProperty(PULL_PREFIX_ + id);
  return listPulls();
}
