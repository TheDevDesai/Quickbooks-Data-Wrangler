/**
 * Consolidated GL actuals: one tab across several connected QuickBooks
 * companies (e.g. Sample Company Inc. + Sample Company Europe).
 *
 * - The pull's own company is the primary; its accounts, names and currency
 *   are what the tab shows.
 * - Other companies' accounts merge into the primary account with the same
 *   account number (6310 in Europe lands on 6310 in the US). Accounts
 *   with no match keep their own row.
 * - Amounts in another currency are converted line by line at the rate for
 *   the line's month from the "FX Rates" tab (reporting currency per 1 unit,
 *   e.g. 1.17 USD per EUR), which finance keeps in line with the
 *   consolidation's monthly average rates.
 * - Each company is tied out against its own QuickBooks P&L in its own
 *   currency, so a conversion never hides a pull difference.
 * - Intercompany charges are not eliminated: scope the tab to the accounts
 *   you need (e.g. Marketing) or leave intercompany accounts out.
 */

var FX_TAB_ = 'FX Rates';
var FX_MONTH_NAMES_ = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

/** 'yyyy-mm' for a month cell: a Date, "Jan 2026", "January 2026", "2026-01" or "1/2026". */
function fxMonthKey_(v) {
  if (Object.prototype.toString.call(v) === '[object Date]') return v.getFullYear() + '-' + ('0' + (v.getMonth() + 1)).slice(-2);
  var s = String(v === undefined || v === null ? '' : v).trim().toLowerCase();
  var m = s.match(/^(\d{4})-(\d{1,2})/);
  if (m) return m[1] + '-' + ('0' + m[2]).slice(-2);
  m = s.match(/^([a-z]{3})[a-z]*\.?[\s-]+(\d{4})$/);
  if (m && FX_MONTH_NAMES_.indexOf(m[1]) !== -1) return m[2] + '-' + ('0' + (FX_MONTH_NAMES_.indexOf(m[1]) + 1)).slice(-2);
  m = s.match(/^(\d{1,2})\/(\d{4})$/);
  if (m) return m[2] + '-' + ('0' + m[1]).slice(-2);
  return '';
}

/** Label for a 'yyyy-mm' key, e.g. "Jan 2026". */
function fxMonthLabel_(key) {
  var i = Number(key.slice(5, 7)) - 1;
  return FX_MONTH_NAMES_[i].charAt(0).toUpperCase() + FX_MONTH_NAMES_[i].slice(1) + ' ' + key.slice(0, 4);
}

/**
 * Reads an FX tab column header. "EUR" holds reporting currency per 1 EUR;
 * "PHP per USD" holds pesos per dollar (how central banks quote it) and is inverted.
 * @return {{code: string, invert: boolean}|null}
 */
function fxHeader_(h, reporting) {
  var s = String(h || '').trim().toUpperCase();
  if (/^[A-Z]{3}$/.test(s)) return { code: s, invert: false };
  var m = s.match(/^([A-Z]{3})\s*(?:PER|\/)\s*([A-Z]{3})$/);
  if (!m) return null;
  if (m[2] === reporting) return { code: m[1], invert: true };
  if (m[1] === reporting) return { code: m[2], invert: false };
  return null;
}

/**
 * Parses the FX tab: header row ['Month', 'EUR', 'PHP per USD', ...] then one row per month.
 * @return {Object} {EUR: {'2026-01': 1.17, ...}, ...} in reporting currency per 1 unit.
 */
function parseFxRows_(header, rows, reporting) {
  var table = {};
  var cols = (header || []).map(function (h) { return fxHeader_(h, reporting || 'USD'); });
  rows.forEach(function (r) {
    var key = fxMonthKey_(r[0]);
    if (!key) return;
    for (var c = 1; c < cols.length; c++) {
      var rate = Number(r[c]);
      if (!cols[c] || r[c] === '' || r[c] === null || !(rate > 0)) continue;
      (table[cols[c].code] || (table[cols[c].code] = {}))[key] = cols[c].invert ? 1 / rate : rate;
    }
  });
  return table;
}

/**
 * The rate for a currency and month; an empty month uses the latest earlier
 * month that has one (an open month before finance enters its rate).
 * @return {{rate: number, month: string}|null} month is where the rate came from.
 */
function fxRateFor_(table, currency, key) {
  var rates = table[currency] || {};
  if (rates[key]) return { rate: rates[key], month: key };
  var earlier = Object.keys(rates).filter(function (k) { return k < key; }).sort();
  return earlier.length ? { rate: rates[earlier[earlier.length - 1]], month: earlier[earlier.length - 1] } : null;
}

/** Months ('yyyy-mm') covered by a date range. */
function monthsBetween_(start, end) {
  var out = [];
  var y = Number(start.slice(0, 4)), m = Number(start.slice(5, 7));
  var last = end.slice(0, 7);
  for (var guard = 0; guard < 600; guard++) {
    var key = y + '-' + ('0' + m).slice(-2);
    if (key > last) break;
    out.push(key);
    if (++m > 12) { m = 1; y++; }
  }
  return out;
}

/**
 * Maps another company's accounts onto the primary company's.
 * @param {Object[]} primaryAll Every primary account.
 * @param {Object[]} otherAll Every account of the other company.
 * @param {string} realmId The other company (prefixes ids of unmatched accounts).
 * @return {Object} {otherId: merged account}; a matched account is the primary
 *     account itself, an unmatched one a copy whose Id is "<realmId>:<Id>".
 */
function mapAccountsToPrimary_(primaryAll, otherAll, realmId) {
  var byNumber = {};
  primaryAll.forEach(function (a) { if (a.AcctNum) byNumber[String(a.AcctNum)] = a; });
  var out = {};
  otherAll.forEach(function (a) {
    var match = a.AcctNum && byNumber[String(a.AcctNum)];
    if (match) { out[String(a.Id)] = match; return; }
    var copy = {};
    Object.keys(a).forEach(function (k) { copy[k] = a[k]; });
    copy.Id = realmId + ':' + a.Id;
    out[String(a.Id)] = copy;
  });
  return out;
}

/**
 * Accounts of another company in scope: the default scope (all expense
 * accounts), or the ones whose number (else name) matches a picked primary account.
 */
function otherCompanyScope_(otherAll, primaryAll, selected) {
  if (!selected || !selected.length) return otherAll.filter(function (a) { return a.Classification === 'Expense'; });
  var numbers = {}, names = {};
  primaryAll.forEach(function (a) {
    if (selected.indexOf(String(a.Id)) === -1) return;
    if (a.AcctNum) numbers[String(a.AcctNum)] = true;
    else names[String(a.Name || '').toLowerCase()] = true;
  });
  return otherAll.filter(function (a) {
    return a.AcctNum ? numbers[String(a.AcctNum)] : names[String(a.Name || '').toLowerCase()];
  });
}

/**
 * Converts lines to the reporting currency in place (keeping the local amounts)
 * and returns the months that borrowed an earlier month's rate.
 * Throws when a month has no rate at all.
 */
function convertLines_(periodLines, table, currency, reportingCurrency) {
  var borrowed = {};
  periodLines.forEach(function (lines) {
    lines.forEach(function (l) {
      var key = String(l.date || '').slice(0, 7);
      var fx = fxRateFor_(table, currency, key);
      if (!fx) {
        throw new Error('Enter the ' + currency + ' to ' + reportingCurrency + ' rate for ' + fxMonthLabel_(key) +
          ' in the "' + FX_TAB_ + '" tab (' + reportingCurrency + ' per 1 ' + currency + '), then sync again.');
      }
      if (fx.month !== key) borrowed[fxMonthLabel_(key)] = fxMonthLabel_(fx.month);
      l.localDebit = l.debit;
      l.localCredit = l.credit;
      l.fxRate = fx.rate;
      l.debit = ROUND_(l.debit * fx.rate);
      l.credit = ROUND_(l.credit * fx.rate);
    });
  });
  return borrowed;
}

/**
 * Combines per-company tie-outs (each in its own currency) into one table with
 * a Company column. periodDiff is converted to the reporting currency.
 * @param {Object[]} parts [{company, tieOut, rateOf: function(periodIndex): number}]
 */
function combineTieOuts_(parts) {
  var rows = [], totalAbs = 0, failures = [], periodDiff = null;
  parts.forEach(function (part) {
    var t = part.tieOut;
    t.rows.slice(0, -1).forEach(function (r) { rows.push([part.company].concat(r)); });
    totalAbs = ROUND_(totalAbs + t.totalAbsDiff);
    t.failures.forEach(function (f) { failures.push(part.company + ' ' + f); });
    if (!periodDiff) periodDiff = t.periodDiff.map(function () { return 0; });
    t.periodDiff.forEach(function (d, p) { periodDiff[p] = ROUND_(periodDiff[p] + d * part.rateOf(p)); });
  });
  rows.push(['Check: total of differences (should be 0)', '', '', '', '', totalAbs]);
  return {
    header: ['Company', 'GL Account', 'Period', 'QuickBooks P&L (company currency)', 'Resolved vendors total', 'Difference'],
    types: ['text', 'text', 'text', 'number', 'number', 'number'],
    rows: rows, rowKinds: rows.map(function (r, i) { return i === rows.length - 1 ? 'summary' : 'data'; }),
    periodDiff: periodDiff || [], totalAbsDiff: totalAbs, failures: failures
  };
}

// ---------------------------------------------------------------------------
// QuickBooks and spreadsheet orchestration
// ---------------------------------------------------------------------------

/** The company's home currency code (e.g. 'USD', 'EUR'), or '' if QuickBooks doesn't say. */
function companyHomeCurrency_(realmId) {
  try {
    var prefs = qboGet_(realmId, '/preferences', {});
    var cp = prefs.Preferences && prefs.Preferences.CurrencyPrefs;
    return (cp && cp.HomeCurrency && cp.HomeCurrency.value) || '';
  } catch (e) {
    return '';
  }
}

/**
 * Reads the FX tab, creating it or adding the currency column and month rows
 * the range needs, so finance only has to type the rates.
 */
function syncFxRates_(currencies, months, reportingCurrency) {
  var ss = SpreadsheetApp.getActive();
  var sheet = ss.getSheetByName(FX_TAB_);
  if (!sheet) {
    sheet = ss.insertSheet(FX_TAB_);
    sheet.getRange(1, 1).setValue('Monthly rates for consolidated tabs: ' + reportingCurrency +
      ' per 1 unit of each currency (use the same average rates as the consolidation). A header like "PHP per ' + reportingCurrency +
      '" takes rates quoted the other way. An empty month uses the latest earlier rate.')
      .setFontStyle('italic');
    sheet.getRange(2, 1).setValue('Month').setFontWeight('bold').setBackground('#f1f3f4');
    sheet.setFrozenRows(2);
    sheet.getRange('A:A').setNumberFormat('@');
  }
  var width = Math.max(1, sheet.getLastColumn());
  var header = sheet.getRange(2, 1, 1, width).getValues()[0];
  var codes = header.map(function (h) { var f = fxHeader_(h, reportingCurrency); return f ? f.code : String(h || ''); });
  currencies.forEach(function (c) {
    if (codes.indexOf(c) !== -1) return;
    codes.push(c);
    header.push(c);
    sheet.getRange(2, codes.length).setValue(c).setFontWeight('bold').setBackground('#f1f3f4');
  });
  var last = sheet.getLastRow();
  var rows = last > 2 ? sheet.getRange(3, 1, last - 2, codes.length).getValues() : [];
  var have = {};
  rows.forEach(function (r) { var k = fxMonthKey_(r[0]); if (k) have[k] = true; });
  var add = months.filter(function (k) { return !have[k]; }).map(function (k) {
    var row = [fxMonthLabel_(k)];
    for (var i = 1; i < codes.length; i++) row.push('');
    return row;
  });
  if (add.length) {
    sheet.getRange(Math.max(last, 2) + 1, 1, add.length, codes.length).setValues(add);
    rows = rows.concat(add);
  }
  return parseFxRows_(header, rows, reportingCurrency);
}
