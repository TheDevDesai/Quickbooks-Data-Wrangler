/**
 * Spreadsheet menu, sidebar and the server functions the sidebar calls.
 */

/**
 * Add-ons may only add a menu under Extensions; it takes the add-on's name
 * (or, for a spreadsheet-bound copy, the Apps Script project's name).
 */
function onOpen(e) {
  SpreadsheetApp.getUi()
    .createAddonMenu()
    .addItem('Connect to QuickBooks', 'showConnectDialog')
    .addItem('Sync now', 'menuSyncNow')
    .addItem('Sync this tab only', 'menuSyncActiveTab')
    .addSeparator()
    .addItem('Open QuickBooks panel', 'showSidebar')
    .addItem('Open QuickBooks panel (large window)', 'showPanelWindow')
    .addToUi();
}

function onInstall(e) {
  onOpen(e);
}

/** Opens the side panel. With autoSync, it starts syncing every tab as soon as it loads. */
function showSidebar(autoSync) {
  var t = HtmlService.createTemplateFromFile('Sidebar');
  t.autoSync = autoSync === true;
  t.asWindow = false;
  SpreadsheetApp.getUi().showSidebar(t.evaluate().setTitle('QuickBooks'));
}

/**
 * The same panel in a wider floating window. Sheets fixes sidebars at about
 * 300px and add-ons cannot change that, so this is the way to get more room.
 */
function showPanelWindow() {
  var t = HtmlService.createTemplateFromFile('Sidebar');
  t.autoSync = false;
  t.asWindow = true;
  SpreadsheetApp.getUi().showModelessDialog(t.evaluate().setWidth(640).setHeight(760), 'QuickBooks');
}

/** Small dialog with one button that opens the QuickBooks sign-in page. */
function showConnectDialog() {
  var t = HtmlService.createTemplateFromFile('ConnectDialog');
  t.addonName = QBW.ADDON_NAME;
  var html = t.evaluate().setWidth(380).setHeight(290);
  SpreadsheetApp.getUi().showModalDialog(html, 'Connect to QuickBooks');
}

/**
 * Syncing runs from the panel, one tab per server call, so each tab gets its
 * own time limit and the panel can show progress.
 */
function menuSyncNow() {
  showSidebar(true);
}

function menuSyncActiveTab() {
  var name = SpreadsheetApp.getActiveSheet().getName();
  var pull = listPulls().filter(function (p) { return p.sheetName === name; })[0];
  var ui = SpreadsheetApp.getUi();
  if (!pull) {
    ui.alert('This tab is not synced with QuickBooks',
      'Open the QuickBooks panel (Extensions > ' + QBW.ADDON_NAME + ' > Open QuickBooks panel) to add a synced tab.', ui.ButtonSet.OK);
    return;
  }
  SpreadsheetApp.getActive().toast('Getting the latest numbers from QuickBooks...', 'Syncing ' + pull.name, 30);
  try {
    var done = runPull(pull.id);
    SpreadsheetApp.getActive().toast(done.lastRows + ' rows, ' + done.lastRange, 'Synced ' + done.name, 6);
    if (done.lastWarning) ui.alert('Synced, but some balances need a look', done.lastWarning, ui.ButtonSet.OK);
  } catch (e) {
    ui.alert('This tab did not sync', e.message, ui.ButtonSet.OK);
  }
}

/** Called from the panel: brings a synced tab to the front. */
function openTab(name) {
  var sheet = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sheet) throw new Error('The tab "' + name + '" no longer exists. Sync it to recreate it.');
  sheet.activate();
}

/** Inlines another HTML file (shared styles) into a template. */
function include_(name) {
  return HtmlService.createHtmlOutputFromFile(name).getContent();
}

/** Everything the sidebar needs on load. */
function getSidebarState() {
  var settings = getAppSettings_();
  return {
    build: QBW.BUILD,
    configured: !!(settings.clientId && settings.clientSecret),
    environment: settings.environment,
    isAdmin: isAdmin_(),
    admins: getAdmins_(),
    redirectUri: getRedirectUri(),
    connections: listConnections(),
    pulls: listPulls(),
    reports: Object.keys(REPORT_CATALOG).map(function (k) {
      return { key: k, label: REPORT_CATALOG[k].label, params: REPORT_CATALOG[k].params, defaultColumns: REPORT_CATALOG[k].defaultColumns || '' };
    }),
    rollforwards: Object.keys(ROLLFORWARD_CATALOG).map(function (k) {
      return { key: k, label: ROLLFORWARD_CATALOG[k].label, filter: ROLLFORWARD_CATALOG[k].filter };
    }),
    rollforwardPeriods: ROLLFORWARD_PERIODS,
    entities: Object.keys(ENTITY_CATALOG).map(function (k) {
      return { key: k, label: ENTITY_CATALOG[k].label, dated: !!ENTITY_CATALOG[k].dateField, hasLines: !!ENTITY_CATALOG[k].hasLines };
    }),
    summarizeOptions: SUMMARIZE_OPTIONS,
    datePresets: Object.keys(DATE_PRESETS).map(function (k) { return { key: k, label: DATE_PRESETS[k] }; }),
    sheetNames: SpreadsheetApp.getActive().getSheets().map(function (s) { return s.getName(); })
  };
}

/**
 * Saves the Intuit app credentials and the admin list. Admins only; the
 * secret is never sent back to the browser.
 */
function saveAppSettings(clientId, clientSecret, environment, adminsText) {
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    if (!isAdmin_()) {
      throw new Error('Only QuickBooks admins can change the setup. Ask one of them: ' + getAdmins_().join(', '));
    }
    var p = PropertiesService.getScriptProperties();
    clientId = String(clientId || '').trim();
    clientSecret = String(clientSecret || '').trim();
    if (clientId) p.setProperty('QBW_CLIENT_ID', clientId);
    if (clientSecret) p.setProperty('QBW_CLIENT_SECRET', clientSecret);
    if (environment === 'sandbox' || environment === 'production') p.setProperty('QBW_ENVIRONMENT', environment);

    // Whoever saves always stays an admin, so nobody can lock themselves out.
    var me = currentUserEmail_();
    var admins = parseAdminList_(adminsText === undefined ? getAdmins_().join(',') : adminsText);
    if (me && admins.indexOf(me) === -1) admins.unshift(me);
    if (admins.length) p.setProperty('QBW_ADMINS', admins.join(','));
  } finally {
    lock.releaseLock();
  }
  return getSidebarState();
}
