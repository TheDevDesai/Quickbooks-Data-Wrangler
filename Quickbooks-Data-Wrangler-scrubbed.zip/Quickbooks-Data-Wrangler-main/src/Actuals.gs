/**
 * GL actuals by month: the actual amount posted to each GL account in each
 * period, grouped GL Group > GL account > vendor, like a pivot of the
 * General Ledger. No beginning or ending balances.
 *
 * GL Group is not a QuickBooks field. Each spreadsheet keeps its own mapping
 * in an "QB Account Groups" tab (account -> group), which the add-on creates
 * and extends with new accounts; people edit the Group column.
 *
 * Basis follows the pull: Accrual counts costs when recognized (journal
 * entries included), Cash counts them when paid. "Leave out journal entries"
 * gives a spend view: only bills, expenses, checks and card charges.
 *
 * Vendors come from VendorResolver: the line's Name, else its memo (aliases,
 * amortization patterns, rules). Only expense-account lines are included, so
 * a prepaid bill (debit to a prepaid asset) and its monthly amortization
 * (debit to the expense account) are never both counted.
 *
 * Every sync also writes, next to the main tab:
 *   "<tab> · Tie-out"     resolved-vendor totals vs QuickBooks' P&L, by account and period
 *   "<tab> · Unresolved"  lines whose vendor couldn't be found, with the memo
 * and, for the transaction detail layout:
 *   "<tab> · Explorer"    pick a GL account and vendors; monthly totals recompute
 */

var GROUPS_TAB_ = 'QB Account Groups';
var GROUPS_HEADER_ = ['Account Number', 'Account', 'Group', 'Account ID'];
var JOURNAL_ENTRY_ = 'Journal Entry';
var NO_VENDOR_ = '(No vendor)';
var NO_VENDOR_JE_ = '(No vendor: journal entry)';
var UNGROUPED_ = 'Ungrouped';
var LEFT_OUT_ = 'Left out of this tab';

// ---------------------------------------------------------------------------
// Pure helpers
// ---------------------------------------------------------------------------

/** Suggested group for an account not yet in the groups tab. */
function defaultGroup_(account) {
  if (account.AccountType === 'Cost of Goods Sold') return 'COGS';
  if (account.AccountType === 'Other Expense') return 'Other Expenses';
  if (account.Classification === 'Expense') return 'Operating Expenses';
  if (account.Classification === 'Revenue') return 'Income';
  return account.Classification || UNGROUPED_;
}

/** Credit-normal accounts (income, liabilities, equity) show credits as positive actuals. */
function isCreditNormal_(account) {
  return account.Classification === 'Revenue' || account.Classification === 'Liability' || account.Classification === 'Equity';
}

/**
 * Builds lookups from the groups tab rows ([number, name, group, id]).
 * Rows can be matched by account ID, account number, or name, so a pasted
 * list of "number, name, group" works without IDs.
 */
function buildGroupLookup_(rows) {
  var lookup = { byId: {}, byNumber: {}, byName: {}, order: [] };
  (rows || []).forEach(function (r) {
    var number = String(r[0] === undefined || r[0] === null ? '' : r[0]).trim();
    var name = String(r[1] || '').trim();
    var group = String(r[2] || '').trim();
    var id = String(r[3] === undefined || r[3] === null ? '' : r[3]).trim();
    if (!group || !(id || number || name)) return;
    if (lookup.order.indexOf(group) === -1) lookup.order.push(group);
    if (id) lookup.byId[id] = group;
    if (number) lookup.byNumber[number] = group;
    if (name) lookup.byName[name.toLowerCase()] = group;
  });
  return lookup;
}

/** The group for an account from the lookup, or '' when it isn't mapped. */
function groupFor_(lookup, account) {
  var id = String(account.Id || ''), number = String(account.AcctNum || '');
  var names = [account.FullyQualifiedName, account.Name, number && (number + ' ' + account.Name)]
    .filter(Boolean).map(function (n) { return String(n).toLowerCase(); });
  if (lookup.byId[id]) return lookup.byId[id];
  if (number && lookup.byNumber[number]) return lookup.byNumber[number];
  for (var i = 0; i < names.length; i++) if (lookup.byName[names[i]]) return lookup.byName[names[i]];
  return '';
}

function accountLabel_(a) {
  var name = a.FullyQualifiedName || a.Name || String(a.Id);
  return a.AcctNum ? a.AcctNum + ' ' + name : name;
}

/**
 * Sums GL lines into {group: {accountId: {vendor: [amount per period]}}}.
 * @param {Object[][]} periodLines GL lines per period.
 * @param {Object} accounts {id: QuickBooks Account} in scope.
 * @param {function(Object): string} groupOf Group for an account.
 * @param {Object} opts {byVendor, excludeJournalEntries}
 */
function computeActuals_(periodLines, accounts, groupOf, opts) {
  var data = {};
  var n = periodLines.length;
  periodLines.forEach(function (lines, p) {
    lines.forEach(function (l) {
      var a = accounts[l.accountId] || l.postedAccount;
      if (!a) return;
      var isJe = l.txnType === JOURNAL_ENTRY_;
      if (opts.excludeJournalEntries && isJe) return;
      var amount = isCreditNormal_(a) ? l.credit - l.debit : l.debit - l.credit;
      if (!amount) return;
      // A vendor override reports the line under another account (sign still from the posted account).
      var shownId = l.reportAccountId && accounts[l.reportAccountId] ? l.reportAccountId : l.accountId;
      var group = groupOf(accounts[shownId]) || UNGROUPED_;
      var vendor = opts.byVendor ? (l.vendor || l.name || (isJe ? NO_VENDOR_JE_ : NO_VENDOR_)) : '';
      var g = data[group] || (data[group] = {});
      var acc = g[shownId] || (g[shownId] = {});
      var row = acc[vendor] || (acc[vendor] = zeros_(n));
      row[p] = ROUND_(row[p] + amount);
    });
  });
  return data;
}

/**
 * Matcher for the vendors a pull leaves out. Names compare like vendor names
 * (case, punctuation and legal suffixes ignored); a name ending in * matches
 * every vendor that starts with it ("Event – AES*" also catches next year's tag).
 */
function buildVendorExcluder_(names) {
  var exact = {}, prefixes = [];
  (names || []).forEach(function (n) {
    n = String(n || '').trim();
    if (!n) return;
    if (n.charAt(n.length - 1) === '*') {
      var p = looseText_(n.slice(0, -1));
      if (p) prefixes.push(p);
    } else {
      exact[normalizeVendor_(n)] = true;
    }
  });
  return function (vendor) {
    if (exact[normalizeVendor_(vendor)]) return true;
    var loose = looseText_(vendor);
    return prefixes.some(function (p) { return loose === p || loose.indexOf(p + ' ') === 0; });
  };
}

function zeros_(n) {
  var z = [];
  for (var i = 0; i < n; i++) z.push(0);
  return z;
}

function sumInto_(target, values) {
  values.forEach(function (v, i) { if (typeof v === 'number') target[i] = ROUND_(target[i] + v); });
}

function total_(values) {
  return ROUND_(values.reduce(function (s, v) { return s + (typeof v === 'number' ? v : 0); }, 0));
}

/**
 * Index of the last period that counts as actuals: the one holding the end of
 * `through` ('yyyy-mm'), or of the last completed month before `today`.
 * Later periods are forecast. -1 when every period is still to come.
 */
function forecastCutIndex_(periods, through, today) {
  var ym = through;
  if (!ym) {
    var t = parseYmd_(today);
    var prev = normMonth_(t.y, t.m - 1);
    ym = prev.y + '-' + ('0' + prev.m).slice(-2);
  }
  var y = Number(ym.slice(0, 4)), m = Number(ym.slice(5, 7));
  var end = ymd_(y, m, daysInMonth_(y, m));
  var cut = -1;
  periods.forEach(function (p, i) { if (p.start <= end) cut = i; });
  return cut;
}

/**
 * Straight-line forecast in place: every row's periods after `cut` become the
 * average of its last `basis` actual periods ('ytd' = all of them). Months with
 * no spend count as 0, so the average is a true run-rate.
 * @param {Object} data {group: {account: {vendor: [amount per period]}}} from computeActuals_.
 */
function applyStraightLine_(data, cut, basis) {
  var from = basis === 'ytd' ? 0 : Math.max(0, cut - Number(basis) + 1);
  Object.keys(data).forEach(function (g) {
    Object.keys(data[g]).forEach(function (id) {
      Object.keys(data[g][id]).forEach(function (v) {
        var values = data[g][id][v];
        var used = values.slice(from, cut + 1);
        var avg = used.length ? ROUND_(used.reduce(function (s, x) { return s + x; }, 0) / used.length) : 0;
        for (var p = cut + 1; p < values.length; p++) values[p] = avg;
      });
    });
  });
}

/** Clears forecast periods from an actuals-only row (check, moved in, left out). */
function blankForecast_(values, forecastFrom) {
  if (forecastFrom === undefined || forecastFrom === null || !values) return values;
  return values.map(function (v, p) { return p >= forecastFrom ? null : v; });
}

var FORECAST_BASES_ = { '1': 'last month', '3': 'last 3 months', '6': 'last 6 months', ytd: 'year to date' };

/**
 * Lays out computed actuals.
 *   schedule: GL Group | GL Account | Vendor | one column per period | Total,
 *             with account, group and grand totals (like a pivot table).
 *   long:     one row per group, account, vendor and period (for pivots).
 * @param {Object} spec {data, leftOut, movedIn, forecastFrom (first forecast period, or null), accounts, periods,
 *   groupOrder, layout, byVendor, includeZero, checkDiff, title}
 */
function layoutActuals_(spec) {
  var periods = spec.periods, n = periods.length;
  var accounts = spec.accounts;
  var groups = Object.keys(spec.data);
  if (spec.includeZero) {
    // Accounts with no activity still get a row, under their group.
    Object.keys(accounts).forEach(function (id) {
      var g = spec.groupOf(accounts[id]) || UNGROUPED_;
      var bucket = spec.data[g] || (spec.data[g] = {});
      if (!bucket[id]) { bucket[id] = {}; bucket[id][spec.byVendor ? NO_VENDOR_ : ''] = zeros_(n); }
    });
    groups = Object.keys(spec.data);
  }
  var order = spec.groupOrder || [];
  groups.sort(function (a, b) {
    var ia = order.indexOf(a), ib = order.indexOf(b);
    if (a === UNGROUPED_) ia = 1e6;
    if (b === UNGROUPED_) ib = 1e6;
    if (ia === -1) ia = 1e5;
    if (ib === -1) ib = 1e5;
    return ia - ib || (a < b ? -1 : a > b ? 1 : 0);
  });
  var accountSort = function (x, y) {
    var ax = accounts[x], ay = accounts[y];
    var kx = (ax.AcctNum ? '0' + padSort_(ax.AcctNum) : '1') + accountLabel_(ax).toLowerCase();
    var ky = (ay.AcctNum ? '0' + padSort_(ay.AcctNum) : '1') + accountLabel_(ay).toLowerCase();
    return kx < ky ? -1 : kx > ky ? 1 : 0;
  };
  var vendorSort = function (x, y) {
    // Real vendors alphabetically, then the "(No vendor ...)" buckets.
    var px = x.charAt(0) === '(' ? 1 : 0, py = y.charAt(0) === '(' ? 1 : 0;
    return px - py || x.toLowerCase().localeCompare(y.toLowerCase());
  };
  var ff = spec.forecastFrom;
  var isForecast = function (p) { return ff !== undefined && ff !== null && p >= ff; };
  var labels = periods.map(function (p, i) { return p.label + (isForecast(i) ? ' (F)' : ''); });

  if (spec.layout === 'long') {
    var header = ['GL Group', 'Account Number', 'GL Account', 'Account ID']
      .concat(spec.byVendor ? ['Vendor'] : [])
      .concat(['Period', 'Period Start', 'Period End', 'Amount'])
      .concat(ff !== undefined && ff !== null ? ['Actual / Forecast'] : []);
    var types = header.map(function (h) {
      return h === 'Amount' ? 'number' : (h === 'Period Start' || h === 'Period End') ? 'date' : 'text';
    });
    var rows = [];
    var pushLong = function (data, groupLabel) {
      Object.keys(data).forEach(function (g) {
        Object.keys(data[g]).sort(accountSort).forEach(function (id) {
          var a = accounts[id];
          Object.keys(data[g][id]).sort(vendorSort).forEach(function (v) {
            data[g][id][v].forEach(function (amt, p) {
              if (!amt && !spec.includeZero) return;
              if (groupLabel && isForecast(p)) return; // left-out rows are actuals only
              rows.push([groupLabel || g, a.AcctNum || '', a.FullyQualifiedName || a.Name, String(id)]
                .concat(spec.byVendor ? [v] : [])
                .concat([periods[p].label, periods[p].start, periods[p].end, amt])
                .concat(ff !== undefined && ff !== null ? [isForecast(p) ? 'Forecast' : 'Actual'] : []));
            });
          });
        });
      });
    };
    groups.forEach(function (g) { var one = {}; one[g] = spec.data[g]; pushLong(one); });
    if (spec.leftOut) pushLong(spec.leftOut, LEFT_OUT_);
    return { header: header, rows: rows, types: types, rowKinds: rows.map(function () { return 'data'; }), title: spec.title };
  }

  var lead = spec.byVendor ? ['GL Group', 'GL Account', 'Vendor'] : ['GL Group', 'GL Account'];
  var header2 = lead.concat(labels).concat(n > 1 ? ['Total'] : []);
  var types2 = header2.map(function (h, i) { return i < lead.length ? 'text' : 'number'; });
  var blank = lead.map(function () { return ''; });
  var withTotal = function (values) { return n > 1 ? values.concat([total_(values)]) : values; };
  var out = [], kinds = [];
  var grand = zeros_(n);
  groups.forEach(function (g) {
    var groupSum = zeros_(n);
    var head = blank.slice(); head[0] = g;
    out.push(head.concat(labels.map(function () { return ''; })).concat(n > 1 ? [''] : []));
    kinds.push('header');
    Object.keys(spec.data[g]).sort(accountSort).forEach(function (id) {
      var label = accountLabel_(accounts[id]);
      var vendors = Object.keys(spec.data[g][id]).sort(vendorSort);
      var accSum = zeros_(n);
      vendors.forEach(function (v, i) {
        var values = spec.data[g][id][v];
        sumInto_(accSum, values);
        if (!spec.byVendor) return;
        out.push(['', i === 0 ? label : '', v].concat(withTotal(values)));
        kinds.push('data');
      });
      if (spec.byVendor) {
        out.push(['', 'Total ' + label, ''].concat(withTotal(accSum)));
        kinds.push('subtotal');
      } else {
        out.push(['', label].concat(withTotal(accSum)));
        kinds.push('data');
      }
      sumInto_(groupSum, accSum);
    });
    var tot = blank.slice(); tot[0] = 'Total ' + g;
    out.push(tot.concat(withTotal(groupSum)));
    kinds.push('summary');
    sumInto_(grand, groupSum);
  });
  if (out.length) {
    var gt = blank.slice(); gt[0] = 'Grand total';
    out.push(gt.concat(withTotal(grand)));
    kinds.push('summary');
  }
  if (spec.movedIn) {
    // Lines posted to accounts outside this tab, shown here by a Vendor Aliases account override.
    var mi = blank.slice(); mi[0] = 'Of which moved in from other GL accounts (Vendor Aliases)' + (ff !== undefined && ff !== null ? ', actuals' : '');
    out.push(mi.concat(withTotal(blankForecast_(spec.movedIn, ff))));
    kinds.push('data');
  }
  var leftRows = [];
  if (spec.leftOut) {
    var leftSum = zeros_(n);
    Object.keys(spec.leftOut).forEach(function (g) {
      Object.keys(spec.leftOut[g]).sort(accountSort).forEach(function (id) {
        var label = accountLabel_(accounts[id]);
        Object.keys(spec.leftOut[g][id]).sort(vendorSort).forEach(function (v) {
          var values = blankForecast_(spec.leftOut[g][id][v], ff);
          sumInto_(leftSum, values);
          leftRows.push((spec.byVendor ? ['', label, v] : ['', label + ' · ' + v]).concat(withTotal(values)));
        });
      });
    });
    if (leftRows.length) {
      var lh = blank.slice(); lh[0] = LEFT_OUT_ + ' (not in the totals above)';
      out.push(lh.concat(labels.map(function () { return ''; })).concat(n > 1 ? [''] : []));
      kinds.push('header');
      leftRows.forEach(function (r) { out.push(r); kinds.push('data'); });
      var lt = blank.slice(); lt[0] = 'Total left out';
      out.push(lt.concat(withTotal(blankForecast_(leftSum, ff))));
      kinds.push('summary');
    }
  }
  if (spec.checkDiff) {
    var ck = blank.slice();
    ck[0] = 'Check' + (leftRows.length || spec.movedIn ? ': grand total' + (leftRows.length ? ' + left out' : '') +
      (spec.movedIn ? ' − moved in' : '') + ' vs QuickBooks P&L' : ' vs QuickBooks P&L') + ' (should be 0)';
    out.push(ck.concat(withTotal(blankForecast_(spec.checkDiff, ff))));
    kinds.push('subtotal');
  }
  return { header: header2, rows: out, types: types2, rowKinds: kinds, title: spec.title };
}

/** A line's actual amount in the account's natural sign. */
function actualAmount_(line, account) {
  return isCreditNormal_(account) ? line.credit - line.debit : line.debit - line.credit;
}

/** {accountId: [amount per period]} from GL lines (optionally without journal entries). */
function accountPeriodTotals_(periodLines, accounts, excludeJournalEntries) {
  var out = {};
  periodLines.forEach(function (lines, p) {
    lines.forEach(function (l) {
      var a = accounts[l.accountId];
      if (!a || (excludeJournalEntries && l.txnType === JOURNAL_ENTRY_)) return;
      var row = out[l.accountId] || (out[l.accountId] = zeros_(periodLines.length));
      row[p] = ROUND_(row[p] + actualAmount_(l, a));
    });
  });
  return out;
}

/** {accountId: [amount per period]} from a P&L summarized by month, mapped onto the given periods. */
function parsePnlByAccountPeriod_(report, periods) {
  var cols = reportColumns_(report);
  var colPeriod = cols.map(function (c) {
    if (!c.startDate) return -1;
    for (var p = 0; p < periods.length; p++) {
      if (c.startDate >= periods[p].start && c.startDate <= periods[p].end) return p;
    }
    return -1;
  });
  var out = {};
  walkReport_(report).forEach(function (e) {
    if (e.kind === 'summary') return;
    var id = e.cells[0] && e.cells[0].id;
    if (!id) return;
    colPeriod.forEach(function (p, i) {
      if (p < 0) return;
      var v = num_(e.cells, i);
      if (!v) return;
      var row = out[id] || (out[id] = zeros_(periods.length));
      row[p] = ROUND_(row[p] + v);
    });
  });
  return out;
}

/**
 * Resolved totals vs QuickBooks, one row per account and period, ending with
 * a check row that should be 0.
 */
function buildTieOut_(computed, qbo, accounts, periods) {
  var ids = {};
  Object.keys(computed).concat(Object.keys(qbo)).forEach(function (id) { if (accounts[id]) ids[id] = true; });
  var sorted = Object.keys(ids).sort(function (x, y) {
    var kx = accountLabel_(accounts[x]).toLowerCase(), ky = accountLabel_(accounts[y]).toLowerCase();
    return kx < ky ? -1 : kx > ky ? 1 : 0;
  });
  var rows = [], periodDiff = zeros_(periods.length), totalAbs = 0, failures = [];
  sorted.forEach(function (id) {
    periods.forEach(function (per, p) {
      var mine = (computed[id] || [])[p] || 0, theirs = (qbo[id] || [])[p] || 0;
      if (!mine && !theirs) return;
      var diff = ROUND_(mine - theirs);
      rows.push([accountLabel_(accounts[id]), per.label, theirs, mine, diff]);
      periodDiff[p] = ROUND_(periodDiff[p] + diff);
      totalAbs = ROUND_(totalAbs + Math.abs(diff));
      if (Math.abs(diff) >= 0.01) failures.push(accountLabel_(accounts[id]) + ' ' + per.label + ': ' + diff.toFixed(2));
    });
  });
  rows.push(['Check: total of differences (should be 0)', '', '', '', totalAbs]);
  return {
    header: ['GL Account', 'Period', 'QuickBooks P&L', 'Resolved vendors total', 'Difference'],
    types: ['text', 'text', 'number', 'number', 'number'],
    rows: rows, rowKinds: rows.map(function (r, i) { return i === rows.length - 1 ? 'summary' : 'data'; }),
    periodDiff: periodDiff, totalAbsDiff: totalAbs, failures: failures
  };
}

var DETAIL_HEADER_ = ['Date', 'Month', 'GL Group', 'Account Number', 'GL Account', 'Transaction Type', 'JE / Doc Number',
  'QBO Name', 'Resolved Vendor', 'Vendor Source', 'Original Memo', 'Amount', 'Reclassed from'];
var DETAIL_COL_ = { month: 2, account: 5, vendor: 9, amount: 12 }; // 1-based, used by the Explorer formulas

/**
 * One row per GL line with its resolved vendor, plus the exception rows.
 * Lines must already carry vendor / vendorSource / parsed from resolveVendor_.
 * A consolidated pull adds Company, local amount and FX rate columns at the end.
 */
function layoutActualsDetail_(periodLines, accounts, groupOf, periods, excludeJournalEntries, consolidated) {
  var rows = [], exceptions = [];
  periodLines.forEach(function (lines, p) {
    lines.forEach(function (l) {
      var a = accounts[l.accountId] || l.postedAccount;
      if (!a || (excludeJournalEntries && l.txnType === JOURNAL_ENTRY_)) return;
      var amount = ROUND_(actualAmount_(l, a));
      if (!amount) return;
      var shown = l.reportAccountId && accounts[l.reportAccountId] ? accounts[l.reportAccountId] : a;
      var row = [l.date, periods[p].label, groupOf(shown) || UNGROUPED_, shown.AcctNum || '', accountLabel_(shown), l.txnType,
        l.docNum || '', l.name || '', l.vendor || l.name || '', l.vendorSource || '', l.memo || '', amount,
        shown === a ? '' : accountLabel_(a)];
      if (consolidated) {
        var local = l.fxRate ? ROUND_(isCreditNormal_(a) ? l.localCredit - l.localDebit : l.localDebit - l.localCredit) : amount;
        row.push(l.company || '', local, l.fxRate || 1);
      }
      rows.push(row);
      if (isVendorException_(l.vendorSource)) {
        var ex = [l.date, accountLabel_(a), l.txnType, l.docNum || '', amount, l.memo || '', l.parsed || ''];
        exceptions.push(consolidated ? [l.company || ''].concat(ex) : ex);
      }
    });
  });
  rows.sort(function (x, y) { return x[0] < y[0] ? -1 : x[0] > y[0] ? 1 : (x[4] < y[4] ? -1 : x[4] > y[4] ? 1 : 0); });
  var amt = consolidated ? 5 : 4;
  exceptions.sort(function (x, y) { return Math.abs(y[amt]) - Math.abs(x[amt]); });
  var exHeader = ['Date', 'GL Account', 'Transaction Type', 'JE / Doc Number', 'Amount', 'Original Memo', 'Text found in memo'];
  var exTypes = ['date', 'text', 'text', 'text', 'number', 'text', 'text'];
  return {
    detail: {
      header: DETAIL_HEADER_.concat(consolidated ? ['Company', 'Amount (company currency)', 'FX rate'] : []),
      rows: rows, rowKinds: rows.map(function () { return 'data'; }),
      types: ['date', 'text', 'text', 'text', 'text', 'text', 'text', 'text', 'text', 'text', 'text', 'number', 'text']
        .concat(consolidated ? ['text', 'number', 'rate'] : [])
    },
    exceptions: {
      header: consolidated ? ['Company'].concat(exHeader) : exHeader,
      types: consolidated ? ['text'].concat(exTypes) : exTypes,
      rows: exceptions, rowKinds: exceptions.map(function () { return 'data'; })
    }
  };
}

// ---------------------------------------------------------------------------
// QuickBooks and spreadsheet orchestration
// ---------------------------------------------------------------------------

/** Reads the groups tab, adds any in-scope accounts it doesn't list yet, and returns the lookup. */
function syncAccountGroups_(scopeAccounts) {
  var ss = SpreadsheetApp.getActive();
  var sheet = ss.getSheetByName(GROUPS_TAB_);
  if (!sheet) {
    sheet = ss.insertSheet(GROUPS_TAB_);
    sheet.getRange(1, 1).setValue('Account groups for GL actuals. Edit the Group column; new accounts are added at the bottom when you sync.')
      .setFontStyle('italic');
    sheet.getRange(2, 1, 1, GROUPS_HEADER_.length).setValues([GROUPS_HEADER_]).setFontWeight('bold').setBackground('#f1f3f4');
    sheet.setFrozenRows(2);
    sheet.getRange('A:A').setNumberFormat('@');
    sheet.getRange('D:D').setNumberFormat('@');
  }
  var last = sheet.getLastRow();
  var rows = last > 2 ? sheet.getRange(3, 1, last - 2, GROUPS_HEADER_.length).getValues() : [];
  var lookup = buildGroupLookup_(rows);
  var missing = scopeAccounts.filter(function (a) { return !groupFor_(lookup, a); });
  // Accounts listed with an empty Group are left for people to fill in, not re-added.
  var listed = {};
  rows.forEach(function (r) { if (r[3]) listed[String(r[3])] = true; });
  var toAdd = missing.filter(function (a) { return !listed[String(a.Id)]; }).map(function (a) {
    return [a.AcctNum || '', a.FullyQualifiedName || a.Name, defaultGroup_(a), String(a.Id)];
  });
  if (toAdd.length) {
    sheet.getRange(Math.max(last, 2) + 1, 1, toAdd.length, GROUPS_HEADER_.length).setValues(toAdd);
    lookup = buildGroupLookup_(rows.concat(toAdd));
  }
  return lookup;
}

/**
 * Fetches one company's in-scope GL lines per period with resolved vendors and
 * vendor account overrides, and ties them out against its own P&L.
 * @param {Object} c {realmId, all, accounts: {id: account} in scope}
 */
function loadCompanyActuals_(c, periods, range, method, excludeJe) {
  var ids = Object.keys(c.accounts);
  var index = accountNameIndex_(c.all);
  var columns = 'tx_date,txn_type,doc_num,name,memo,' +
    (companyUsesMultiCurrency_(c.realmId) ? 'debt_home_amt,credit_home_amt' : 'debt_amt,credit_amt');
  var periodLines = periods.map(function (p) {
    var params = { start_date: p.start, end_date: p.end, columns: columns, accounting_method: method };
    return fetchGeneralLedgerLines_(c.realmId, params, ids, c.all).map(function (l) {
      if (!l.accountId) l.accountId = index[l.accountName] || '';
      return l;
    });
  });

  var vendorCtx = loadVendorContext_(c.realmId);
  periodLines.forEach(function (lines) {
    lines.forEach(function (l) {
      var r = resolveVendor_(l, vendorCtx);
      l.vendor = r.vendor;
      l.vendorSource = r.source;
      l.parsed = r.parsed;
    });
  });

  // A vendor override pointing at an account in this tab also brings in that vendor's lines from expense
  // accounts outside it (e.g. Google Ads card charges coded to 5160 shown under 6400 Demand Gen).
  var outside = c.all.filter(function (a) { return a.Classification === 'Expense' && !c.accounts[String(a.Id)]; });
  var pulledIn = Object.keys(vendorCtx.overrides || {}).some(function (v) {
    var t = findAccountByText_(c.all, vendorCtx.overrides[v]);
    return t && c.accounts[String(t.Id)];
  });
  if (pulledIn && outside.length) {
    var outsideIds = outside.map(function (a) { return String(a.Id); });
    var byId = {};
    c.all.forEach(function (a) { byId[String(a.Id)] = a; });
    periods.forEach(function (p, i) {
      var params = { start_date: p.start, end_date: p.end, columns: columns, accounting_method: method };
      fetchGeneralLedgerLines_(c.realmId, params, outsideIds, c.all).forEach(function (l) {
        if (!l.accountId) l.accountId = index[l.accountName] || '';
        var r = resolveVendor_(l, vendorCtx);
        var t = findAccountByText_(c.all, vendorAccountOverride_(vendorCtx, r.vendor));
        if (!t || !c.accounts[String(t.Id)] || c.accounts[l.accountId]) return;
        l.vendor = r.vendor;
        l.vendorSource = r.source;
        l.parsed = r.parsed;
        l.broughtIn = true;
        l.postedAccount = byId[l.accountId];
        if (l.postedAccount) periodLines[i].push(l);
      });
    });
  }

  // Vendor overrides from the aliases tab move a vendor's lines to another account in this report.
  // "shown" holds the accounts lines are reported under; "accounts" stays the posted scope for the tie-out.
  var shown = {}, missingTargets = {};
  ids.forEach(function (id) { shown[id] = c.accounts[id]; });
  periodLines.forEach(function (lines) {
    lines.forEach(function (l) {
      var target = vendorAccountOverride_(vendorCtx, l.vendor);
      if (!target) return;
      var t = findAccountByText_(c.all, target);
      if (!t) { missingTargets[target] = true; return; }
      if (String(t.Id) === l.accountId) return;
      l.reportAccountId = String(t.Id);
      shown[String(t.Id)] = t;
    });
  });

  // Tie-out against QuickBooks' own P&L. Skipped for the spend view, which leaves journal entries out on purpose.
  var tieOut = null;
  if (!excludeJe) {
    var pnl = qboReport_(c.realmId, 'ProfitAndLoss', {
      start_date: range.start, end_date: range.end, accounting_method: method, summarize_column_by: 'Month'
    });
    tieOut = buildTieOut_(accountPeriodTotals_(periodLines, c.accounts, false), parsePnlByAccountPeriod_(pnl, periods), c.accounts, periods);
  }
  return { periodLines: periodLines, shown: shown, missingTargets: missingTargets, tieOut: tieOut };
}

function buildActuals_(pull, range, conn) {
  var realmId = pull.realmId;
  var fsm = conn.fiscalStartMonth || 1;
  var periods = buildPeriods_(range.start, range.end, pull.period || 'Month', fsm);
  var method = pull.accountingMethod || 'Accrual';
  var byVendor = pull.byVendor !== false;
  var excludeJe = !!pull.excludeJournalEntries;
  var selected = (pull.filters && pull.filters.account) || [];
  var others = pull.alsoRealmIds || [];
  var warnings = [];

  var all = qboQueryAll_(realmId, 'Account', 'SELECT * FROM Account WHERE Active IN (true, false)');
  var accounts = {};
  all.forEach(function (a) {
    var inScope = selected.length ? selected.indexOf(String(a.Id)) !== -1 : a.Classification === 'Expense';
    if (inScope) accounts[String(a.Id)] = a;
  });
  if (!Object.keys(accounts).length) throw new Error('No matching GL accounts found in QuickBooks.');

  var primary = loadCompanyActuals_({ realmId: realmId, all: all, accounts: accounts }, periods, range, method, excludeJe);
  var periodLines = primary.periodLines;
  var shown = primary.shown;
  var missingTargets = primary.missingTargets;
  var tieOut = primary.tieOut;
  var companyNames = [conn.companyName];

  if (others.length) {
    // Consolidated: add each other company's lines, mapped onto the primary accounts and converted.
    var reporting = companyHomeCurrency_(realmId) || 'USD';
    periodLines.forEach(function (lines) { lines.forEach(function (l) { l.company = conn.companyName; }); });
    var parts = tieOut ? [{ company: conn.companyName, tieOut: tieOut, rateOf: function () { return 1; } }] : [];
    var fxTable = null;
    others.forEach(function (otherId) {
      var oc = getConnection_(otherId);
      var oAll = qboQueryAll_(otherId, 'Account', 'SELECT * FROM Account WHERE Active IN (true, false)');
      var oAccounts = {};
      otherCompanyScope_(oAll, all, selected).forEach(function (a) { oAccounts[String(a.Id)] = a; });
      if (!Object.keys(oAccounts).length) return;
      var o = loadCompanyActuals_({ realmId: otherId, all: oAll, accounts: oAccounts }, periods, range, method, excludeJe);
      var currency = companyHomeCurrency_(otherId);
      if (!currency) throw new Error('QuickBooks did not say which currency ' + oc.companyName + ' keeps its books in, so its amounts cannot be converted. Try again; if it keeps happening, untick it under Also include.');
      var rateOf = function () { return 1; };
      if (currency !== reporting) {
        if (!fxTable || !fxTable[currency]) fxTable = syncFxRates_([currency], monthsBetween_(range.start, range.end), reporting);
        var borrowed = convertLines_(o.periodLines, fxTable, currency, reporting);
        var used = Object.keys(borrowed);
        if (used.length) {
          warnings.push(oc.companyName + ': no ' + currency + ' rate yet for ' + used.join(', ') + ' in the "' + FX_TAB_ +
            '" tab, so the latest earlier rate was used (' + used.map(function (k) { return borrowed[k]; }).join(', ') + ').');
        }
        rateOf = function (p) {
          var fx = fxRateFor_(fxTable, currency, periods[p].end.slice(0, 7));
          return fx ? fx.rate : 1;
        };
      }
      if (o.tieOut) parts.push({ company: oc.companyName, tieOut: o.tieOut, rateOf: rateOf });
      var map = mapAccountsToPrimary_(all, oAll, otherId);
      o.periodLines.forEach(function (lines, p) {
        lines.forEach(function (l) {
          var posted = (oAccounts[l.accountId] || l.broughtIn) && map[l.accountId];
          if (!posted) return;
          l.company = oc.companyName;
          l.accountId = String(posted.Id);
          if (l.broughtIn) l.postedAccount = posted;
          else shown[l.accountId] = posted;
          if (l.reportAccountId && map[l.reportAccountId]) {
            l.reportAccountId = String(map[l.reportAccountId].Id);
            shown[l.reportAccountId] = map[l.reportAccountId];
          }
          periodLines[p].push(l);
        });
      });
      Object.keys(o.shown).forEach(function (id) { if (map[id]) shown[String(map[id].Id)] = map[id]; });
      Object.keys(o.missingTargets).forEach(function (t) { missingTargets[t] = true; });
      companyNames.push(oc.companyName + (currency !== reporting ? ' (' + currency + ' converted to ' + reporting + ')' : ''));
    });
    tieOut = parts.length ? combineTieOuts_(parts) : null;
  }

  // Vendors left out in the settings come off the totals and are listed at the bottom instead.
  var leftOutLines = null, leftOutVendors = {};
  if ((pull.excludeVendors || []).length) {
    var isLeftOut = buildVendorExcluder_(pull.excludeVendors);
    var vendorOf = function (l) { return l.vendor || l.name || ''; };
    leftOutLines = periodLines.map(function (lines) { return lines.filter(function (l) { return isLeftOut(vendorOf(l)); }); });
    periodLines = periodLines.map(function (lines) { return lines.filter(function (l) { return !isLeftOut(vendorOf(l)); }); });
    leftOutLines.forEach(function (lines) {
      lines.forEach(function (l) {
        if ((shown[l.accountId] || l.postedAccount) && (l.debit || l.credit) && !(excludeJe && l.txnType === JOURNAL_ENTRY_)) leftOutVendors[vendorOf(l)] = true;
      });
    });
  }

  var lookup = syncAccountGroups_(Object.keys(shown).map(function (id) { return shown[id]; }));
  var groupOf = function (a) { return groupFor_(lookup, a); };
  var detail = layoutActualsDetail_(periodLines, shown, groupOf, periods, excludeJe, others.length > 0);
  writeActualsCompanions_(pull.sheetName, tieOut, detail.exceptions, pull.layout === 'detail' ? periods : null);

  var leftCount = Object.keys(leftOutVendors).length;
  var basis = method + ' basis' + (excludeJe ? ', journal entries left out (spend view)' : '') +
    (leftCount ? '; ' + leftCount + ' vendor' + (leftCount === 1 ? '' : 's') + ' left out' +
      (pull.layout === 'detail' ? ' (in settings)' : ' (listed at the bottom)') : '');
  var result;
  if (pull.layout === 'detail') {
    result = detail.detail;
  } else {
    var data = computeActuals_(periodLines, shown, groupOf, { byVendor: byVendor, excludeJournalEntries: excludeJe });
    // Straight-line forecast: periods after the actuals cut-off become each row's average run-rate.
    var forecastFrom = null;
    if (pull.forecastBasis) {
      var cut = forecastCutIndex_(periods, pull.forecastThrough, range.today);
      if (cut >= 0 && cut < periods.length - 1) {
        applyStraightLine_(data, cut, pull.forecastBasis);
        forecastFrom = cut + 1;
        basis += '; actuals through ' + periods[cut].label + ', then straight-line forecast (F) at the ' +
          FORECAST_BASES_[pull.forecastBasis] + ' average';
      }
    }
    var leftOut = leftCount ? computeActuals_(leftOutLines, shown, groupOf, { byVendor: true, excludeJournalEntries: excludeJe }) : null;
    var movedIn = zeros_(periods.length), anyMoved = false;
    periodLines.forEach(function (lines, p) {
      lines.forEach(function (l) {
        if (!l.broughtIn || (excludeJe && l.txnType === JOURNAL_ENTRY_)) return;
        movedIn[p] = ROUND_(movedIn[p] + actualAmount_(l, l.postedAccount));
        anyMoved = anyMoved || !!movedIn[p];
      });
    });
    result = layoutActuals_({
      data: data, leftOut: leftOut, movedIn: anyMoved ? movedIn : null, forecastFrom: forecastFrom, accounts: shown, periods: periods, groupOrder: lookup.order, groupOf: groupOf,
      layout: pull.layout, byVendor: byVendor, includeZero: !!pull.includeZero,
      checkDiff: tieOut && pull.layout === 'schedule' ? tieOut.periodDiff : null,
      title: ['GL Actuals by Account' + (byVendor ? ' and Vendor' : ''), companyNames.join(' + '), range.start + ' to ' + range.end, basis,
        'Groups come from the "' + GROUPS_TAB_ + '" tab; vendors for unnamed lines come from memos (see "' + ALIASES_TAB_ + '")']
    });
  }
  if (tieOut && tieOut.failures.length) {
    warnings.unshift(tieOut.failures.length + ' account-month(s) differ from the QuickBooks P&L: ' +
      tieOut.failures.slice(0, 4).join('; ') + (tieOut.failures.length > 4 ? '; ...' : '') + ' (see the Tie-out tab).');
  }
  var missing = Object.keys(missingTargets);
  if (missing.length) {
    warnings.push('These GL accounts in the "' + ALIASES_TAB_ + '" tab were not found in QuickBooks, so those vendors stay under their posted account: ' + missing.join(', ') + '.');
  }
  result.warning = warnings.join(' ');
  return result;
}

/**
 * Called from the sidebar: vendor names to offer under "Leave out vendors" —
 * the company's QuickBooks vendors, the alias vendors, and every vendor name
 * already on the tab (which includes memo tags like "Event – AES Mar-26").
 */
function listActualsVendors(realmId, sheetName) {
  var names = {};
  var add = function (v) {
    v = String(v === undefined || v === null ? '' : v).trim();
    if (v && v.indexOf('Total ') !== 0) names[v] = true;
  };
  listDimension(realmId, 'Vendor').forEach(function (v) { add(v.name); });
  var ss = SpreadsheetApp.getActive();
  var aliases = ss.getSheetByName(ALIASES_TAB_);
  if (aliases && aliases.getLastRow() > 2) aliases.getRange(3, 2, aliases.getLastRow() - 2, 1).getValues().forEach(function (r) { add(r[0]); });
  var sheet = sheetName && ss.getSheetByName(sheetName);
  if (sheet && sheet.getLastRow() > 1) {
    var width = Math.min(sheet.getLastColumn(), 20);
    var top = sheet.getRange(1, 1, Math.min(sheet.getLastRow(), 10), width).getValues();
    for (var r = 0; r < top.length; r++) {
      var c = top[r].indexOf('Resolved Vendor');
      if (c === -1) c = top[r].indexOf('Vendor');
      if (c === -1) continue;
      if (sheet.getLastRow() > r + 1) sheet.getRange(r + 2, c + 1, sheet.getLastRow() - r - 1, 1).getValues().forEach(function (v) { add(v[0]); });
      break;
    }
  }
  return Object.keys(names).sort(function (a, b) { return a.toLowerCase().localeCompare(b.toLowerCase()); })
    .map(function (n) { return { id: n, name: n }; });
}

/** Tab names that sit next to a GL actuals tab. */
function companionTabName_(sheetName, suffix) {
  return (sheetName + ' · ' + suffix).slice(0, 99);
}

function quoteSheet_(name) {
  return "'" + String(name).replace(/'/g, "''") + "'";
}

/** Writes the Tie-out and Unresolved tabs, and the Explorer for the detail layout. */
function writeActualsCompanions_(sheetName, tieOut, exceptions, explorerPeriods) {
  if (tieOut) {
    writeResult_(companionTabName_(sheetName, 'Tie-out'), tieOut, {
      note: 'Resolved-vendor totals by account and period compared with the QuickBooks Profit and Loss. The last row should be 0.'
    });
  }
  var ex = exceptions.rows.length ? exceptions
    : { header: ['Every line has a vendor. Nothing to review.'], rows: [], types: ['text'], rowKinds: [] };
  writeResult_(companionTabName_(sheetName, 'Unresolved'), ex, {
    note: 'Lines with no Name whose memo matched no vendor, alias or rule. Add an alias for the memo text to the "' +
      ALIASES_TAB_ + '" tab and sync again.'
  });
  if (explorerPeriods) writeVendorExplorer_(sheetName, explorerPeriods);
}

var EXPLORER_VENDOR_SLOTS_ = 10;
var EXPLORER_ROWS_ = 300;

/**
 * "<tab> · Explorer": pick a GL account and up to 10 vendors (blank = all of
 * the account's vendors); a monthly table recomputes from the detail tab with
 * SUMIFS. Picks are kept across syncs.
 */
function writeVendorExplorer_(detailName, periods) {
  var ss = SpreadsheetApp.getActive();
  var explorerName = companionTabName_(detailName, 'Explorer');
  var listsName = companionTabName_(detailName, 'Lists');
  var d = quoteSheet_(detailName), e = quoteSheet_(explorerName), L = quoteSheet_(listsName);
  var letter = function (n) { return String.fromCharCode(64 + n); };
  var dAccount = d + '!' + letter(DETAIL_COL_.account) + '2:' + letter(DETAIL_COL_.account);
  var dVendor = d + '!' + letter(DETAIL_COL_.vendor) + '2:' + letter(DETAIL_COL_.vendor);

  var explorer = ss.getSheetByName(explorerName);
  var picked = explorer ? explorer.getRange(3, 2, 1 + EXPLORER_VENDOR_SLOTS_, 1).getValues() : null; // keep picks
  if (!explorer) explorer = ss.insertSheet(explorerName);
  explorer.clear();
  explorer.getRange(1, 1, explorer.getMaxRows(), explorer.getMaxColumns()).clearDataValidations();

  var lists = ss.getSheetByName(listsName) || ss.insertSheet(listsName);
  lists.clear();
  lists.getRange(1, 1, 1, 2).setValues([['GL accounts', 'Vendors in the chosen account']]);
  lists.getRange(2, 1).setFormula('=IFERROR(SORT(UNIQUE(FILTER(' + dAccount + ',' + dAccount + '<>""))),"")');
  lists.getRange(2, 2).setFormula('=IFERROR(SORT(UNIQUE(FILTER(' + dVendor + ',' + dAccount + '=' + e + '!$B$3))),"")');
  lists.hideSheet();

  var width = periods.length + 2;
  var headerRow = 15, totalRow = 16, firstRow = 17;
  if (explorer.getMaxColumns() < width) explorer.insertColumnsAfter(explorer.getMaxColumns(), width - explorer.getMaxColumns());
  if (explorer.getMaxRows() < firstRow + EXPLORER_ROWS_) {
    explorer.insertRowsAfter(explorer.getMaxRows(), firstRow + EXPLORER_ROWS_ - explorer.getMaxRows());
  }

  explorer.getRange(1, 1).setValue('Vendor explorer: pick a GL account, then any vendors (leave them blank for all). Totals update automatically.')
    .setFontWeight('bold');
  explorer.getRange(3, 1, 2, 1).setValues([['GL account'], ['Vendors']]).setFontWeight('bold');
  explorer.getRange(3, 2).setDataValidation(SpreadsheetApp.newDataValidation()
    .requireValueInRange(lists.getRange('A2:A1000'), true).setAllowInvalid(false).build());
  explorer.getRange(4, 2, EXPLORER_VENDOR_SLOTS_, 1).setDataValidation(SpreadsheetApp.newDataValidation()
    .requireValueInRange(lists.getRange('B2:B2000'), true).setAllowInvalid(true).build());
  explorer.getRange(3, 2, 1 + EXPLORER_VENDOR_SLOTS_, 1).setBackground('#e8f0fe');
  if (picked) explorer.getRange(3, 2, picked.length, 1).setValues(picked);

  var header = ['Vendor'].concat(periods.map(function (p) { return p.label; })).concat(['Total']);
  // Text format first, so month labels like "Sep 2026" stay text and match the detail tab.
  explorer.getRange(headerRow, 1, 1, width).setNumberFormat('@').setValues([header]).setFontWeight('bold').setBackground('#f1f3f4');
  explorer.getRange(totalRow, 1).setValue('Selected total').setFontWeight('bold');
  explorer.getRange(totalRow, 2, 1, width - 1).setFormulaR1C1('=SUM(R[1]C:R[' + EXPLORER_ROWS_ + ']C)').setFontWeight('bold');
  var slots = '$B$4:$B$' + (3 + EXPLORER_VENDOR_SLOTS_);
  explorer.getRange(firstRow, 1).setFormula('=IF($B$3="","",IFERROR(IF(COUNTA(' + slots + ')=0,FILTER(' + L + '!B2:B,' +
    L + '!B2:B<>""),FILTER(' + slots + ',' + slots + '<>"")),""))');
  var C = function (n) { return d + '!C' + n; };
  explorer.getRange(firstRow, 2, EXPLORER_ROWS_, periods.length).setFormulaR1C1(
    '=IF(RC1="","",SUMIFS(' + C(DETAIL_COL_.amount) + ',' + C(DETAIL_COL_.account) + ',R3C2,' + C(DETAIL_COL_.vendor) +
    ',RC1,' + C(DETAIL_COL_.month) + ',R' + headerRow + 'C))');
  explorer.getRange(firstRow, width, EXPLORER_ROWS_, 1).setFormulaR1C1('=IF(RC1="","",SUM(RC2:RC[-1]))');
  explorer.getRange(totalRow, 2, EXPLORER_ROWS_ + 1, width - 1).setNumberFormat(NUMBER_FORMATS_.number);
  explorer.setFrozenRows(headerRow);
  explorer.setColumnWidth(1, 260);
}
