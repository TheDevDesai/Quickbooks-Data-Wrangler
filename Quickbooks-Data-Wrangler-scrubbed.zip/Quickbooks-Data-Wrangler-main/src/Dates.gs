/**
 * Date-range resolution. Pure functions (no Apps Script services) so they
 * can be unit tested in Node.
 */

/**
 * Resolves a date preset to concrete dates.
 * @param {Object} range {preset, start, end} as stored on a pull.
 * @param {string} today 'yyyy-MM-dd' in the spreadsheet's timezone.
 * @param {number=} fiscalStartMonth 1-12, first month of the fiscal year.
 * @return {{start: string, end: string}} 'yyyy-MM-dd' strings ('' if unbounded).
 */
function resolveDateRange(range, today, fiscalStartMonth) {
  range = range || {};
  var preset = range.preset || 'this_month';
  var t = parseYmd_(today);
  var fsm = fiscalStartMonth || 1;
  var qStart = Math.floor((t.m - 1) / 3) * 3 + 1;
  var fyStartYear = t.m >= fsm ? t.y : t.y - 1;

  switch (preset) {
    case 'custom':
      if (!range.start || !range.end) throw new Error('Custom date range needs a start and end date.');
      if (range.start > range.end) throw new Error('Start date is after end date.');
      return { start: range.start, end: range.end };
    case 'this_month':
      return span_(t.y, t.m, 1);
    case 'this_month_to_date':
      return { start: ymd_(t.y, t.m, 1), end: today };
    case 'last_month':
      return span_(t.y, t.m - 1, 1);
    case 'this_quarter':
      return span_(t.y, qStart, 3);
    case 'this_quarter_to_date':
      return { start: ymd_(t.y, qStart, 1), end: today };
    case 'last_quarter':
      return span_(t.y, qStart - 3, 3);
    case 'this_year':
      return span_(t.y, 1, 12);
    case 'this_year_to_date':
      return { start: ymd_(t.y, 1, 1), end: today };
    case 'last_year':
      return span_(t.y - 1, 1, 12);
    case 'this_fiscal_year':
      return span_(fyStartYear, fsm, 12);
    case 'this_fiscal_year_to_date':
      return { start: span_(fyStartYear, fsm, 12).start, end: today };
    case 'last_fiscal_year':
      return span_(fyStartYear - 1, fsm, 12);
    case 'last_12_months':
      return span_(t.y, t.m - 12, 12);
    case 'trailing_12_months':
      return { start: span_(t.y, t.m - 11, 1).start, end: today };
    case 'all_dates':
      return { start: '', end: '' };
    default:
      throw new Error('Unknown date preset: ' + preset);
  }
}

/** First day of (year, month) through the last day of month + count - 1. Months may overflow. */
function span_(year, month, count) {
  var s = normMonth_(year, month);
  var e = normMonth_(year, month + count - 1);
  return { start: ymd_(s.y, s.m, 1), end: ymd_(e.y, e.m, daysInMonth_(e.y, e.m)) };
}

function normMonth_(year, month) {
  var idx = year * 12 + (month - 1);
  return { y: Math.floor(idx / 12), m: (idx % 12 + 12) % 12 + 1 };
}

function daysInMonth_(y, m) {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

function parseYmd_(s) {
  var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  if (!match) throw new Error('Expected a yyyy-MM-dd date, got: ' + s);
  return { y: +match[1], m: +match[2], d: +match[3] };
}

function ymd_(y, m, d) {
  return y + '-' + (m < 10 ? '0' : '') + m + '-' + (d < 10 ? '0' : '') + d;
}

var MONTH_NAMES_ = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

/** Converts QuickBooks' FirstMonthOfFiscalYear ("January") to 1-12. */
function monthNameToNumber_(name) {
  var i = MONTH_NAMES_.indexOf(String(name || ''));
  return i === -1 ? 1 : i + 1;
}

/** Adds days to a 'yyyy-MM-dd' date. */
function addDays_(s, days) {
  var t = parseYmd_(s);
  var d = new Date(Date.UTC(t.y, t.m - 1, t.d + days));
  return ymd_(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
}

/** First day of the fiscal year containing the date. */
function fiscalYearStart_(s, fiscalStartMonth) {
  var t = parseYmd_(s);
  var fsm = fiscalStartMonth || 1;
  return ymd_(t.m >= fsm ? t.y : t.y - 1, fsm, 1);
}

var PERIOD_MONTHS_ = { Month: 1, Quarter: 3, Year: 12 };
var MONTH_ABBR_ = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Splits a date range into calendar periods (clipped to the range).
 * Quarters and years follow the fiscal calendar.
 * @param {string} frequency 'Month' | 'Quarter' | 'Year' | 'Total'
 * @return {{label: string, start: string, end: string, fiscalYearStart: boolean}[]}
 */
function buildPeriods_(start, end, frequency, fiscalStartMonth) {
  var fsm = fiscalStartMonth || 1;
  var isFyStart = function (d) { return fiscalYearStart_(d, fsm) === d; };
  if (!start || !end) throw new Error('A roll forward needs a start and end date.');
  if (frequency === 'Total' || !PERIOD_MONTHS_[frequency]) {
    return [{ label: start + ' to ' + end, start: start, end: end, fiscalYearStart: isFyStart(start) }];
  }
  var size = PERIOD_MONTHS_[frequency];
  var s = parseYmd_(start);
  // Align period boundaries to the fiscal calendar: months since the fiscal year's first month.
  var offset = ((s.m - fsm) % size + size) % size;
  var cursorIdx = s.y * 12 + (s.m - 1) - offset;
  var periods = [];
  var pStart = start;
  while (pStart <= end) {
    var nextIdx = cursorIdx + size;
    var nextStart = ymd_(Math.floor(nextIdx / 12), nextIdx % 12 + 1, 1);
    var pEnd = addDays_(nextStart, -1);
    if (pEnd > end) pEnd = end;
    periods.push({ label: periodLabel_(cursorIdx, frequency, fsm), start: pStart, end: pEnd, fiscalYearStart: isFyStart(pStart) });
    cursorIdx = nextIdx;
    pStart = nextStart;
  }
  return periods;
}

function periodLabel_(monthIdx, frequency, fsm) {
  var y = Math.floor(monthIdx / 12), m = monthIdx % 12 + 1;
  if (frequency === 'Month') return MONTH_ABBR_[m - 1] + ' ' + y;
  // Fiscal years are named by the calendar year they end in (FY ending June 2026 = FY2026).
  var fyEndYear = fsm === 1 ? y : (m >= fsm ? y + 1 : y);
  if (frequency === 'Year') return 'FY' + fyEndYear;
  var q = Math.floor((((m - fsm) % 12 + 12) % 12) / 3) + 1;
  return (fsm === 1 ? '' : 'FY') + (fsm === 1 ? y : fyEndYear) + ' Q' + q;
}
