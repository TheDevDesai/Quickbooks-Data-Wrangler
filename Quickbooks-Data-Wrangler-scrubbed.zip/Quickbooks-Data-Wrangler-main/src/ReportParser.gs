/**
 * Turns QuickBooks Reports API JSON into tables. Pure functions (no Apps
 * Script services) so they can be unit tested in Node.
 *
 * QuickBooks reports are trees: a Section row has an optional Header,
 * nested Rows and an optional Summary (the "Total for ..." line); a Data
 * row has ColData. Three output layouts are supported:
 *
 *   report - looks like the QuickBooks report: indented names, section
 *            headers and totals. Good for reading and presenting.
 *   table  - one row per data line with Level 1..N columns holding the
 *            section path. No subtotals, so it is safe to SUM / pivot.
 *   long   - "unpivoted" table: one row per data line per period/column.
 *            Ideal for pivot tables and lookups across many periods.
 *
 * Every layout returns {header: string[], rows: any[][], types: string[],
 * rowKinds: string[], title: string[]} where types are 'text' | 'number' |
 * 'date' per column and values are raw strings or numbers.
 */

/** Walks the report tree into a flat list of {kind, depth, path, cells}. */
function walkReport_(report) {
  var out = [];
  function walk(rows, depth, path) {
    (rows || []).forEach(function (row) {
      if (row.ColData && !row.Header && !row.Rows && !row.Summary) {
        out.push({ kind: 'data', depth: depth, path: path, cells: row.ColData });
        return;
      }
      var name = row.Header && row.Header.ColData && row.Header.ColData[0]
        ? String(row.Header.ColData[0].value || '')
        : '';
      if (row.Header) out.push({ kind: 'header', depth: depth, path: path, cells: row.Header.ColData || [] });
      var childPath = path.concat([name || humanizeGroup_(row.group)]);
      if (row.Rows && row.Rows.Row) walk(row.Rows.Row, depth + 1, childPath);
      if (row.Summary) out.push({ kind: 'summary', depth: depth, path: path, cells: row.Summary.ColData || [], group: row.group, name: name });
    });
  }
  walk(report && report.Rows && report.Rows.Row, 0, []);
  return out;
}

/** "GrossProfit" -> "Gross Profit" */
function humanizeGroup_(group) {
  return String(group || '').replace(/([a-z])([A-Z])/g, '$1 $2');
}

/** Column definitions: [{title, colType, key, startDate, endDate}] */
function reportColumns_(report) {
  var cols = (report && report.Columns && report.Columns.Column) || [];
  return cols.map(function (c, i) {
    var meta = {};
    (c.MetaData || []).forEach(function (m) { meta[m.Name] = m.Value; });
    var title = c.ColTitle || (c.ColType === 'Account' ? 'Account' : '') || (i === 0 ? 'Name' : 'Column ' + (i + 1));
    return { title: title, colType: c.ColType || '', key: meta.ColKey || '', startDate: meta.StartDate || '', endDate: meta.EndDate || '' };
  });
}

var NUMERIC_RE_ = /^-?\d+(\.\d+)?$/;
var DATE_RE_ = /^\d{4}-\d{2}-\d{2}$/;
var NUMBER_COL_TYPES_ = { Money: 1, Number: 1, Amount: 1, Percent: 1, Quantity: 1, Rate: 1 };
var TEXT_COL_TYPES_ = { Account: 1, String: 1, Customer: 1, Vendor: 1, Employee: 1, ProductsAndService: 1, Department: 1, Class: 1 };

/** Picks 'number' | 'date' | 'text' for each column from its type and the values seen. */
function inferColumnTypes_(columns, entries) {
  return columns.map(function (col, i) {
    if (NUMBER_COL_TYPES_[col.colType]) return 'number';
    if (col.colType === 'Date') return 'date';
    if (TEXT_COL_TYPES_[col.colType] || i === 0) return 'text';
    var seen = 0, numeric = 0, dates = 0;
    entries.forEach(function (e) {
      var v = e.cells[i] && e.cells[i].value;
      if (v === undefined || v === null || v === '') return;
      seen++;
      if (NUMERIC_RE_.test(v)) numeric++;
      else if (DATE_RE_.test(v)) dates++;
    });
    if (seen && numeric === seen) return 'number';
    if (seen && dates === seen) return 'date';
    return 'text';
  });
}

function cellValue_(cells, i, type) {
  var v = cells[i] ? cells[i].value : '';
  if (v === undefined || v === null) v = '';
  if (type === 'number' && v !== '' && NUMERIC_RE_.test(v)) return Number(v);
  return v;
}

/** Title lines (report name, company, period) from the report header. */
function reportTitle_(report, companyName) {
  var h = (report && report.Header) || {};
  var lines = [h.ReportName ? humanizeGroup_(h.ReportName) : 'Report'];
  if (companyName) lines.push(companyName);
  if (h.StartPeriod && h.EndPeriod) lines.push(h.StartPeriod + ' to ' + h.EndPeriod);
  else if (h.EndPeriod) lines.push('As of ' + h.EndPeriod);
  var basis = h.ReportBasis ? h.ReportBasis + ' basis' : '';
  if (basis) lines.push(basis);
  return lines;
}

/** True when a section header row carries amounts (a parent account with its own postings). */
function headerHasAmounts_(entry, types) {
  for (var i = 1; i < types.length; i++) {
    var v = entry.cells[i] && entry.cells[i].value;
    if (types[i] === 'number' && v !== undefined && v !== '' && NUMERIC_RE_.test(v)) return true;
  }
  return false;
}

/** Columns that carry QuickBooks ids on data rows (e.g. account id, transaction id). */
function idColumns_(entries, columnCount) {
  var has = [];
  for (var i = 0; i < columnCount; i++) has.push(false);
  entries.forEach(function (e) {
    if (e.kind !== 'data') return;
    e.cells.forEach(function (c, i) { if (i < columnCount && c && c.id) has[i] = true; });
  });
  return has;
}

/**
 * @param {Object} report Raw QuickBooks report JSON.
 * @param {string} layout 'report' | 'table' | 'long'
 * @param {Object=} opts {companyName, includeIds (default true)}
 */
function flattenReport(report, layout, opts) {
  opts = opts || {};
  var columns = reportColumns_(report);
  var entries = walkReport_(report);
  var types = inferColumnTypes_(columns, entries.filter(function (e) { return e.kind === 'data'; }));
  var title = reportTitle_(report, opts.companyName);
  if (layout === 'report') return reportLayout_(columns, entries, types, title);
  if (layout === 'long') return longLayout_(columns, entries, types, title, opts);
  return tableLayout_(columns, entries, types, title, opts);
}

function reportLayout_(columns, entries, types, title) {
  var rows = [], rowKinds = [];
  entries.forEach(function (e) {
    var row = columns.map(function (c, i) { return cellValue_(e.cells, i, types[i]); });
    var label = String(row[0] === undefined ? '' : row[0]);
    if (e.kind === 'summary' && !label) label = e.name ? 'Total ' + e.name : humanizeGroup_(e.group);
    row[0] = new Array(e.depth + 1).join('    ') + label;
    rows.push(row);
    rowKinds.push(e.kind);
  });
  return {
    header: columns.map(function (c) { return c.title; }),
    rows: rows, types: types, rowKinds: rowKinds, title: title
  };
}

/** Rows that represent real lines of data (no subtotals). */
function dataEntries_(entries, types) {
  return entries.filter(function (e) {
    return e.kind === 'data' || (e.kind === 'header' && headerHasAmounts_(e, types));
  });
}

function maxDepth_(entries) {
  return entries.reduce(function (m, e) { return Math.max(m, e.path.length); }, 0);
}

function levelHeaders_(depth) {
  var h = [];
  for (var i = 1; i <= depth; i++) h.push('Level ' + i);
  return h;
}

function pathCells_(path, depth) {
  var out = [];
  for (var i = 0; i < depth; i++) out.push(path[i] || '');
  return out;
}

function tableLayout_(columns, entries, types, title, opts) {
  var data = dataEntries_(entries, types);
  var depth = maxDepth_(data);
  var ids = opts.includeIds === false ? [] : idColumns_(data, columns.length);
  var header = levelHeaders_(depth), outTypes = header.map(function () { return 'text'; });
  columns.forEach(function (c, i) {
    header.push(c.title); outTypes.push(types[i]);
    if (ids[i]) { header.push(c.title + ' ID'); outTypes.push('text'); }
  });
  var rows = data.map(function (e) {
    var row = pathCells_(e.path, depth);
    columns.forEach(function (c, i) {
      row.push(cellValue_(e.cells, i, types[i]));
      if (ids[i]) row.push(e.cells[i] && e.cells[i].id ? String(e.cells[i].id) : '');
    });
    return row;
  });
  return { header: header, rows: rows, types: outTypes, rowKinds: rows.map(function () { return 'data'; }), title: title };
}

function longLayout_(columns, entries, types, title, opts) {
  var data = dataEntries_(entries, types);
  var depth = maxDepth_(data);
  var ids = opts.includeIds === false ? [] : idColumns_(data, columns.length);
  // Dimension columns are the non-numeric ones; value columns are numeric, minus the Total column.
  var dims = [], values = [];
  columns.forEach(function (c, i) {
    if (types[i] !== 'number') dims.push(i);
    else if (c.key !== 'total' && c.title !== 'Total') values.push(i);
  });
  if (!values.length) columns.forEach(function (c, i) { if (types[i] === 'number') values.push(i); });
  var hasPeriods = values.some(function (i) { return columns[i].startDate || columns[i].endDate; });

  var header = levelHeaders_(depth), outTypes = header.map(function () { return 'text'; });
  dims.forEach(function (i) {
    header.push(columns[i].title); outTypes.push(types[i]);
    if (ids[i]) { header.push(columns[i].title + ' ID'); outTypes.push('text'); }
  });
  header.push('Column'); outTypes.push('text');
  if (hasPeriods) { header.push('Period Start', 'Period End'); outTypes.push('date', 'date'); }
  header.push('Value'); outTypes.push('number');

  var rows = [];
  data.forEach(function (e) {
    var base = pathCells_(e.path, depth);
    dims.forEach(function (i) {
      base.push(cellValue_(e.cells, i, types[i]));
      if (ids[i]) base.push(e.cells[i] && e.cells[i].id ? String(e.cells[i].id) : '');
    });
    values.forEach(function (i) {
      var v = cellValue_(e.cells, i, 'number');
      if (v === '' || v === 0) return; // long format omits empty cells
      var row = base.concat([columns[i].title]);
      if (hasPeriods) row.push(columns[i].startDate, columns[i].endDate);
      row.push(v);
      rows.push(row);
    });
  });
  return { header: header, rows: rows, types: outTypes, rowKinds: rows.map(function () { return 'data'; }), title: title };
}

/**
 * Keeps only the chosen accounts (and their sub-accounts) in a summary
 * report such as the P&L or Balance Sheet, which QuickBooks cannot filter by
 * account itself. Section totals are recalculated from what is kept, and
 * derived lines with no accounts under them (Gross Profit, Net Income) are
 * dropped because they would no longer mean what their label says.
 * Returns a new report object; the input is not modified.
 * @param {Object} report Raw QuickBooks report JSON.
 * @param {string[]} accountIds Accounts to keep.
 */
function filterReportByAccounts(report, accountIds) {
  var wanted = {};
  (accountIds || []).forEach(function (id) { wanted[String(id)] = true; });
  var out = JSON.parse(JSON.stringify(report || {}));
  if (!out.Rows || !out.Rows.Row) return out;
  var width = ((out.Columns && out.Columns.Column) || []).length;

  function amounts(cells) {
    var sums = [];
    for (var i = 1; i < width; i++) {
      var v = cells && cells[i] && cells[i].value;
      sums.push(v !== undefined && v !== '' && NUMERIC_RE_.test(v) ? Number(v) : null);
    }
    return sums;
  }
  function add(total, part) {
    part.forEach(function (v, i) { if (v !== null) total[i] = (total[i] || 0) + v; });
  }

  // Returns {rows, totals} where totals are the kept amounts per numeric column.
  function filter(rows, selected) {
    var kept = [], totals = [];
    (rows || []).forEach(function (row) {
      var isSection = row.Header || row.Rows || row.Summary;
      if (!isSection) {
        var id = row.ColData && row.ColData[0] && row.ColData[0].id;
        if (selected || (id && wanted[String(id)])) {
          kept.push(row);
          add(totals, amounts(row.ColData));
        }
        return;
      }
      var headerId = row.Header && row.Header.ColData && row.Header.ColData[0] && row.Header.ColData[0].id;
      var sel = selected || !!(headerId && wanted[String(headerId)]);
      var child = filter(row.Rows && row.Rows.Row, sel);
      var ownAmounts = row.Header ? amounts(row.Header.ColData) : [];
      var keepsOwn = sel && ownAmounts.some(function (v) { return v !== null; });
      if (!child.rows.length && !keepsOwn) return;
      if (row.Header && !keepsOwn) {
        // A parent account's own postings only count when the parent itself was chosen.
        row.Header.ColData.forEach(function (c, i) { if (i > 0 && NUMERIC_RE_.test(c.value || '')) c.value = ''; });
      }
      var sectionTotal = child.totals.slice();
      if (keepsOwn) add(sectionTotal, ownAmounts);
      if (row.Rows) row.Rows.Row = child.rows;
      if (row.Summary && row.Summary.ColData) {
        row.Summary.ColData.forEach(function (c, i) {
          if (i > 0) c.value = sectionTotal[i - 1] === undefined || sectionTotal[i - 1] === null ? '' : sectionTotal[i - 1].toFixed(2);
        });
      }
      kept.push(row);
      add(totals, sectionTotal);
    });
    return { rows: kept, totals: totals };
  }

  out.Rows.Row = filter(out.Rows.Row, false).rows;
  return out;
}
