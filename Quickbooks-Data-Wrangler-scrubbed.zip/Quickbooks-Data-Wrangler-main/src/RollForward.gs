/**
 * Roll forward schedules: Beginning balance + increases - decreases = Ending
 * balance, per period, by GL account, bank/credit card account, customer
 * (A/R) or vendor (A/P).
 *
 * Sources (one consistent method for every dimension):
 *   Beginning balance of the first period
 *     accounts            -> Trial Balance as of the day before the start
 *     customers / vendors -> Customer / Vendor Balance as of the day before
 *   Activity in each period -> General Ledger debits and credits for that period
 *                              (A/R or A/P accounts only, grouped by name, for
 *                              customers / vendors)
 *   Later beginnings        -> previous period's ending balance
 *
 * The final computed ending balance is checked against QuickBooks' own
 * balance as of the end date and any differences are reported.
 *
 * Accounts use debit-positive balances (credit balances are negative), as on
 * a trial balance. Customers are shown as amounts owed to you and vendors as
 * amounts you owe, both positive.
 *
 * For accounts, income and expense balances close to Retained Earnings at the
 * start of each fiscal year. That shows up in a "Year-end close" column so
 * every row still ties.
 *
 * Basis: accounts use the chosen accounting method throughout (Trial Balance
 * and General Ledger). For customers / vendors, accrual is the A/R or A/P
 * balance roll forward; cash has no receivable or payable, so the cash view
 * rolls forward cash received from each customer (or paid to each vendor)
 * through bank and credit card accounts, fiscal year to date.
 */

var ROLLFORWARD_CATALOG = {
  actuals: {
    label: 'GL actuals by month (group, account, vendor)', filter: 'account', title: 'GL Actuals by Account and Vendor',
    actuals: true
  },
  prepaid: {
    label: 'Prepaid by vendor (opening, additions, amortization, ending)', filter: 'account',
    title: 'Prepaid Roll Forward by Vendor', increase: 'Additions', decrease: 'Amortization'
  },
  account: {
    label: 'GL account', filter: 'account', title: 'General Ledger Roll Forward',
    increase: 'Debits', decrease: 'Credits'
  },
  bank: {
    label: 'Bank & credit card account', filter: 'bankAccount', title: 'Bank & Credit Card Roll Forward',
    increase: 'Debits (Deposits / Refunds)', decrease: 'Credits (Payments / Charges)'
  },
  customer: {
    label: 'Customer (A/R)', filter: 'customer', title: 'Accounts Receivable Roll Forward by Customer',
    increase: 'Charges (Invoices / Debits)', decrease: 'Payments & Credits',
    cash: {
      title: 'Cash Received by Customer', increase: 'Cash Received', decrease: 'Refunds Paid',
      beginning: 'Received Fiscal YTD (Beginning)', ending: 'Received Fiscal YTD (Ending)'
    }
  },
  vendor: {
    label: 'Vendor (A/P)', filter: 'vendor', title: 'Accounts Payable Roll Forward by Vendor',
    increase: 'Bills & Charges (Credits)', decrease: 'Payments & Credits (Debits)',
    cash: {
      title: 'Cash Paid by Vendor', increase: 'Cash Paid', decrease: 'Refunds Received',
      beginning: 'Paid Fiscal YTD (Beginning)', ending: 'Paid Fiscal YTD (Ending)'
    }
  }
};

var ROLLFORWARD_PERIODS = ['Month', 'Quarter', 'Year', 'Total'];
var BANK_ACCOUNT_TYPES_ = { 'Bank': 1, 'Credit Card': 1 };
var PNL_CLASSIFICATIONS_ = { Revenue: 1, Expense: 1 };
var ROUND_ = function (n) { return Math.round(n * 100) / 100; };

// ---------------------------------------------------------------------------
// Report parsing (pure)
// ---------------------------------------------------------------------------

function columnIndexByKey_(report, keys) {
  var cols = reportColumns_(report);
  for (var k = 0; k < keys.length; k++) {
    for (var i = 0; i < cols.length; i++) if (cols[i].key === keys[k]) return i;
  }
  return -1;
}

function num_(cells, i) {
  if (i < 0 || !cells[i]) return 0;
  var v = cells[i].value;
  return v === undefined || v === '' || !NUMERIC_RE_.test(v) ? 0 : Number(v);
}

/**
 * Transaction lines from a General Ledger report.
 * @return {{accountId, accountName, nameId, name, date, debit, credit}[]}
 */
function parseGeneralLedgerLines_(report) {
  var iDate = columnIndexByKey_(report, ['tx_date']);
  var iName = columnIndexByKey_(report, ['name', 'cust_name', 'vend_name']);
  var iType = columnIndexByKey_(report, ['txn_type']);
  var iMemo = columnIndexByKey_(report, ['memo']);
  var iNum = columnIndexByKey_(report, ['doc_num']);
  var iDebit = columnIndexByKey_(report, ['debt_home_amt', 'debt_amt']);
  var iCredit = columnIndexByKey_(report, ['credit_home_amt', 'credit_amt']);
  if (iDebit < 0 || iCredit < 0) {
    if (!(report && report.Rows && report.Rows.Row && report.Rows.Row.length)) return [];
    throw new Error('The General Ledger did not return Debit and Credit columns.');
  }
  var out = [];
  function walk(rows, account) {
    (rows || []).forEach(function (row) {
      if (row.Header || row.Rows) {
        var h = row.Header && row.Header.ColData && row.Header.ColData[0];
        var acct = h ? { id: String(h.id || ''), name: String(h.value || '') } : account;
        walk(row.Rows && row.Rows.Row, acct);
        return;
      }
      if (!row.ColData || row.Summary) return;
      var c = row.ColData;
      var date = iDate >= 0 && c[iDate] ? c[iDate].value : '';
      // Skips "Beginning Balance" and other non-transaction lines.
      if (iDate >= 0 && !DATE_RE_.test(date || '')) return;
      out.push({
        accountId: account ? account.id : '',
        accountName: account ? account.name : '',
        nameId: iName >= 0 && c[iName] && c[iName].id ? String(c[iName].id) : '',
        name: iName >= 0 && c[iName] ? String(c[iName].value || '') : '',
        date: date,
        txnType: iType >= 0 && c[iType] ? String(c[iType].value || '') : '',
        txnId: iType >= 0 && c[iType] && c[iType].id ? String(c[iType].id) : '',
        memo: iMemo >= 0 && c[iMemo] ? String(c[iMemo].value || '') : '',
        docNum: iNum >= 0 && c[iNum] ? String(c[iNum].value || '') : '',
        debit: num_(c, iDebit),
        credit: num_(c, iCredit)
      });
    });
  }
  walk(report && report.Rows && report.Rows.Row, null);
  return out;
}

/**
 * Debit-positive balances by account id from a Trial Balance report.
 * @param {function(string): string=} idForName Resolves an account name when a row has no id.
 */
function parseTrialBalance_(report, idForName) {
  var balances = {};
  walkReport_(report).forEach(function (e) {
    if (e.kind === 'summary') return;
    var first = e.cells[0];
    if (!first) return;
    var id = first.id ? String(first.id) : (idForName && idForName(String(first.value || '')));
    if (!id) return;
    var bal = num_(e.cells, 1) - num_(e.cells, 2);
    balances[id] = ROUND_((balances[id] || 0) + bal);
  });
  return balances;
}

/** Map of every way QuickBooks may print an account name -> account id. */
function accountNameIndex_(accounts) {
  var index = {};
  accounts.forEach(function (a) {
    var id = String(a.Id);
    [a.FullyQualifiedName, a.Name].forEach(function (n) {
      if (!n) return;
      if (!index[n]) index[n] = id;
      if (a.AcctNum && !index[a.AcctNum + ' ' + n]) index[a.AcctNum + ' ' + n] = id;
    });
  });
  return index;
}

/** Balances by customer/vendor id (and name) from a Customer/Vendor Balance report. */
function parseNameBalances_(report) {
  var cols = reportColumns_(report);
  var iTotal = -1;
  cols.forEach(function (c, i) { if (c.key === 'total' || c.title === 'Total') iTotal = i; });
  if (iTotal < 0) iTotal = cols.length - 1;
  var out = {};
  walkReport_(report).forEach(function (e) {
    if (e.kind === 'summary') return;
    var first = e.cells[0];
    if (!first || !first.id) return;
    var amount = num_(e.cells, iTotal);
    if (e.kind === 'header' && !amount) return;
    var id = String(first.id);
    out[id] = { name: String(first.value || ''), balance: ROUND_((out[id] ? out[id].balance : 0) + amount) };
  });
  return out;
}

// ---------------------------------------------------------------------------
// Roll forward computation (pure)
// ---------------------------------------------------------------------------

/**
 * @param {Object} input
 *   entities:   {key: {cols: [...], pnl: bool, retainedEarnings: bool}}
 *   beginning:  {key: number}
 *   periods:    [{label, start, end, fiscalYearStart, activity: {key: {inc, dec}}}]
 *   closeYears: bool (apply fiscal year-end close for income/expense accounts)
 * @return {{key, period, beginning, increases, decreases, close, ending}[][]} per entity key.
 */
function computeRollForward_(input) {
  var keys = {};
  Object.keys(input.entities).forEach(function (k) { keys[k] = true; });
  Object.keys(input.beginning).forEach(function (k) { keys[k] = true; });
  input.periods.forEach(function (p) { Object.keys(p.activity).forEach(function (k) { keys[k] = true; }); });

  var reKey = null;
  Object.keys(input.entities).forEach(function (k) { if (input.entities[k].retainedEarnings) reKey = k; });

  var balance = {};
  Object.keys(keys).forEach(function (k) { balance[k] = input.beginning[k] || 0; });

  var out = {};
  Object.keys(keys).forEach(function (k) { out[k] = []; });

  input.periods.forEach(function (p) {
    var close = {};
    if (input.closeYears && p.fiscalYearStart) {
      var netIncome = 0;
      Object.keys(keys).forEach(function (k) {
        var e = input.entities[k];
        if (e && e.pnl && balance[k]) {
          close[k] = -balance[k];
          netIncome += balance[k];
        }
      });
      if (reKey && netIncome) close[reKey] = (close[reKey] || 0) + netIncome;
    }
    Object.keys(keys).forEach(function (k) {
      var a = p.activity[k] || { inc: 0, dec: 0 };
      var beg = balance[k];
      var c = close[k] || 0;
      var end = ROUND_(beg + c + a.inc - a.dec);
      out[k].push({
        key: k, period: p, beginning: ROUND_(beg), close: ROUND_(c),
        increases: ROUND_(a.inc), decreases: ROUND_(a.dec), ending: end
      });
      balance[k] = end;
    });
  });
  return out;
}

/** Sums GL lines into {key: {inc, dec}} using a key function and sign convention. */
function sumActivity_(lines, keyFn, creditIncreases) {
  var act = {};
  lines.forEach(function (l) {
    var k = keyFn(l);
    if (k === null) return;
    var a = act[k] || (act[k] = { inc: 0, dec: 0 });
    if (creditIncreases) { a.inc += l.credit; a.dec += l.debit; }
    else { a.inc += l.debit; a.dec += l.credit; }
  });
  return act;
}

/**
 * Lays out computed roll forward rows.
 * @param {Object} spec {dimension, layout: 'schedule'|'long', entityHeader: [], entities, results, periods, includeZero, title,
 *   labels: optional {increase, decrease, beginning, ending} overriding the catalog's column names}
 */
function layoutRollForward_(spec) {
  var cat = ROLLFORWARD_CATALOG[spec.dimension];
  var labels = spec.labels || {};
  var def = { increase: labels.increase || cat.increase, decrease: labels.decrease || cat.decrease };
  var BEG = labels.beginning || 'Beginning Balance', END = labels.ending || 'Ending Balance';
  var keys = Object.keys(spec.results).filter(function (k) {
    if (spec.includeZero) return true;
    return spec.results[k].some(function (r) {
      return r.beginning || r.increases || r.decreases || r.close || r.ending;
    });
  });
  keys.sort(function (a, b) {
    var ea = spec.entities[a], eb = spec.entities[b];
    var sa = ea ? ea.sort : 'zzzz' + a, sb = eb ? eb.sort : 'zzzz' + b;
    return sa < sb ? -1 : sa > sb ? 1 : 0;
  });
  var hasClose = keys.some(function (k) { return spec.results[k].some(function (r) { return r.close; }); });
  var entityCols = function (k) {
    var e = spec.entities[k];
    return e ? e.cols.slice() : spec.entityHeader.map(function (h, i) { return i === 0 ? '(Unknown ' + k + ')' : ''; });
  };
  var textTypes = spec.entityHeader.map(function () { return 'text'; });

  if (spec.layout === 'long') {
    var header = spec.entityHeader.concat(['Period', 'Period Start', 'Period End', BEG])
      .concat(hasClose ? ['Year-end Close'] : [])
      .concat([def.increase, def.decrease, 'Net Change', END]);
    var types = textTypes.concat(['text', 'date', 'date', 'number'])
      .concat(hasClose ? ['number'] : []).concat(['number', 'number', 'number', 'number']);
    var rows = [];
    keys.forEach(function (k) {
      spec.results[k].forEach(function (r) {
        rows.push(entityCols(k).concat([r.period.label, r.period.start, r.period.end, r.beginning])
          .concat(hasClose ? [r.close] : [])
          .concat([r.increases, r.decreases, ROUND_(r.increases - r.decreases), r.ending]));
      });
    });
    return { header: header, rows: rows, types: types, rowKinds: rows.map(function () { return 'data'; }), title: spec.title };
  }

  // Schedule: one row per entity. Single period -> Beginning | Increases | Decreases | Ending.
  // Multiple periods -> Beginning | net change per period | totals | Ending.
  var multi = spec.periods.length > 1;
  var header2 = spec.entityHeader.concat([BEG]);
  if (hasClose) header2.push('Year-end Close');
  if (multi) spec.periods.forEach(function (p) { header2.push(p.label + ' Net Change'); });
  header2.push(def.increase, def.decrease, END);
  var types2 = textTypes.concat(header2.slice(spec.entityHeader.length).map(function () { return 'number'; }));

  var rows2 = keys.map(function (k) {
    var rs = spec.results[k];
    var row = entityCols(k).concat([rs[0].beginning]);
    var inc = 0, dec = 0, close = 0;
    rs.forEach(function (r) { inc += r.increases; dec += r.decreases; close += r.close; });
    if (hasClose) row.push(ROUND_(close));
    if (multi) rs.forEach(function (r) { row.push(ROUND_(r.increases - r.decreases)); });
    row.push(ROUND_(inc), ROUND_(dec), rs[rs.length - 1].ending);
    return row;
  });
  var kinds = rows2.map(function () { return 'data'; });
  if (rows2.length) {
    var n = spec.entityHeader.length;
    var total = spec.entityHeader.map(function (h, i) { return i === 0 ? 'Total' : ''; });
    for (var c = n; c < header2.length; c++) {
      total.push(ROUND_(rows2.reduce(function (s, r) { return s + (Number(r[c]) || 0); }, 0)));
    }
    rows2.push(total);
    kinds.push('summary');
  }
  return { header: header2, rows: rows2, types: types2, rowKinds: kinds, title: spec.title };
}

/** Compares computed ending balances with QuickBooks' own; returns readable differences. */
function reconcileEndings_(results, actual, describe) {
  var diffs = [];
  var keys = {};
  Object.keys(results).forEach(function (k) { keys[k] = true; });
  Object.keys(actual).forEach(function (k) { keys[k] = true; });
  Object.keys(keys).forEach(function (k) {
    var rs = results[k];
    var computed = rs && rs.length ? rs[rs.length - 1].ending : 0;
    var expected = actual[k] || 0;
    if (Math.abs(computed - expected) >= 0.01) {
      diffs.push(describe(k) + ': roll forward ' + computed.toFixed(2) + ' vs QuickBooks ' + expected.toFixed(2));
    }
  });
  return diffs;
}

// ---------------------------------------------------------------------------
// QuickBooks orchestration
// ---------------------------------------------------------------------------

// Apps Script refuses request URLs over about 2,000 characters, so long account
// lists are sent in batches. Budget for the encoded list in one request.
var MAX_ACCOUNT_PARAM_CHARS_ = 1200;

/**
 * Splits account IDs into batches whose encoded "account" parameter stays
 * under the URL budget. A parent account and its sub-accounts always share a
 * batch, so a report that includes sub-accounts under their parent can never
 * return the same line in two batches.
 * @param {string[]} ids Account IDs to request.
 * @param {Object[]} allAccounts QuickBooks Account objects (for ParentRef).
 */
function chunkAccountIds_(ids, allAccounts, maxChars) {
  maxChars = maxChars || MAX_ACCOUNT_PARAM_CHARS_;
  var parentOf = {};
  (allAccounts || []).forEach(function (a) {
    if (a.ParentRef && a.ParentRef.value) parentOf[String(a.Id)] = String(a.ParentRef.value);
  });
  var root = function (id) {
    var seen = {};
    while (parentOf[id] && !seen[id]) { seen[id] = true; id = parentOf[id]; }
    return id;
  };
  var families = {}, order = [];
  ids.forEach(function (id) {
    var r = root(String(id));
    if (!families[r]) { families[r] = []; order.push(r); }
    families[r].push(String(id));
  });
  var cost = function (id) { return encodeURIComponent(id).length + 3; }; // + encoded comma
  var chunks = [], current = [], used = 0;
  order.forEach(function (r) {
    var fam = families[r];
    var famCost = fam.reduce(function (s, id) { return s + cost(id); }, 0);
    if (current.length && used + famCost > maxChars) { chunks.push(current); current = []; used = 0; }
    current = current.concat(fam);
    used += famCost;
  });
  if (current.length) chunks.push(current);
  return chunks;
}

/** General Ledger lines for the given accounts (null = all), batching long account lists. */
function fetchGeneralLedgerLines_(realmId, params, accountIds, allAccounts) {
  if (!accountIds) return parseGeneralLedgerLines_(qboReport_(realmId, 'GeneralLedger', params));
  var lines = [];
  chunkAccountIds_(accountIds, allAccounts).forEach(function (chunk) {
    var p = {};
    Object.keys(params).forEach(function (k) { p[k] = params[k]; });
    p.account = chunk.join(',');
    Array.prototype.push.apply(lines, parseGeneralLedgerLines_(qboReport_(realmId, 'GeneralLedger', p)));
  });
  return lines;
}

/**
 * Builds a roll forward for a pull. Returns a writer result plus `warning`.
 * @param {Object} pull Saved pull with source 'rollforward'.
 * @param {{start, end}} range Resolved date range.
 * @param {Object} conn Connection record (companyName, fiscalStartMonth).
 */
function buildRollForward_(pull, range, conn) {
  if (pull.rollforwardBy === 'actuals') return buildActuals_(pull, range, conn);
  if (pull.rollforwardBy === 'prepaid') return buildPrepaidRollForward_(pull, range, conn);
  var dim = pull.rollforwardBy;
  var def = ROLLFORWARD_CATALOG[dim];
  var fsm = conn.fiscalStartMonth || 1;
  var realmId = pull.realmId;
  var periods = buildPeriods_(range.start, range.end, pull.period || 'Month', fsm);
  var dayBefore = addDays_(range.start, -1);
  var isAccounts = dim === 'account' || dim === 'bank';
  var method = pull.accountingMethod || (isAccounts ? '' : 'Accrual');
  var cashNames = !isAccounts && method === 'Cash';
  var isCustomer = dim === 'customer';
  var selected = (pull.filters && pull.filters[def.filter]) || [];
  var selectedSet = {};
  selected.forEach(function (id) { selectedSet[id] = true; });

  var accounts = qboQueryAll_(realmId, 'Account', 'SELECT * FROM Account WHERE Active IN (true, false)');
  var accountIndex = accountNameIndex_(accounts);
  var accountIdOf = function (name) { return accountIndex[name] || ''; };
  var glAccountIds = null; // null = all accounts
  if (dim === 'bank' || cashNames) {
    glAccountIds = accounts.filter(function (a) { return BANK_ACCOUNT_TYPES_[a.AccountType]; }).map(function (a) { return String(a.Id); });
    if (dim === 'bank' && selected.length) glAccountIds = glAccountIds.filter(function (id) { return selectedSet[id]; });
  } else if (dim === 'account' && selected.length) {
    glAccountIds = selected;
  } else if (dim === 'customer' || dim === 'vendor') {
    var arap = isCustomer ? 'Accounts Receivable' : 'Accounts Payable';
    glAccountIds = accounts.filter(function (a) { return a.AccountType === arap; }).map(function (a) { return String(a.Id); });
  }
  if (glAccountIds && !glAccountIds.length) {
    throw new Error(dim === 'bank' ? 'No bank or credit card accounts found.' : 'No matching accounts found in QuickBooks.');
  }

  // The cash view reads bank lines, where the generic Name column could be any name type;
  // the customer / vendor columns keep customers and vendors apart.
  var nameColumn = cashNames ? (isCustomer ? 'cust_name' : 'vend_name') : 'name';
  var glColumns = 'tx_date,' + nameColumn + ',' +
    (companyUsesMultiCurrency_(realmId) ? 'debt_home_amt,credit_home_amt' : 'debt_amt,credit_amt');
  var fetchGl = function (start, end) {
    var params = { start_date: start, end_date: end, columns: glColumns };
    if (method) params.accounting_method = method;
    return fetchGeneralLedgerLines_(realmId, params, glAccountIds, accounts).map(function (l) {
      if (!l.accountId) l.accountId = accountIdOf(l.accountName);
      return l;
    });
  };
  var periodLines = periods.map(function (p) { return fetchGl(p.start, p.end); });

  var entities = {}, entityHeader, beginning, actualEnding, keyFn, creditIncreases = false;

  if (isAccounts) {
    entityHeader = ['Account Number', 'Account', 'Account Type', 'Account ID'];
    var keep = function (id) { return !glAccountIds || glAccountIds.indexOf(id) !== -1; };
    accounts.forEach(function (a) {
      var id = String(a.Id);
      if (!keep(id)) return;
      entities[id] = {
        cols: [a.AcctNum || '', a.FullyQualifiedName || a.Name, a.AccountType || '', id],
        sort: (a.AcctNum ? '0' + padSort_(a.AcctNum) : '1') + (a.FullyQualifiedName || a.Name || '').toLowerCase(),
        pnl: !!PNL_CLASSIFICATIONS_[a.Classification],
        retainedEarnings: a.AccountSubType === 'RetainedEarnings'
      };
    });
    var tb = function (asOf) {
      var params = { start_date: fiscalYearStart_(asOf, fsm), end_date: asOf };
      if (method) params.accounting_method = method;
      var all = parseTrialBalance_(qboReport_(realmId, 'TrialBalance', params), accountIdOf);
      var out = {};
      Object.keys(all).forEach(function (id) { if (keep(id)) out[id] = all[id]; });
      return out;
    };
    beginning = tb(dayBefore);
    actualEnding = tb(range.end);
    keyFn = function (l) { return l.accountId && keep(l.accountId) ? l.accountId : null; };
  } else {
    // Customers: debits increase (A/R charges, or cash deposited). Vendors: credits increase
    // (A/P bills, or cash / card paid out).
    creditIncreases = !isCustomer;
    entityHeader = [isCustomer ? 'Customer' : 'Vendor', isCustomer ? 'Customer ID' : 'Vendor ID'];
    var entity = isCustomer ? 'Customer' : 'Vendor';
    var byName = {};
    qboQueryAll_(realmId, entity, 'SELECT * FROM ' + entity + ' WHERE Active IN (true, false)').forEach(function (r) {
      var id = String(r.Id);
      var name = r.FullyQualifiedName || r.DisplayName || id;
      entities[id] = { cols: [name, id], sort: name.toLowerCase(), pnl: cashNames };
      byName[name] = id;
      if (r.DisplayName) byName[r.DisplayName] = byName[r.DisplayName] || id;
    });
    var balances = function (asOf) {
      var report = qboReport_(realmId, isCustomer ? 'CustomerBalance' : 'VendorBalance',
        { report_date: asOf, accounting_method: 'Accrual' });
      var parsed = parseNameBalances_(report), out = {};
      Object.keys(parsed).forEach(function (id) { out[id] = parsed[id].balance; });
      return out;
    };
    keyFn = function (l) {
      if (cashNames && !l.name) return null; // transfers, bank fees, etc.
      return l.nameId || byName[l.name] || (l.name ? 'name:' + l.name : '(no name)');
    };
    if (cashNames) {
      // Fiscal year-to-date cash before the start date; there is no balance to tie out to.
      var fyStart = fiscalYearStart_(range.start, fsm);
      beginning = {};
      if (fyStart < range.start) {
        var ytd = sumActivity_(fetchGl(fyStart, dayBefore), keyFn, creditIncreases);
        Object.keys(ytd).forEach(function (k) { beginning[k] = ROUND_(ytd[k].inc - ytd[k].dec); });
      }
      actualEnding = null;
    } else {
      beginning = balances(dayBefore);
      actualEnding = balances(range.end);
    }
    if (selected.length) {
      var only = function (map) {
        var out = {};
        Object.keys(map).forEach(function (k) { if (selectedSet[k]) out[k] = map[k]; });
        return out;
      };
      beginning = only(beginning);
      if (actualEnding) actualEnding = only(actualEnding);
      var baseKey = keyFn;
      keyFn = function (l) { var k = baseKey(l); return selectedSet[k] ? k : null; };
    }
    // Names that appear only in the GL (no list record) still get a readable row.
    periodLines.forEach(function (lines) {
      lines.forEach(function (l) {
        var k = keyFn(l);
        if (k && !entities[k]) entities[k] = { cols: [l.name || '(No name)', l.nameId || ''], sort: (l.name || '').toLowerCase(), pnl: cashNames };
      });
    });
  }

  periods.forEach(function (p, i) { p.activity = sumActivity_(periodLines[i], keyFn, creditIncreases); });
  // Income/expense accounts (and fiscal-YTD cash totals) reset at each fiscal year start;
  // Retained Earnings picks up the offset only when it is part of the pull.
  var results = computeRollForward_({ entities: entities, beginning: beginning, periods: periods, closeYears: isAccounts || cashNames });

  var diffs = actualEnding ? reconcileEndings_(results, actualEnding, function (k) {
    return entities[k] ? entities[k].cols[isAccounts ? 1 : 0] : k;
  }) : [];

  var title = [cashNames ? def.cash.title : def.title, conn.companyName, range.start + ' to ' + range.end,
    (method || 'Company default') + ' basis' +
    (isAccounts ? ' - balances shown as debit (+) / credit (-)' : '') +
    (cashNames ? ' - cash through bank and credit card accounts' : '')];
  var result = layoutRollForward_({
    dimension: dim, layout: pull.layout, entityHeader: entityHeader, entities: entities,
    results: results, periods: periods, includeZero: !!pull.includeZero, title: title,
    labels: cashNames ? def.cash : null
  });
  result.warning = diffs.length
    ? diffs.length + ' ending balance(s) differ from QuickBooks (often transactions dated in the future or edited during the pull): ' +
      diffs.slice(0, 5).join('; ') + (diffs.length > 5 ? '; ...' : '')
    : '';
  return result;
}

function padSort_(acctNum) {
  return /^\d+$/.test(acctNum) ? ('0000000000' + acctNum).slice(-10) : String(acctNum).toLowerCase();
}

function companyUsesMultiCurrency_(realmId) {
  try {
    var prefs = qboGet_(realmId, '/preferences', {});
    return !!(prefs.Preferences && prefs.Preferences.CurrencyPrefs && prefs.Preferences.CurrencyPrefs.MultiCurrencyEnabled);
  } catch (e) {
    return false;
  }
}
