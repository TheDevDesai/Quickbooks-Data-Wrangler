/**
 * Flattens QuickBooks entity JSON (Invoice, Account, JournalEntry, ...) into
 * a table. Pure functions so they can be unit tested in Node.
 *
 * Nested objects become dotted columns (CustomerRef.name), custom fields
 * become CustomField.<Name>, and with expandLines each Line becomes its own
 * row with Line.* columns alongside the parent transaction's columns.
 */

var LEADING_COLUMNS_ = ['Id', 'TxnDate', 'DocNumber', 'Name', 'DisplayName', 'FullyQualifiedName',
  'AcctNum', 'AccountType', 'AccountSubType', 'Active', 'TotalAmt', 'Balance'];
var DROPPED_FIELDS_ = { domain: 1, sparse: 1, SyncToken: 1 };

function flattenValue_(value, prefix, out) {
  if (value === null || value === undefined) return;
  if (Array.isArray(value)) {
    if (!value.length) return;
    if (value.every(function (v) { return v === null || typeof v !== 'object'; })) {
      out[prefix] = value.join(', ');
    } else if (/(^|\.)CustomField$/.test(prefix)) {
      value.forEach(function (cf) {
        if (!cf || !cf.Name) return;
        var v = cf.StringValue !== undefined ? cf.StringValue
          : cf.NumberValue !== undefined ? cf.NumberValue
            : cf.DateValue !== undefined ? cf.DateValue
              : cf.BooleanValue;
        if (v !== undefined) out[prefix + '.' + cf.Name] = v;
      });
    } else {
      value.forEach(function (v, i) { flattenValue_(v, prefix + '[' + i + ']', out); });
    }
    return;
  }
  if (typeof value === 'object') {
    Object.keys(value).forEach(function (k) {
      if (DROPPED_FIELDS_[k]) return;
      flattenValue_(value[k], prefix ? prefix + '.' + k : k, out);
    });
    return;
  }
  out[prefix] = value;
}

/**
 * @param {Object[]} records Entities from QueryResponse.
 * @param {Object=} opts {expandLines: boolean}
 * @return {{header: string[], rows: any[][], types: string[]}}
 */
function flattenEntities(records, opts) {
  opts = opts || {};
  var flat = [];
  (records || []).forEach(function (rec) {
    var lines = opts.expandLines && Array.isArray(rec.Line) && rec.Line.length ? rec.Line : null;
    var parent = {};
    Object.keys(rec).forEach(function (k) {
      if (DROPPED_FIELDS_[k] || (lines && k === 'Line')) return;
      flattenValue_(rec[k], k, parent);
    });
    if (!lines) { flat.push(parent); return; }
    lines.forEach(function (line) {
      var row = {};
      Object.keys(parent).forEach(function (k) { row[k] = parent[k]; });
      flattenValue_(line, 'Line', row);
      flat.push(row);
    });
  });

  var seen = {}, keys = [];
  flat.forEach(function (row) {
    Object.keys(row).forEach(function (k) { if (!seen[k]) { seen[k] = true; keys.push(k); } });
  });
  var header = orderColumns_(keys);
  var types = header.map(function (k) { return entityColumnType_(k, flat); });
  var rows = flat.map(function (row) {
    return header.map(function (k, i) {
      var v = row[k];
      if (v === undefined || v === null) return '';
      if (types[i] === 'number' && typeof v !== 'number') return Number(v);
      return typeof v === 'boolean' ? v : (typeof v === 'number' ? v : String(v));
    });
  });
  return { header: header, rows: rows, types: types };
}

/** Puts the most useful columns first, Line.* columns after the header fields, MetaData last. */
function orderColumns_(keys) {
  function rank(k) {
    var lead = LEADING_COLUMNS_.indexOf(k);
    if (lead !== -1) return lead;
    if (k.indexOf('MetaData.') === 0) return 3000;
    if (k.indexOf('Line.') === 0 || k.indexOf('Line[') === 0) return 2000;
    return 1000;
  }
  return keys
    .map(function (k, i) { return { k: k, i: i, r: rank(k) }; })
    .sort(function (a, b) { return a.r - b.r || a.i - b.i; })
    .map(function (x) { return x.k; });
}

/** Ids, numbers-as-text and refs stay text; true numbers and yyyy-MM-dd dates are typed. */
function entityColumnType_(key, flatRows) {
  if (/(^|\.)(Id|value|DocNumber|AcctNum|SyncToken|LineNum|TxnId)$/.test(key)) return 'text';
  var seen = 0, nums = 0, dates = 0;
  flatRows.forEach(function (r) {
    var v = r[key];
    if (v === undefined || v === null || v === '') return;
    seen++;
    if (typeof v === 'number') nums++;
    else if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) dates++;
  });
  if (seen && nums === seen) return 'number';
  if (seen && dates === seen) return 'date';
  return 'text';
}

/** Builds the QuickBooks query statement (without pagination). */
function buildEntityQuery(entity, opts) {
  opts = opts || {};
  var clauses = [];
  var def = ENTITY_CATALOG[entity];
  if (!def) throw new Error('Unknown entity: ' + entity);
  if (def.dateField && opts.start) clauses.push(def.dateField + " >= '" + opts.start + "'");
  if (def.dateField && opts.end) clauses.push(def.dateField + " <= '" + opts.end + "'");
  // QuickBooks queries have no OR or parentheses, so extra conditions are AND-ed as written.
  if (opts.where) clauses.push(String(opts.where).replace(/^\s*where\s+/i, ''));
  var q = 'SELECT * FROM ' + entity;
  if (clauses.length) q += ' WHERE ' + clauses.join(' AND ');
  return q;
}
