/**
 * QuickBooks Online OAuth 2.0.
 *
 * App credentials (from the Intuit developer portal) live in Script
 * Properties. Each user's tokens live in their own User Properties, one
 * entry per connected company (realm), so a user can connect several
 * companies and other editors of the sheet never see each other's tokens.
 *
 * Installed as a Workspace add-on, Script Properties are shared by every
 * user in every spreadsheet, so only the people listed in QBW_ADMINS may
 * change them. The first person to save the setup becomes the first admin.
 */

var CONN_PREFIX_ = 'qbw.conn.';

function getAppSettings_() {
  var p = PropertiesService.getScriptProperties();
  return {
    clientId: p.getProperty('QBW_CLIENT_ID') || '',
    clientSecret: p.getProperty('QBW_CLIENT_SECRET') || '',
    environment: p.getProperty('QBW_ENVIRONMENT') || 'production'
  };
}

/** Lower-cased, de-duplicated emails from a comma/space/semicolon separated list. */
function parseAdminList_(text) {
  var seen = {};
  return String(text || '').split(/[\s,;]+/)
    .map(function (e) { return e.trim().toLowerCase(); })
    .filter(function (e) {
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) || seen[e]) return false;
      seen[e] = true;
      return true;
    });
}

/**
 * Who may change the app setup. Before setup anyone may (to bootstrap); after
 * that only listed admins. A setup saved before admins existed (an older
 * spreadsheet-bound install) stays editable until someone adds admins.
 */
function canAdminister_(admins, configured, email) {
  if (!configured || !admins.length) return true;
  return !!email && admins.indexOf(String(email).toLowerCase()) !== -1;
}

function currentUserEmail_() {
  try {
    return (Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || '').toLowerCase();
  } catch (e) {
    return '';
  }
}

function getAdmins_() {
  return parseAdminList_(PropertiesService.getScriptProperties().getProperty('QBW_ADMINS'));
}

function isAdmin_() {
  var s = getAppSettings_();
  return canAdminister_(getAdmins_(), !!(s.clientId && s.clientSecret), currentUserEmail_());
}

function requireAppSettings_() {
  var s = getAppSettings_();
  if (!s.clientId || !s.clientSecret) {
    throw new Error('QuickBooks is not set up for this spreadsheet yet. An admin needs to add the QuickBooks app keys under Admin setup in the QuickBooks panel.');
  }
  return s;
}

/** The OAuth redirect URI to register in the Intuit developer portal. */
function getRedirectUri() {
  return 'https://script.google.com/macros/d/' + ScriptApp.getScriptId() + '/usercallback';
}

/** Called from the sidebar: URL that starts the QuickBooks consent flow. */
function getAuthorizationUrl() {
  var s = requireAppSettings_();
  var state = ScriptApp.newStateToken()
    .withMethod('authCallback')
    .withTimeout(900)
    .createToken();
  return QBW.AUTH_URL +
    '?client_id=' + encodeURIComponent(s.clientId) +
    '&response_type=code' +
    '&scope=' + encodeURIComponent(QBW.SCOPE) +
    '&redirect_uri=' + encodeURIComponent(getRedirectUri()) +
    '&state=' + encodeURIComponent(state);
}

/** OAuth redirect target. Apps Script validates the state token before routing here. */
function authCallback(request) {
  var p = request.parameter || {};
  if (p.error) return callbackPage_('QuickBooks connection was not completed: ' + p.error, false);
  if (!p.code || !p.realmId) return callbackPage_('QuickBooks did not return an authorization code.', false);
  try {
    var s = requireAppSettings_();
    var token = tokenRequest_({
      grant_type: 'authorization_code',
      code: p.code,
      redirect_uri: getRedirectUri()
    }, s);
    var conn = {
      realmId: String(p.realmId),
      environment: s.environment,
      companyName: 'Company ' + p.realmId,
      fiscalStartMonth: 1
    };
    applyToken_(conn, token);
    saveConnection_(conn);
    // Best-effort enrichment; the connection is usable even if these fail.
    try {
      var info = qboGet_(conn.realmId, '/companyinfo/' + conn.realmId, {});
      conn.companyName = (info.CompanyInfo && info.CompanyInfo.CompanyName) || conn.companyName;
      var prefs = qboGet_(conn.realmId, '/preferences', {});
      var fiscal = prefs.Preferences && prefs.Preferences.AccountingInfoPrefs &&
        prefs.Preferences.AccountingInfoPrefs.FirstMonthOfFiscalYear;
      conn.fiscalStartMonth = monthNameToNumber_(fiscal);
      var latest = getConnection_(conn.realmId);
      latest.companyName = conn.companyName;
      latest.fiscalStartMonth = conn.fiscalStartMonth;
      saveConnection_(latest);
    } catch (e) {
      console.warn('Connected, but company details could not be loaded: ' + e);
    }
    return callbackPage_('This spreadsheet is connected to ' + conn.companyName + '. You can close this tab and go back to your spreadsheet.', true);
  } catch (e) {
    console.error(e);
    return callbackPage_('Connection failed: ' + e.message, false);
  }
}

function callbackPage_(message, ok) {
  var html = '<div style="font-family:\'IBM Plex Sans\',\'Segoe UI\',Roboto,Arial,sans-serif;padding:40px;max-width:520px;color:#17212b">' +
    '<h2 style="font-weight:600;color:' + (ok ? '#1e7b4f' : '#b3261e') + '">' + (ok ? 'You\'re connected' : 'Not connected') + '</h2>' +
    '<p style="font-size:15px;line-height:1.5">' + escapeHtml_(message) + '</p></div>' +
    (ok ? '<script>setTimeout(function(){window.top.close()},2500)</script>' : '');
  return HtmlService.createHtmlOutput(html).setTitle('QuickBooks Data Wrangler');
}

function escapeHtml_(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function tokenRequest_(payload, settings) {
  var res = UrlFetchApp.fetch(QBW.TOKEN_URL, {
    method: 'post',
    headers: {
      Authorization: 'Basic ' + Utilities.base64Encode(settings.clientId + ':' + settings.clientSecret),
      Accept: 'application/json'
    },
    payload: payload,
    muteHttpExceptions: true
  });
  var body = {};
  try { body = JSON.parse(res.getContentText() || '{}'); } catch (e) { /* non-JSON error page */ }
  if (res.getResponseCode() !== 200 || !body.access_token) {
    var err = new Error('Token request failed (' + res.getResponseCode() + '): ' +
      (body.error_description || body.error || res.getContentText().slice(0, 200)));
    err.oauthError = body.error || '';
    throw err;
  }
  return body;
}

function applyToken_(conn, token) {
  var now = Date.now();
  conn.accessToken = token.access_token;
  conn.refreshToken = token.refresh_token || conn.refreshToken;
  conn.expiresAt = now + (Number(token.expires_in) || 3600) * 1000;
  if (token.x_refresh_token_expires_in) {
    conn.refreshExpiresAt = now + Number(token.x_refresh_token_expires_in) * 1000;
  }
  conn.needsReconnect = false;
}

function saveConnection_(conn) {
  PropertiesService.getUserProperties().setProperty(CONN_PREFIX_ + conn.realmId, JSON.stringify(conn));
}

function getConnection_(realmId) {
  var raw = PropertiesService.getUserProperties().getProperty(CONN_PREFIX_ + realmId);
  if (!raw) throw new Error('You are not connected to the QuickBooks company this tab uses. Use Extensions > ' + QBW.ADDON_NAME + ' > Connect to QuickBooks, then sync again.');
  return JSON.parse(raw);
}

/** Returns a valid access token, refreshing it if needed. */
function getAccessToken_(realmId, forceRefresh) {
  var conn = getConnection_(realmId);
  if (!forceRefresh && conn.accessToken && conn.expiresAt - 120000 > Date.now()) return conn.accessToken;

  // Intuit rotates refresh tokens, so two concurrent refreshes could strand one of them.
  var lock = LockService.getUserLock();
  lock.waitLock(30000);
  try {
    conn = getConnection_(realmId);
    if (!forceRefresh && conn.accessToken && conn.expiresAt - 120000 > Date.now()) return conn.accessToken;
    if (!conn.refreshToken) throw new Error('Your QuickBooks sign-in for ' + conn.companyName + ' has expired. Click Reconnect in the QuickBooks panel.');
    try {
      applyToken_(conn, tokenRequest_({ grant_type: 'refresh_token', refresh_token: conn.refreshToken }, requireAppSettings_()));
    } catch (e) {
      if (e.oauthError === 'invalid_grant') {
        conn.needsReconnect = true;
        saveConnection_(conn);
        throw new Error('Your QuickBooks sign-in for ' + conn.companyName + ' has expired. Click Reconnect in the QuickBooks panel.');
      }
      throw e;
    }
    saveConnection_(conn);
    return conn.accessToken;
  } finally {
    lock.releaseLock();
  }
}

/** Called from the sidebar: the current user's connected companies (no tokens). */
function listConnections() {
  var props = PropertiesService.getUserProperties().getProperties();
  return Object.keys(props)
    .filter(function (k) { return k.indexOf(CONN_PREFIX_) === 0; })
    .map(function (k) {
      var c = JSON.parse(props[k]);
      return {
        realmId: c.realmId,
        companyName: c.companyName,
        environment: c.environment,
        needsReconnect: !!c.needsReconnect || (c.refreshExpiresAt && c.refreshExpiresAt < Date.now())
      };
    })
    .sort(function (a, b) { return a.companyName.localeCompare(b.companyName); });
}

/** Called from the sidebar: revokes tokens and forgets the company for this user. */
function disconnectCompany(realmId) {
  var conn;
  try { conn = getConnection_(realmId); } catch (e) { return listConnections(); }
  try {
    var s = requireAppSettings_();
    UrlFetchApp.fetch(QBW.REVOKE_URL, {
      method: 'post',
      contentType: 'application/json',
      headers: {
        Authorization: 'Basic ' + Utilities.base64Encode(s.clientId + ':' + s.clientSecret),
        Accept: 'application/json'
      },
      payload: JSON.stringify({ token: conn.refreshToken || conn.accessToken }),
      muteHttpExceptions: true
    });
  } catch (e) {
    console.warn('Token revoke failed: ' + e);
  }
  PropertiesService.getUserProperties().deleteProperty(CONN_PREFIX_ + realmId);
  return listConnections();
}
