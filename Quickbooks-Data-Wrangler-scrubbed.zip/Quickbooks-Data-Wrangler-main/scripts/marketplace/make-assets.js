// Regenerates marketplace/ images: node scripts/marketplace/make-assets.js (run from the repo root, after npm run bundle).
const { chromium } = require('playwright');
const fs = require('fs');
// Mark: a ledger page with two sync arrows, in the panel's ledger-ink blue. No Intuit branding.
const mark = (size) => `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="14" fill="#1f5f8b"/>
  <rect x="17" y="14" width="30" height="36" rx="3" fill="#ffffff"/>
  <rect x="22" y="22" width="20" height="3" rx="1.5" fill="#1f5f8b" opacity=".55"/>
  <rect x="22" y="29" width="20" height="3" rx="1.5" fill="#1f5f8b" opacity=".55"/>
  <rect x="22" y="36" width="12" height="3" rx="1.5" fill="#1f5f8b" opacity=".55"/>
  <circle cx="45" cy="45" r="11" fill="#1e7b4f" stroke="#1f5f8b" stroke-width="2.5"/>
  <path d="M39.5 44a5.5 5.5 0 0 1 9.6-3.2M50.5 46a5.5 5.5 0 0 1-9.6 3.2" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M49.6 37.6v3.8h-3.8M40.4 52.4v-3.8h3.8" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
(async () => {
  const b = await chromium.launch();
  for (const size of [32, 48, 96, 128]) {
    const p = await b.newPage({ viewport: { width: size, height: size } });
    await p.setContent(`<style>html,body{margin:0;background:transparent}</style>${mark(size)}`);
    await p.screenshot({ path: `marketplace/icon-${size}.png`, omitBackground: true });
  }
  const banner = await b.newPage({ viewport: { width: 220, height: 140 } });
  await banner.setContent(`<style>html,body{margin:0}body{width:220px;height:140px;background:#fbfcfd;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;font-family:"IBM Plex Sans","Segoe UI",Arial,sans-serif;color:#17212b}
    b{font-size:15px;font-weight:600}</style>${mark(56)}<b>QuickBooks Data Wrangler</b>`);
  await banner.screenshot({ path: 'marketplace/card-banner-220x140.png' });
  await b.close();
})();
