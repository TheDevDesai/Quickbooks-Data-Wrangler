// Regenerates marketplace/screenshot-1280x800.png with sample data: node scripts/marketplace/make-screenshot.js (run from the repo root, after npm run bundle).
const { chromium } = require('playwright');
const fs = require('fs');
const src = (f) => fs.readFileSync('dist/' + f, 'utf8');
const ago = (m) => new Date(Date.now() - m * 60000).toISOString();
const state = { configured: true, isAdmin: false, admins: [], environment: 'production', redirectUri: '',
  connections: [{ realmId: '1', companyName: 'Sample Company Inc', environment: 'production' }],
  pulls: [
    { id: 'a', name: 'P&L by month', sheetName: 'P&L Q3', realmId: '1', source: 'report', accountingMethod: 'Accrual', lastStatus: 'ok', lastRows: 14, lastRange: '2026-07-01 to 2026-09-30', lastRun: ago(3), dateRange: {preset:'last_12_months'}, filters: {} },
    { id: 'b', name: 'Cash roll forward', sheetName: 'Cash roll forward', realmId: '1', source: 'rollforward', accountingMethod: 'Cash', lastStatus: 'ok', lastRows: 6, lastRange: '2026-01-01 to 2026-10-26', lastRun: ago(3), dateRange: {preset:'this_year_to_date'}, filters: {} },
    { id: 'c', name: 'AP by vendor', sheetName: 'AP by vendor', realmId: '1', source: 'rollforward', accountingMethod: 'Accrual', lastStatus: 'ok', lastRows: 23, lastRange: '2026-09-01 to 2026-09-30', lastRun: ago(3), dateRange: {preset:'last_month'}, filters: {} }],
  reports: [{key:'ProfitAndLoss',label:'Profit and Loss',params:['dateRange','method','summarize']}], rollforwards: [{key:'bank',label:'Bank & credit card account',filter:'bankAccount'}],
  rollforwardPeriods: ['Month','Total'], entities: [{key:'Invoice',label:'Invoices',dated:true,hasLines:true}], summarizeOptions: ['Total','Month'],
  datePresets: [{key:'last_month',label:'Last month'}], sheetNames: [] };
const mock = `<script>window.google={script:{get run(){var ok,r=new Proxy({},{get(_,k){if(k==='withSuccessHandler')return f=>{ok=f;return r};if(k==='withFailureHandler')return()=>r;return()=>setTimeout(()=>ok(${JSON.stringify(state)}),5)}});return r}}};</script>`;
const panel = src('Sidebar.html').replace("<?!= include_('Styles') ?>", () => src('Styles.html'))
  .replace("<?!= autoSync ? 'true' : 'false' ?>", 'false').replace('<head>', () => '<head>' + mock);
const rows = [['Income','','','',''],['    4000 Subscription revenue','412,300.00','428,950.00','441,120.00','1,282,370.00'],['    4100 Services','38,400.00','35,750.00','41,900.00','116,050.00'],
  ['Total Income','450,700.00','464,700.00','483,020.00','1,398,420.00'],['Expenses','','','',''],['    6000 Payroll','268,400.00','271,300.00','274,950.00','814,650.00'],
  ['    6200 Software','24,180.00','24,560.00','25,010.00','73,750.00'],['    6500 Rent','18,000.00','18,000.00','18,000.00','54,000.00'],['Total Expenses','310,580.00','313,860.00','317,960.00','942,400.00'],
  ['Net Income','140,120.00','150,840.00','165,060.00','456,020.00']];
const grid = `<table><tr><th></th><th>A</th><th>B</th><th>C</th><th>D</th><th>E</th></tr>
  <tr><td>1</td><td colspan="5"><b>Profit And Loss</b></td></tr><tr><td>2</td><td colspan="5">Sample Company Inc &middot; Jul 1 &ndash; Sep 30, 2026 &middot; Accrual basis</td></tr><tr><td>3</td><td colspan="5"></td></tr>
  <tr class="h"><td>4</td><td>Account</td><td>Jul 2026</td><td>Aug 2026</td><td>Sep 2026</td><td>Total</td></tr>
  ${rows.map((r, i) => `<tr class="${/^(Total|Net|Income|Expenses)/.test(r[0]) ? 'b' : ''}"><td>${i + 5}</td>${r.map((c, j) => `<td class="${j ? 'n' : ''}">${c.replace(/ {4}/, '&nbsp;&nbsp;&nbsp;&nbsp;')}</td>`).join('')}</tr>`).join('')}
  ${Array.from({ length: 12 }, (_, i) => `<tr><td>${i + 15}</td><td></td><td></td><td></td><td></td><td></td></tr>`).join('')}</table>`;
const page = `<style>html,body{margin:0}body{width:1280px;height:800px;display:grid;grid-template-columns:1fr 320px;grid-template-rows:56px 1fr;font-family:Arial,sans-serif;background:#fff}
  header{grid-column:1/3;display:flex;align-items:center;gap:24px;padding:0 20px;border-bottom:1px solid #dadce0;font-size:14px;color:#3c4043}
  header b{font-size:18px;font-weight:400}header span.ext{background:#e8f0fe;border-radius:4px;padding:4px 8px;color:#1f5f8b}
  .sheet{overflow:hidden}table{border-collapse:collapse;font-size:13px;width:100%}td,th{border:1px solid #e2e3e3;padding:4px 8px;height:20px;white-space:nowrap}
  th,td:first-child{background:#f8f9fa;color:#5f6368;font-weight:400;text-align:center;width:36px}td.n{text-align:right;font-variant-numeric:tabular-nums}
  tr.h td{background:#f1f3f4;font-weight:bold}tr.h td:first-child{font-weight:400}tr.b td:not(:first-child){font-weight:bold}
  iframe{border:0;border-left:1px solid #dadce0;width:320px;height:744px}</style>
  <header><b>Board financials</b><span>File</span><span>Edit</span><span>View</span><span>Insert</span><span>Format</span><span>Data</span><span class="ext">Extensions</span><span>Help</span></header>
  <div class="sheet">${grid}</div><iframe id="f"></iframe>`;
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
  await p.route('https://fonts.googleapis.com/**', r => r.fulfill({ body: '' }));
  await p.setContent(page);
  await p.$eval('#f', (el, html) => { el.srcdoc = html; }, panel);
  await p.waitForTimeout(500);
  await p.screenshot({ path: 'marketplace/screenshot-1280x800.png' });
  await b.close();
})();
