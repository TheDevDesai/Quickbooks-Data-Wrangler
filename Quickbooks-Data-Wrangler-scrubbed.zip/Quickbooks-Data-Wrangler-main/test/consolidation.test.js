const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const col = (key, title, type) => ({ ColTitle: title, ColType: type || 'Money', MetaData: [{ Name: 'ColKey', Value: key }] });
const cell = (value, id) => (id ? { value, id } : { value });

function gl(sections) {
  return {
    Header: { ReportName: 'GeneralLedger' },
    Columns: { Column: [col('tx_date', 'Date', 'Date'), col('txn_type', 'Type', 'String'), col('name', 'Name', 'String'), col('memo', 'Memo', 'String'), col('debt_amt', 'Debit'), col('credit_amt', 'Credit')] },
    Rows: { Row: sections.map(([id, name, lines]) => ({
      Header: { ColData: [cell(name, id), cell(''), cell(''), cell(''), cell(''), cell('')] },
      Rows: { Row: lines.map(([d, t, v, m, dr, cr]) => ({ ColData: [cell(d), cell(t), cell(v), cell(m), cell(dr ? dr.toFixed(2) : ''), cell(cr ? cr.toFixed(2) : '')], type: 'Data' })) },
      Summary: { ColData: [cell('Total'), cell(''), cell(''), cell(''), cell(''), cell('')] }, type: 'Section'
    })) }
  };
}

function pnl(values) {
  const month = (label, start, end) => ({ ColTitle: label, ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: start }, { Name: 'EndDate', Value: end }] });
  return {
    Header: { ReportName: 'ProfitAndLoss' },
    Columns: { Column: [col('account', '', 'Account'), month('Aug 2026', '2026-08-01', '2026-08-31'), month('Sep 2026', '2026-09-01', '2026-09-30'), col('total', 'Total')] },
    Rows: { Row: Object.entries(values).map(([id, [a, b]]) => ({
      ColData: [cell('acct', id), cell(a.toFixed(2)), cell(b.toFixed(2)), cell((a + b).toFixed(2))], type: 'Data' })) }
  };
}

// US (USD) and Europe (EUR) share the chart of accounts by number but not by id.
const US = [
  { Id: '100', AcctNum: '6310', Name: 'Marketing – Salaries & Wages', FullyQualifiedName: 'Sales & Marketing:Marketing:Marketing – Salaries & Wages', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '101', AcctNum: '6320', Name: 'Marketing – Benefits', FullyQualifiedName: 'Sales & Marketing:Marketing:Marketing – Benefits', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '102', AcctNum: '6390', Name: 'Marketing Software', FullyQualifiedName: 'Sales & Marketing:Marketing:Marketing Software', AccountType: 'Expense', Classification: 'Expense' }
];
const EU = [
  { Id: '7', AcctNum: '6310', Name: 'Salaries & Wages', FullyQualifiedName: 'Marketing:Salaries & Wages', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '8', AcctNum: '6320', Name: 'Benefits', FullyQualifiedName: 'Marketing:Benefits', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '9', AcctNum: '6110', Name: 'Engineering - Salaries & Wages', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '10', AcctNum: '49000', Name: 'Other Income - Intercompany', AccountType: 'Income', Classification: 'Revenue' }
];
const US_GL = {
  '2026-08-01': [['100', '6310 Marketing – Salaries & Wages', [['2026-08-15', 'Journal Entry', '', 'Rippling payroll', 6000, 0]]],
    ['102', '6390 Marketing Software', [['2026-08-03', 'Bill', 'HubSpot Inc', '', 4180.25, 0]]]],
  '2026-09-01': [['100', '6310 Marketing – Salaries & Wages', [['2026-09-15', 'Journal Entry', '', 'Rippling payroll', 6000, 0]]]]
};
const EU_GL = {
  '2026-08-01': [['7', '6310 Salaries & Wages', [['2026-08-31', 'Journal Entry', '', 'Payroll run August', 15000, 0]]],
    ['8', '6320 Benefits', [['2026-08-31', 'Journal Entry', '', 'Social security', 4000, 0]]],
    ['9', '6110 Engineering - Salaries & Wages', [['2026-08-31', 'Journal Entry', '', 'Payroll run', 20000, 0]]]],
  '2026-09-01': [['7', '6310 Salaries & Wages', [['2026-09-30', 'Journal Entry', '', 'Payroll run September', 17000, 0]]]]
};
const FX = { EUR: { '2026-08': 1.16, '2026-09': 1.17 } };

function run(g, pull, opts) {
  opts = opts || {};
  const calls = [], companions = [], fxSyncs = [];
  g.getConnection_ = (id) => ({ realmId: id, companyName: id === 'eu' ? 'Sample Company Europe Lda.' : 'Sample Company Inc.' });
  g.qboQueryAll_ = (realm) => (realm === 'eu' ? EU : US);
  g.qboGet_ = opts.get || ((realm) => ({ Preferences: { CurrencyPrefs: { MultiCurrencyEnabled: false, HomeCurrency: { value: realm === 'eu' ? 'EUR' : 'USD' } } } }));
  g.qboReport_ = (realm, name, params) => {
    calls.push(Object.assign({ realm, report: name }, plain(params)));
    if (name === 'ProfitAndLoss') {
      return pnl(realm === 'eu' ? { 7: [15000, 17000], 8: [4000, 0], 9: [20000, 0] } : { 100: [6000, 6000], 101: [0, 0], 102: [4180.25, 0] });
    }
    return gl((realm === 'eu' ? EU_GL : US_GL)[params.start_date]);
  };
  g.syncAccountGroups_ = () => g.buildGroupLookup_([['6310', '', 'People', ''], ['6320', '', 'People', ''], ['6390', '', 'Software', ''], ['6110', '', 'R&D', '']]);
  g.loadVendorContext_ = () => ({ aliases: [], vendors: [], mentions: [] });
  g.writeActualsCompanions_ = (...a) => companions.push(plain(a));
  g.syncFxRates_ = (currencies, months, reporting) => { fxSyncs.push([currencies, months, reporting]); return opts.fx || FX; };
  const out = plain(g.buildActuals_(Object.assign({ realmId: 'us', period: 'Month', layout: 'schedule', accountingMethod: 'Accrual', sheetName: 'Actuals', filters: {} }, pull),
    { start: '2026-08-01', end: '2026-09-30' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  return { out, calls, companions, fxSyncs };
}

test('Europe marketing payroll lands on the US accounts with the same number, converted at the month rate', () => {
  const g = load();
  const { out, companions, fxSyncs } = run(g, { alsoRealmIds: ['eu'] });
  assert.deepEqual(plain(fxSyncs), [[['EUR'], ['2026-08', '2026-09'], 'USD']]);
  assert.equal(out.title[1], 'Sample Company Inc. + Sample Company Europe Lda. (EUR converted to USD)');
  const total = (label) => out.rows.find((r) => r[1] === 'Total ' + label).slice(3);
  // 6310: US 6,000 a month + EU 15,000 EUR x 1.16 / 17,000 EUR x 1.17.
  assert.deepEqual(total('6310 Sales & Marketing:Marketing:Marketing – Salaries & Wages'), [6000 + 17400, 6000 + 19890, 49290]);
  assert.deepEqual(total('6320 Sales & Marketing:Marketing:Marketing – Benefits'), [4640, 0, 4640]);
  // A Europe account the US doesn't have keeps its own row.
  assert.deepEqual(total('6110 Engineering - Salaries & Wages'), [23200, 0, 23200]);
  // Each company ties out in its own currency; the check row is 0.
  const tie = companions[0][1];
  assert.equal(tie.totalAbsDiff, 0);
  assert.equal(tie.header[0], 'Company');
  assert.ok(tie.rows.some((r) => r[0] === 'Sample Company Europe Lda.' && r[2] === 'Aug 2026' && r[3] === 15000));
  assert.deepEqual(out.rows[out.rows.length - 1].slice(3), [0, 0, 0]);
  assert.equal(out.warning, '');
});

test('without "Also include" the tab stays single-company and asks for no rates', () => {
  const g = load();
  const { out, calls, fxSyncs } = run(g, {});
  assert.deepEqual(fxSyncs, []);
  assert.ok(calls.every((c) => c.realm === 'us'));
  assert.equal(out.title[1], 'Sample Company Inc.');
  assert.ok(!out.rows.some((r) => /6110/.test(r[1])));
});

test('picked accounts carry over to the other company by account number', () => {
  const g = load();
  const { out, calls } = run(g, { alsoRealmIds: ['eu'], filters: { account: ['100', '101'] } });
  const ptGl = calls.filter((c) => c.realm === 'eu' && c.report === 'GeneralLedger');
  assert.ok(ptGl.length && ptGl.every((c) => c.account === '7,8'));
  assert.ok(!out.rows.some((r) => /6110|6390/.test(r[1])));
});

test('an open month without a rate borrows the latest earlier one and says so', () => {
  const g = load();
  const { out } = run(g, { alsoRealmIds: ['eu'] }, { fx: { EUR: { '2026-08': 1.16 } } });
  const total = out.rows.find((r) => r[1] === 'Total 6310 Sales & Marketing:Marketing:Marketing – Salaries & Wages').slice(3);
  assert.deepEqual(total, [23400, 6000 + 19720, 49120]);
  assert.match(out.warning, /no EUR rate yet for Sep 2026 .*latest earlier rate was used \(Aug 2026\)/);
});

test('no rate at all stops the sync with what to enter', () => {
  const g = load();
  assert.throws(() => run(g, { alsoRealmIds: ['eu'] }, { fx: {} }), /Enter the EUR to USD rate for Aug 2026 in the "FX Rates" tab/);
});

test('detail layout shows company, local amount and rate', () => {
  const g = load();
  const { out } = run(g, { alsoRealmIds: ['eu'], layout: 'detail' });
  assert.deepEqual(out.header.slice(-3), ['Company', 'Amount (company currency)', 'FX rate']);
  const row = out.rows.find((r) => /August/.test(r[10]));
  assert.equal(row[11], 17400);
  assert.deepEqual(row.slice(-3), ['Sample Company Europe Lda.', 15000, 1.16]);
  assert.equal(row[4], '6310 Sales & Marketing:Marketing:Marketing – Salaries & Wages');
});

test('FX tab parsing accepts month text, dates and ISO months', () => {
  const g = load();
  const t = plain(g.parseFxRows_(['Month', 'eur', 'PHP'], [['Jan 2026', 1.17, ''], ['2026-02', '1.18', 0.0172], [new Date(2026, 2, 1), 1.16, 'x'], ['notes', 2, 2]]));
  assert.deepEqual(t, { EUR: { '2026-01': 1.17, '2026-02': 1.18, '2026-03': 1.16 }, PHP: { '2026-02': 0.0172 } });
  assert.equal(g.fxMonthKey_('September 2026'), '2026-09');
  assert.equal(g.fxMonthKey_('9/2026'), '2026-09');
  assert.deepEqual(plain(g.monthsBetween_('2025-11-15', '2026-02-28')), ['2025-11', '2025-12', '2026-01', '2026-02']);
});

test('normalizePull_ keeps other companies only for GL actuals and never the primary', () => {
  const g = load();
  const base = { realmId: 'us', source: 'rollforward', period: 'Month', dateRange: { preset: 'this_year' }, sheetName: 'Actuals' };
  assert.deepEqual(plain(g.normalizePull_(Object.assign({ rollforwardBy: 'actuals', alsoRealmIds: ['eu', 'us', 'eu', 'ph'] }, base)).alsoRealmIds), ['eu', 'ph']);
  assert.deepEqual(plain(g.normalizePull_(Object.assign({ rollforwardBy: 'vendor', alsoRealmIds: ['eu'] }, base)).alsoRealmIds), []);
});

test('a "PHP per USD" column takes central-bank quotes and inverts them', () => {
  const g = load();
  const t = plain(g.parseFxRows_(['Month', 'EUR', 'PHP per USD'], [['Jan 2026', 1.18, 59.1622]], 'USD'));
  assert.equal(t.EUR['2026-01'], 1.18);
  assert.ok(Math.abs(t.PHP['2026-01'] - 1 / 59.1622) < 1e-12);
  assert.equal(g.fxHeader_('USD/PHP', 'USD').code, 'PHP');
  assert.equal(g.fxHeader_('Notes', 'USD'), null);
});

test('a company whose currency QuickBooks does not report stops the sync instead of adding unconverted amounts', () => {
  const g = load();
  const realGet = (realm) => ({ Preferences: { CurrencyPrefs: realm === 'eu' ? {} : { HomeCurrency: { value: 'USD' } } } });
  assert.throws(() => run(g, { alsoRealmIds: ['eu'] }, { get: realGet }), /did not say which currency Sample Company Europe/);
});

test('left-out vendors come off the totals, are listed at the bottom, and the check still ties', () => {
  const g = load();
  const { out } = run(g, { excludeVendors: ['HubSpot, Inc.'] });
  assert.equal(out.title[3], 'Accrual basis; 1 vendor left out (listed at the bottom)');
  const grand = out.rows.find((r) => r[0] === 'Grand total');
  assert.deepEqual(grand.slice(3), [6000, 6000, 12000], 'HubSpot is off the grand total');
  assert.ok(!out.rows.some((r) => r[1] === 'Total 6390 Sales & Marketing:Marketing:Marketing Software'));
  const at = out.rows.findIndex((r) => r[0] === 'Left out of this tab (not in the totals above)');
  assert.ok(at > out.rows.indexOf(grand));
  assert.deepEqual(out.rows[at + 1], ['', '6390 Sales & Marketing:Marketing:Marketing Software', 'HubSpot Inc', 4180.25, 0, 4180.25]);
  assert.deepEqual(out.rows[at + 2], ['Total left out', '', '', 4180.25, 0, 4180.25]);
  // Summary formulas look for "Total <account>" rows; none of the left-out rows look like that.
  assert.ok(!out.rows.slice(at).some((r) => /^Total \d/.test(r[1] || '')));
  const check = out.rows[out.rows.length - 1];
  assert.equal(check[0], 'Check: grand total + left out vs QuickBooks P&L (should be 0)');
  assert.deepEqual(check.slice(3), [0, 0, 0]);
});

test('a pattern leaves out every vendor starting with it, in the pivot-ready layout too', () => {
  const g = load();
  const { out } = run(g, { excludeVendors: ['Rippling*'], layout: 'long' });
  const left = out.rows.filter((r) => r[0] === 'Left out of this tab');
  assert.deepEqual(left.map((r) => [r[4], r[5], r[8]]), [['Rippling (payroll)', 'Aug 2026', 6000], ['Rippling (payroll)', 'Sep 2026', 6000]]);
  assert.ok(out.rows.some((r) => r[4] === 'HubSpot Inc' && r[0] !== 'Left out of this tab'));
});

test('vendor name matching ignores case and suffixes; a trailing * matches whole words only', () => {
  const g = load();
  const m = g.buildVendorExcluder_(['Event – AES*', 'Citywide Sound Productions, Inc.']);
  assert.ok(m('Event – AES Mar-26'));
  assert.ok(m('event - aes apr-27'));
  assert.ok(!m('Event – LESSONS'));
  assert.ok(m('CITYWIDE SOUND PRODUCTIONS'));
  assert.ok(!m('Citywide Sound'));
});

test('normalizePull_ keeps left-out vendors for GL actuals only, trimmed and de-duplicated', () => {
  const g = load();
  const base = { realmId: 'us', source: 'rollforward', period: 'Month', dateRange: { preset: 'this_year' }, sheetName: 'Actuals' };
  assert.deepEqual(plain(g.normalizePull_(Object.assign({ rollforwardBy: 'actuals', excludeVendors: [' VENDORX ', 'VENDORX', '', 'Event – AES*'] }, base)).excludeVendors), ['VENDORX', 'Event – AES*']);
  assert.deepEqual(plain(g.normalizePull_(Object.assign({ rollforwardBy: 'vendor', excludeVendors: ['VENDORX'] }, base)).excludeVendors), []);
});

test('a Vendor Aliases account override brings that vendor in from accounts outside the tab', () => {
  const g = load();
  const accounts = [
    { Id: '604', AcctNum: '6400', Name: 'Demand Generation / Paid Media', FullyQualifiedName: 'Sales & Marketing:Demand Generation / Paid Media', AccountType: 'Expense', Classification: 'Expense' },
    { Id: '516', AcctNum: '5160', Name: 'Other Expenses – Platform', AccountType: 'Cost of Goods Sold', Classification: 'Expense' }
  ];
  const lines = {
    '604': { '2026-06-01': [], '2026-07-01': [['2026-07-31', 'Journal Entry', '', '[Jan to Jun 2026] Google Ad Charges', 6200.00, 0], ['2026-07-31', 'Expense', 'LinkedIn', '', 100, 0]] },
    '516': { '2026-06-01': [['2026-06-12', 'Expense', 'Google Ads', 'GOOGLE *ADS', 6200.00, 0], ['2026-06-20', 'Expense', 'AWS', '', 900, 0]],
      '2026-07-01': [['2026-07-31', 'Journal Entry', '', '[Jan to Jun 2026] Google Ad Charges', 0, 6200.00]] }
  };
  const glCalls = [];
  g.qboQueryAll_ = () => accounts;
  g.qboGet_ = () => ({ Preferences: { CurrencyPrefs: { HomeCurrency: { value: 'USD' } } } });
  g.qboReport_ = (realm, name, params) => {
    if (name === 'ProfitAndLoss') {
      const month = (label, start, end) => ({ ColTitle: label, ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: start }, { Name: 'EndDate', Value: end }] });
      return { Header: {}, Columns: { Column: [col('account', '', 'Account'), month('Jun 2026', '2026-06-01', '2026-06-30'), month('Jul 2026', '2026-07-01', '2026-07-31')] },
        Rows: { Row: [{ ColData: [cell('6400', '604'), cell('0.00'), cell('6300.00')], type: 'Data' }] } };
    }
    glCalls.push(params.account);
    return gl(params.account.split(',').filter((id) => lines[id]).map((id) => [id, id === '604' ? '6400 Demand Generation / Paid Media' : '5160 Other Expenses – Platform', lines[id][params.start_date]]));
  };
  g.syncAccountGroups_ = () => g.buildGroupLookup_([['6400', '', 'Operating Expenses', ''], ['5160', '', 'COGS', '']]);
  g.loadVendorContext_ = () => {
    const rows = [['Google Ad', 'Google Ads', ''], ['', 'Google Ads', '6400']];
    const vendors = g.buildVendorIndex_(['Google Ads', 'LinkedIn', 'AWS']);
    return { aliases: g.parseAliasRows_(rows), vendors, mentions: g.buildMentionIndex_(vendors), overrides: g.buildVendorOverrides_(rows, vendors) };
  };
  let tie;
  g.writeActualsCompanions_ = (name, t) => { tie = plain(t); };
  const pull = { realmId: 'us', period: 'Month', layout: 'schedule', accountingMethod: 'Accrual', sheetName: 'Actuals', filters: { account: ['604'] } };
  const out = plain(g.buildActuals_(pull, { start: '2026-06-01', end: '2026-07-31' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  assert.deepEqual(glCalls, ['604', '604', '516', '516'], 'the outside expense account is read too, once per month');
  const row = (v) => out.rows.find((r) => r[2] === v);
  // June's card charge lands in June; July's catch-up JE nets against its own 5160 credit.
  assert.deepEqual(row('Google Ads').slice(3), [6200.00, 0, 6200.00]);
  assert.ok(!out.rows.some((r) => r[2] === 'AWS'), 'other 5160 vendors stay out');
  assert.ok(!out.rows.some((r) => /5160/.test(r[1] || '')));
  assert.deepEqual(out.rows.find((r) => r[0] === 'Total Operating Expenses').slice(3), [6200.00, 100, 6300.00]);
  assert.deepEqual(out.rows.find((r) => /^Of which moved in/.test(r[0])).slice(3), [6200.00, -6200.00, 0]);
  const check = out.rows[out.rows.length - 1];
  assert.equal(check[0], 'Check: grand total − moved in vs QuickBooks P&L (should be 0)');
  assert.deepEqual(check.slice(3), [0, 0, 0]);
  assert.equal(tie.totalAbsDiff, 0, 'the tie-out still compares 6400 as posted');
  // The detail layout says where each moved line was posted.
  const detail = plain(g.buildActuals_(Object.assign({}, pull, { layout: 'detail' }), { start: '2026-06-01', end: '2026-07-31' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  const card = detail.rows.find((r) => r[0] === '2026-06-12');
  assert.equal(card[4], '6400 Sales & Marketing:Demand Generation / Paid Media');
  assert.equal(card[12], '5160 Other Expenses – Platform');
});

test('straight-line forecast fills the months after the actuals cut-off with each row\'s average', () => {
  const g = load();
  const periods = g.buildPeriods_('2026-01-01', '2026-12-31', 'Month', 1);
  assert.equal(g.forecastCutIndex_(periods, '', '2026-10-28'), 8, 'blank = last completed month (Sep)');
  assert.equal(g.forecastCutIndex_(periods, '2026-06', '2026-10-28'), 5);
  const data = { G: { a: { HubSpot: [0, 0, 0, 0, 0, 0, 100, 200, 300, 999, 0, 0], Newswire: [0, 5000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] } } };
  g.applyStraightLine_(data, 8, '3');
  assert.deepEqual(plain(data.G.a.HubSpot), [0, 0, 0, 0, 0, 0, 100, 200, 300, 200, 200, 200], 'partial October is replaced');
  assert.deepEqual(plain(data.G.a.Newswire).slice(9), [0, 0, 0], 'a one-off outside the window is not projected');
  const ytd = { G: { a: { X: [90, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5] } } };
  g.applyStraightLine_(ytd, 8, 'ytd');
  assert.deepEqual(plain(ytd.G.a.X).slice(9), [10, 10, 10]);
});

test('a forecast pull marks forecast months, totals actual + forecast, and keeps checks to actual months', () => {
  const g = load();
  const runYear = (pull) => {
    g.getConnection_ = () => ({ companyName: 'Sample Company Inc.' });
    g.qboQueryAll_ = () => US;
    g.qboGet_ = () => ({ Preferences: { CurrencyPrefs: { HomeCurrency: { value: 'USD' } } } });
    g.qboReport_ = (realm, name, params) => {
      if (name === 'ProfitAndLoss') {
        const month = (label, start, end) => ({ ColTitle: label, ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: start }, { Name: 'EndDate', Value: end }] });
        return { Header: {}, Columns: { Column: [col('account', '', 'Account'), month('Aug 2026', '2026-08-01', '2026-08-31'), month('Sep 2026', '2026-09-01', '2026-09-30')] },
          Rows: { Row: [{ ColData: [cell('acct', '102'), cell('100.00'), cell('300.00')], type: 'Data' }] } };
      }
      const amt = { '2026-08-01': 100, '2026-09-01': 300, '2026-10-01': 50 }[params.start_date];
      return gl(amt ? [['102', '6390 Marketing Software', [[params.start_date.slice(0, 8) + '15', 'Bill', 'HubSpot Inc', '', amt, 0]]]] : []);
    };
    g.syncAccountGroups_ = () => g.buildGroupLookup_([['6390', '', 'Software', '']]);
    g.loadVendorContext_ = () => ({ aliases: [], vendors: [], mentions: [] });
    g.writeActualsCompanions_ = () => {};
    return plain(g.buildActuals_(Object.assign({ realmId: 'us', period: 'Month', accountingMethod: 'Accrual', sheetName: 'Actuals', filters: {} }, pull),
      { start: '2026-08-01', end: '2026-11-30', today: '2026-10-28' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  };
  const out = runYear({ layout: 'schedule', forecastBasis: '3' });
  assert.deepEqual(out.header.slice(3), ['Aug 2026', 'Sep 2026', 'Oct 2026 (F)', 'Nov 2026 (F)', 'Total']);
  assert.match(out.title[3], /actuals through Sep 2026, then straight-line forecast \(F\) at the last 3 months average/);
  // Window Jun–Sep clipped to Aug–Sep: (100 + 300) / 2 = 200; October's partial 50 is replaced.
  assert.deepEqual(out.rows.find((r) => r[2] === 'HubSpot Inc').slice(3), [100, 300, 200, 200, 800]);
  const check = out.rows[out.rows.length - 1];
  assert.deepEqual(check.slice(3), [0, 0, null, null, 0], 'no check on forecast months');
  const long = runYear({ layout: 'long', forecastBasis: '1' });
  assert.equal(long.header[long.header.length - 1], 'Actual / Forecast');
  assert.deepEqual(long.rows.map((r) => [r[5], r[8], r[9]]), [['Aug 2026', 100, 'Actual'], ['Sep 2026', 300, 'Actual'], ['Oct 2026', 300, 'Forecast'], ['Nov 2026', 300, 'Forecast']]);
});

test('normalizePull_ keeps a forecast only for grouped or pivot-ready GL actuals', () => {
  const g = load();
  const base = { realmId: 'us', source: 'rollforward', rollforwardBy: 'actuals', period: 'Month', dateRange: { preset: 'this_year' }, sheetName: 'Actuals' };
  const p = plain(g.normalizePull_(Object.assign({ layout: 'schedule', forecastBasis: '3', forecastThrough: '2026-09' }, base)));
  assert.deepEqual([p.forecastBasis, p.forecastThrough], ['3', '2026-09']);
  assert.equal(g.normalizePull_(Object.assign({ layout: 'detail', forecastBasis: '3' }, base)).forecastBasis, '');
  assert.equal(g.normalizePull_(Object.assign({ layout: 'schedule', forecastBasis: '12' }, base)).forecastBasis, '');
  assert.equal(g.normalizePull_(Object.assign({ layout: 'schedule', forecastBasis: 'ytd', forecastThrough: 'Sep' }, base)).forecastThrough, '');
});
