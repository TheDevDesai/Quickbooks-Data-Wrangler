const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const ids = (n, start) => Array.from({ length: n }, (_, i) => String((start || 1150040000) + i));

test('account IDs are batched under the URL budget, keeping parents with their sub-accounts', () => {
  const g = load();
  const all = ids(300).map((id) => ({ Id: id }));
  all[201].ParentRef = { value: all[0].Id };   // sub-account far from its parent in the list
  all[202].ParentRef = { value: all[201].Id }; // and a sub-sub-account
  const chunks = plain(g.chunkAccountIds_(all.map((a) => a.Id), all));
  assert.ok(chunks.length > 1);
  chunks.forEach((c) => assert.ok(encodeURIComponent(c.join(',')).length <= 1200));
  assert.equal(chunks.flat().length, 300);
  assert.equal(new Set(chunks.flat()).size, 300);
  const family = chunks.find((c) => c.includes(all[0].Id));
  assert.ok(family.includes(all[201].Id) && family.includes(all[202].Id));
  assert.deepEqual(plain(g.chunkAccountIds_(['1', '2'], [])), [['1', '2']]);
});

test('GL actuals across hundreds of expense accounts stays under the URL limit', () => {
  const g = load();
  const accounts = ids(250).map((id, i) => ({ Id: id, AcctNum: String(60000 + i), Name: 'Expense ' + i, AccountType: 'Expense', Classification: 'Expense' }));
  const calls = [];
  g.qboQueryAll_ = () => accounts;
  g.qboGet_ = () => ({});
  g.qboReport_ = (realm, name, params) => {
    if (name === 'ProfitAndLoss') return { Header: {}, Columns: { Column: [] }, Rows: {} };
    calls.push(params);
    const id = params.account.split(',')[0];
    return {
      Header: {}, Columns: { Column: ['tx_date', 'txn_type', 'name', 'debt_amt', 'credit_amt'].map((k) => ({ ColTitle: k, ColType: 'Money', MetaData: [{ Name: 'ColKey', Value: k }] })) },
      Rows: { Row: [{ Header: { ColData: [{ value: 'x', id }] }, Rows: { Row: [{ ColData: [{ value: params.start_date }, { value: 'Expense' }, { value: 'Vendor' }, { value: '10.00' }, { value: '' }] }] }, type: 'Section' }] }
    };
  };
  g.syncAccountGroups_ = () => g.buildGroupLookup_([]);
  g.loadVendorContext_ = () => ({ aliases: [], vendors: [], mentions: [] });
  g.writeActualsCompanions_ = () => {};
  const out = plain(g.buildActuals_({ realmId: '1', period: 'Total', layout: 'schedule', accountingMethod: 'Accrual', filters: {} },
    { start: '2026-09-01', end: '2026-09-30' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  assert.ok(calls.length > 1, 'split into several requests');
  calls.forEach((p) => assert.ok(encodeURIComponent(p.account).length <= 1200));
  assert.equal(calls.reduce((n, p) => n + p.account.split(',').length, 0), 250, 'every account requested once');
  assert.deepEqual(out.rows.find((r) => r[0] === 'Grand total'), ['Grand total', '', '', calls.length * 10]);
});

test('a report with too many ticked filters explains the limit', () => {
  const g = load();
  assert.throws(() => g.buildReportParams_({ report: 'GeneralLedger', filters: { account: ids(200) } }, { start: '2026-09-01', end: '2026-09-30' }, '2026-10-26'),
    /Too many items are ticked.*GL actuals by month/);
  assert.doesNotThrow(() => g.buildReportParams_({ report: 'GeneralLedger', filters: { account: ids(20) } }, { start: '2026-09-01', end: '2026-09-30' }, '2026-10-26'));
});
