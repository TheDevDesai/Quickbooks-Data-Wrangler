const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const VENDORS = ['HubSpot, Inc.', 'Signalwise Insights Inc.', 'DataCrate Technologies LLC', 'LinkedIn Corporation (V)', 'Google Ads',
  'Google Cloud', 'Rippling', 'Kessler Brandt LLP', 'Brightframe Media, LLC', 'DeviceDesk Software', 'Atlassian', 'Apple'];

function ctx(g, aliases) {
  const vendors = g.buildVendorIndex_(VENDORS);
  return { aliases: g.parseAliasRows_(aliases || []), vendors, mentions: g.buildMentionIndex_(vendors) };
}
const resolve = (g, c, memo, extra) => plain(g.resolveVendor_(Object.assign({ name: '', memo, txnType: 'Journal Entry', date: '2026-03-31' }, extra || {}), c));

test('memo formats from the books resolve to the QuickBooks vendor (parse + fuzzy, no aliases)', () => {
  const g = load(), c = ctx(g);
  const cases = [
    ['Amortisation for HubSpot for Jan 26', 'HubSpot, Inc.'],
    ['Amortisation for Signalwise Insights Inc. for Feb 26', 'Signalwise Insights Inc.'],
    ['Hubspot - Amortization for April 2026', 'HubSpot, Inc.'],
    ['Hubspot-Amortization for the month of Aug-26', 'HubSpot, Inc.'],
    ['DataCrate Technologies LLC-Amortization for the month of Sep-26', 'DataCrate Technologies LLC'],
    ['LinkedIn Corporation (V) - Amortization for May 2026', 'LinkedIn Corporation (V)'],
    ['[Jan to Jun 2026] Google Ad Charges', 'Google Ads'],
    ['July - Google Ads transaction reclass', 'Google Ads'],
    ['[Jun 2026] 06/12/2026 Expense DeviceDesk Software', 'DeviceDesk Software'],
    ['[Jun 2026] Atlassin Charges', 'Atlassian'],                         // typo still matches
    ['Brightframe Media, LLC\n-Amortisation for Aug', 'Brightframe Media, LLC'] // vendor on line 1
  ];
  cases.forEach(([memo, vendor]) => {
    const r = resolve(g, c, memo);
    assert.equal(r.vendor, vendor, memo);
    assert.equal(r.source, 'Memo – parsed', memo);
  });
});

test('Name on the line always wins and is kept as is', () => {
  const g = load();
  assert.deepEqual(resolve(g, ctx(g), 'Amortisation for HubSpot for Jan 26', { name: 'Some Vendor' }),
    { vendor: 'Some Vendor', source: 'QBO Name', parsed: '' });
});

test('aliases come before parsing, map onto the QuickBooks name, and accept regexes', () => {
  const g = load(), c = ctx(g, [['hubspot', 'HubSpot Inc'], ['/hub\\s?spot crm/', 'Not used: shorter alias is checked second'], ['signalwise', 'Signalwise Insights Inc']]);
  assert.deepEqual(resolve(g, c, 'Hubspot-Amortization for the month of Aug-26'), { vendor: 'HubSpot, Inc.', source: 'Memo – alias', parsed: '' });
  assert.equal(resolve(g, c, 'Amortisation for Signalwise Insights Inc. for Feb 26').vendor, 'Signalwise Insights Inc.');
  const r = plain(g.parseAliasRows_([['/acme\\d+/', 'Acme'], ['bad /(', 'x'], ['', 'y']]));
  assert.equal(r.length, 2);
  assert.equal(g.matchAlias_(g.parseAliasRows_([['/acme\\d+/', 'Acme']]), 'paid ACME42 invoice'), 'Acme');
  assert.equal(g.matchAlias_(g.parseAliasRows_([['google ad', 'Google Ads']]), 'Google Adsense'), '', 'whole words only');
});

test('rules tag entries that are not vendor spend', () => {
  const g = load(), c = ctx(g);
  const cases = [
    ['[Rippling] 1099 Payment for dept: Marketing', 'Rippling (payroll)'],
    ['AES Expenses for March 2026', 'Event – AES Mar-26'],
    ['ACS deposit', 'Event – ACS Mar-26'],                                        // month from the line date
    ['Engineering_Sum of Salary (amount USD)_Engineering', 'Payroll'],
    ['US Emlpoyees PTO', 'Payroll'],
    ['To capitalize prepaid commission for Jan 2026 for Product A/B', 'Commissions (deferred / amortized)'],
    ['Amortization on Intangible Assets ($600,000/60) to Dec 2026', 'Amortization / depreciation'],
    ['Dep for May 2026', 'Amortization / depreciation'],
    ['Sender Charges against Invoice No. 1824', 'Bank charges'],
    ['Business Travel expense Reimburesement', 'Employee reimbursements']
  ];
  cases.forEach(([memo, vendor]) => {
    const r = resolve(g, c, memo);
    assert.equal(r.vendor, vendor, memo);
    assert.equal(r.source, 'Rule', memo);
  });
});

test('a vendor named anywhere beats a generic accrual tag; otherwise accruals and reclasses are tagged', () => {
  const g = load(), c = ctx(g);
  assert.deepEqual(resolve(g, c, 'To accrue for July expense - Kessler Brandt estimated amount'),
    { vendor: 'Kessler Brandt LLP', source: 'Memo – parsed', parsed: '' });
  assert.equal(resolve(g, c, 'To reverse accrued audit fee').vendor, 'Accrual / reversal');
  assert.equal(resolve(g, c, 'to reclass event tickets deposits for AR invoices - Feb 2026').vendor, 'Reclass (JE)');
  assert.equal(resolve(g, c, 'Paid Apple for laptops').vendor, 'Unresolved JE', 'short names are not matched anywhere in a memo');
});

test('leftovers: parsed text that matches no vendor, then Unresolved; both are exceptions', () => {
  const g = load(), c = ctx(g);
  const r1 = resolve(g, c, 'Amortisation for Acme Widgets for Mar 26');
  assert.deepEqual(r1, { vendor: 'Acme Widgets', source: 'Memo – parsed (not in vendor list)', parsed: 'Acme Widgets' });
  const r2 = resolve(g, c, 'Invoice - 1839');
  assert.deepEqual(r2, { vendor: 'Unresolved JE', source: 'Unresolved', parsed: '' });
  assert.equal(resolve(g, c, '', { txnType: 'Expense' }).vendor, 'Unresolved');
  assert.ok(g.isVendorException_(r1.source) && g.isVendorException_(r2.source));
  assert.equal(g.parseMemoVendor_('Contractor-Amortisation for Aug'), 'Contractor', 'a bare month is never taken as the vendor');
  assert.equal(g.parseMemoVendor_('[Jun 2026] 06/27/2026 Expense Microsoft'), 'Microsoft');
});

test('vendor names normalize across suffixes, punctuation and case', () => {
  const g = load();
  assert.equal(g.normalizeVendor_('LinkedIn Corporation (V)'), 'linkedin');
  assert.equal(g.normalizeVendor_('Signalwise Insights Inc.'), 'signalwise insights');
  assert.equal(g.normalizeVendor_('Brick & Barrel One, LLC'), 'brick and barrel one');
  const idx = g.buildVendorIndex_(['DataCrate Technologies LLC', 'Google', 'Google Cloud']);
  assert.equal(g.fuzzyMatchVendor_('datacrate', idx), 'DataCrate Technologies LLC');
  assert.equal(g.fuzzyMatchVendor_('Totally Different Co', idx), '');
});

test('finance follow-ups: Hartwell, Quillon Tech (misspelled), GlobalPay intercompany, Jordan Rivera, LASI', () => {
  const g = load();
  const vendors = g.buildVendorIndex_(['Hartwell & Lowe LLP', 'Quillon Tech', 'GlobalPay', 'Jordan A Rivera', 'Ledger Assist Services Inc.']);
  const c = { aliases: g.parseAliasRows_(g.DEFAULT_VENDOR_ALIASES_), vendors, mentions: g.buildMentionIndex_(vendors),
    overrides: g.buildVendorOverrides_(g.DEFAULT_VENDOR_ALIASES_, vendors) };
  const r = (memo) => plain(g.resolveVendor_({ name: '', memo, txnType: 'Journal Entry', date: '2026-08-31' }, c));
  assert.equal(r('Hartwell duplicate bill - added back').vendor, 'Hartwell & Lowe LLP');
  assert.equal(r('Quyllan Tech - June 15th to Aug 31st').vendor, 'Quillon Tech');
  assert.equal(r('06/09/2026 Expense Interco GlobalPay [Funding REF-0001] GlobalPay, Inc. PURCHASE').vendor, 'GlobalPay (intercompany)',
    'an alias keeps its own label instead of collapsing onto "GlobalPay"');
  assert.equal(r('Jordan Rivera\nContractor-Amortisation for Aug').vendor, 'Jordan A Rivera');
  assert.equal(r('LASI-0370').vendor, 'Ledger Assist Services Inc.');
  // Overrides are by vendor, so they also cover the vendor's named bills.
  assert.equal(g.vendorAccountOverride_(c, 'Jordan A Rivera'), '7260 Finance Contractors');
  assert.equal(g.vendorAccountOverride_(c, 'Ledger Assist Services Inc.'), '7420 Audit/Accounting');
  assert.equal(g.vendorAccountOverride_(c, 'Hartwell & Lowe LLP'), '');
});

test('account fallback and the ER tax payroll rule', () => {
  const g = load(), c = { aliases: [], vendors: [], mentions: [] };
  const r = (memo, accountName) => plain(g.resolveVendor_({ name: '', memo, accountName, txnType: 'Journal Entry', date: '2026-01-31' }, c));
  assert.deepEqual(r('Invoice - 1839', '7280 Bad Debt Expense'), { vendor: 'Bad debt / write-off', source: 'Rule', parsed: '' });
  assert.equal(r('', '7950 Depreciation – PP&E').vendor, 'Amortization / depreciation');
  assert.equal(r('Sales and Account Management_ER tax_Sales', '6115 Sales - Payroll Taxes').vendor, 'Payroll');
  assert.equal(r('Invoice - 1839', '7410 Legal Fees').vendor, 'Unresolved JE', 'only the account name decides the fallback');
});

test('override accounts can be named by number, number and name, or name', () => {
  const g = load();
  const accts = [{ Id: '1', AcctNum: '7260', Name: 'Finance Contractors' }, { Id: '2', AcctNum: '7420', Name: 'Audit/Accounting' }];
  assert.equal(g.findAccountByText_(accts, '7260').Id, '1');
  assert.equal(g.findAccountByText_(accts, '7420 Audit/Accounting').Id, '2');
  assert.equal(g.findAccountByText_(accts, 'audit / accounting').Id, '2');
  assert.equal(g.findAccountByText_(accts, '99999 Nope'), null);
});

test('alias examples: miscoded event ticket, contractor refund wires, reimbursed BD dinners', () => {
  const g = load();
  const vendors = g.buildVendorIndex_(['Casey Lin']);
  const c = { aliases: g.parseAliasRows_(g.DEFAULT_VENDOR_ALIASES_), vendors, mentions: g.buildMentionIndex_(vendors), overrides: {} };
  const r = (memo, txnType, accountName) => plain(g.resolveVendor_({ name: '', memo, txnType, accountName, date: '2026-06-24' }, c));
  assert.equal(r('Event ticket accidientally coded here [adjustment likely done directly to the invoice]', 'Journal Entry', '6520 Content & Media Production').vendor,
    'Event revenue (miscoded)');
  assert.deepEqual(r('WT FIRST EXAMPLE BANK, N.A. MarchInvoice 006 10000001', 'Deposit', '6110 Engineering – Salaries & Wages'),
    { vendor: 'Casey Lin', source: 'Memo – alias', parsed: '' });
  assert.equal(r('WT FIRST EXAMPLE BANK, N.A. INV 7 May 2026 10000002', 'Deposit', '6110 Engineering – Salaries & Wages').vendor, 'Casey Lin');
  assert.notEqual(r('WT FIRST EXAMPLE BANK, N.A. Software Service 10000003', 'Deposit', '6160 Engineering Contractor').vendor, 'Casey Lin');
  ['SQ *SAMPLE STEAKHOUSE NEW YORK NY', 'SAMPLE HOTEL LISBOA', 'CITY CAB 00-000000 LAS VEGAS NV'].forEach((memo) => {
    assert.deepEqual(r(memo, 'Expense', '7000 G&A:7930 Meals and Entertainment'), { vendor: 'Hosted BD dinners & travel (reimbursed)', source: 'Rule', parsed: '' }, memo);
  });
  assert.equal(r('NOODLE HOUSE SAN JOSE CA', 'Expense', '7910 Sales Travel').vendor, 'Hosted BD dinners & travel (reimbursed)');
  assert.equal(r('Unexplained', 'Journal Entry', '7930 Meals and Entertainment').vendor, 'Unresolved JE', 'journal entries are not tagged as dinners');
});
