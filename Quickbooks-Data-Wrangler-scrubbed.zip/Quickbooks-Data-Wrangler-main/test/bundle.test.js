const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { build, DIST } = require('../scripts/bundle');

test('dist/ matches src/ (run `npm run bundle` after editing src/)', () => {
  Object.entries(build()).forEach(([name, text]) => {
    assert.equal(fs.readFileSync(path.join(DIST, name), 'utf8'), text, 'dist/' + name + ' is out of date');
  });
});

test('bundled Code.gs parses and defines the menu and panel entry points', () => {
  const code = build()['Code.gs'];
  const ctx = vm.createContext({});
  vm.runInContext(code, ctx);
  ['onOpen', 'onInstall', 'showSidebar', 'showConnectDialog', 'menuSyncNow', 'authCallback', 'getSidebarState', 'runPull']
    .forEach((fn) => assert.equal(typeof ctx[fn], 'function', fn));
});
