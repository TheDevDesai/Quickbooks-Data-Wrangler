const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const col = (key, title, type) => ({ ColTitle: title, ColType: type || 'Money', MetaData: [{ Name: 'ColKey', Value: key }] });
const cell = (value, id) => (id ? { value, id } : { value });
const ACCOUNTS = [
  { Id: '603', AcctNum: '6390', Name: 'Marketing Software', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '123', AcctNum: '1310', Name: 'Prepaid – Service Subscriptions', AccountType: 'Other Current Asset', Classification: 'Asset' }
];
const COLS = ['tx_date', 'txn_type', 'doc_num', 'name', 'memo', 'debt_amt', 'credit_amt'];
/** sections: [[accountId, label, [[date, type, num, name, memo, debit, credit]]]] */
function gl(sections) {
  return {
    Header: {}, Columns: { Column: COLS.map((k) => col(k, k, /amt/.test(k) ? 'Money' : 'String')) },
    Rows: { Row: sections.map(([id, label, lines]) => ({
      Header: { ColData: [cell(label, id)].concat(COLS.slice(1).map(() => cell(''))) },
      Rows: { Row: lines.map((l) => ({ ColData: [cell(l[0]), cell(l[1], 'tx' + l[2]), cell(l[2]), cell(l[3]), cell(l[4]), cell(l[5] ? l[5].toFixed(2) : ''), cell(l[6] ? l[6].toFixed(2) : '')] })) },
      type: 'Section'
    })) }
  };
}
const SEP = [
  ['603', '6390 Marketing Software', [
    ['2026-09-01', 'Expense', '', 'HubSpot, Inc.', 'Monthly seat', 500, 0],
    ['2026-09-30', 'Journal Entry', '881', '', 'Hubspot-Amortization for the month of Sep-26', 2000, 0],
    ['2026-09-30', 'Journal Entry', '882', '', 'Amortisation for Signalwise Insights Inc. for Sep 26', 1000, 0],
    ['2026-09-30', 'Journal Entry', '883', '', 'Misc true-up', 40, 0]]],
  // A prepaid line, even if returned, is never part of the expense view.
  ['123', '1310 Prepaid – Service Subscriptions', [['2026-09-02', 'Bill', '77', 'HubSpot, Inc.', 'Annual renewal', 24000, 0]]]
];

function setup(g, pnlSep) {
  const companions = [];
  g.qboQueryAll_ = () => ACCOUNTS;
  g.qboGet_ = () => ({});
  g.qboReport_ = (realm, name, params) => name === 'ProfitAndLoss' ? {
    Columns: { Column: [col('account', '', 'Account'), { ColTitle: 'Sep 2026', ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: '2026-09-01' }] }, col('total', 'Total')] },
    Rows: { Row: [{ ColData: [cell('6390 Marketing Software', '603'), cell(pnlSep.toFixed(2)), cell(pnlSep.toFixed(2))] }] }
  } : gl(SEP);
  g.syncAccountGroups_ = () => g.buildGroupLookup_([['6390', '', 'Sales & Marketing', '']]);
  const vendors = g.buildVendorIndex_(['HubSpot, Inc.', 'Signalwise Insights Inc.']);
  g.loadVendorContext_ = () => ({ aliases: [], vendors, mentions: g.buildMentionIndex_(vendors) });
  g.writeActualsCompanions_ = (...a) => companions.push(plain(a));
  return companions;
}
const RUN = (g, layout) => plain(g.buildActuals_({ realmId: '1', period: 'Month', layout, accountingMethod: 'Accrual', sheetName: 'GL detail', filters: {} },
  { start: '2026-09-01', end: '2026-09-30' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));

test('detail layout: resolved vendor, source, memo and JE number per line; QBO Name untouched', () => {
  const g = load();
  const companions = setup(g, 3540);
  const out = RUN(g, 'detail');
  assert.deepEqual(out.header, ['Date', 'Month', 'GL Group', 'Account Number', 'GL Account', 'Transaction Type', 'JE / Doc Number',
    'QBO Name', 'Resolved Vendor', 'Vendor Source', 'Original Memo', 'Amount', 'Reclassed from']);
  assert.deepEqual(out.rows, [
    ['2026-09-01', 'Sep 2026', 'Sales & Marketing', '6390', '6390 Marketing Software', 'Expense', '', 'HubSpot, Inc.', 'HubSpot, Inc.', 'QBO Name', 'Monthly seat', 500, ''],
    ['2026-09-30', 'Sep 2026', 'Sales & Marketing', '6390', '6390 Marketing Software', 'Journal Entry', '881', '', 'HubSpot, Inc.', 'Memo – parsed', 'Hubspot-Amortization for the month of Sep-26', 2000, ''],
    ['2026-09-30', 'Sep 2026', 'Sales & Marketing', '6390', '6390 Marketing Software', 'Journal Entry', '882', '', 'Signalwise Insights Inc.', 'Memo – parsed', 'Amortisation for Signalwise Insights Inc. for Sep 26', 1000, ''],
    ['2026-09-30', 'Sep 2026', 'Sales & Marketing', '6390', '6390 Marketing Software', 'Journal Entry', '883', '', 'Unresolved JE', 'Unresolved', 'Misc true-up', 40, '']
  ]);
  assert.ok(!out.rows.some((r) => r[4].startsWith('1310')), 'prepaid bill is not counted');
  const [sheetName, tieOut, exceptions, explorerPeriods] = companions[0];
  assert.equal(sheetName, 'GL detail');
  assert.equal(tieOut.totalAbsDiff, 0);
  assert.deepEqual(exceptions.rows, [['2026-09-30', '6390 Marketing Software', 'Journal Entry', '883', 40, 'Misc true-up', '']]);
  assert.equal(explorerPeriods.length, 1, 'explorer is built for the detail layout');
});

test('grouped layout puts amortization under the real vendor and ends with a zero check row', () => {
  const g = load();
  setup(g, 3540);
  const out = RUN(g, 'schedule');
  const vendorRows = out.rows.filter((r, i) => out.rowKinds[i] === 'data').map((r) => [r[2], r[3]]);
  assert.deepEqual(vendorRows, [['HubSpot, Inc.', 2500], ['Signalwise Insights Inc.', 1000], ['Unresolved JE', 40]]);
  assert.deepEqual(out.rows[out.rows.length - 1], ['Check vs QuickBooks P&L (should be 0)', '', '', 0]);
  assert.equal(out.warning, '');
});

test('tie-out flags a difference from the QuickBooks P&L', () => {
  const g = load();
  const companions = setup(g, 3250);
  const out = RUN(g, 'schedule');
  assert.match(out.warning, /1 account-month\(s\) differ from the QuickBooks P&L: 6390 Marketing Software Sep 2026: 290.00/);
  assert.deepEqual(out.rows[out.rows.length - 1], ['Check vs QuickBooks P&L (should be 0)', '', '', 290]);
  const tie = companions[0][1];
  assert.deepEqual(tie.rows, [['6390 Marketing Software', 'Sep 2026', 3250, 3540, 290], ['Check: total of differences (should be 0)', '', '', '', 290]]);
});

test('P&L month columns map onto quarters', () => {
  const g = load();
  const periods = plain(g.buildPeriods_('2026-01-01', '2026-06-30', 'Quarter', 1));
  const month = (s) => ({ ColTitle: s, ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: s }] });
  const report = { Columns: { Column: [col('a', '', 'Account'), month('2026-01-01'), month('2026-02-01'), month('2026-04-01'), col('total', 'Total')] },
    Rows: { Row: [{ ColData: [cell('x', '9'), cell('10.00'), cell('5.00'), cell('7.00'), cell('22.00')] }] } };
  assert.deepEqual(plain(g.parsePnlByAccountPeriod_(report, periods)), { 9: [15, 7] });
});

test('prepaid roll forward by vendor: opening + additions - amortization = ending, tied to the Trial Balance', () => {
  const g = load();
  const prepaid = { Id: '123', AcctNum: '1310', Name: 'Prepaid – Service Subscriptions', AccountType: 'Other Current Asset', Classification: 'Asset' };
  g.qboQueryAll_ = () => [prepaid, ACCOUNTS[0]];
  g.qboGet_ = () => ({});
  const vendors = g.buildVendorIndex_(['HubSpot, Inc.', 'Signalwise Insights Inc.']);
  g.loadVendorContext_ = () => ({ aliases: [], vendors, mentions: g.buildMentionIndex_(vendors) });
  const calls = [];
  g.qboReport_ = (realm, name, params) => {
    calls.push(Object.assign({ report: name }, plain(params)));
    if (name === 'TrialBalance') return { Columns: { Column: [col('a', '', 'Account'), col('d', 'Debit'), col('c', 'Credit')] },
      Rows: { Row: [{ ColData: [cell('1310', '123'), cell('30000.00'), cell('')] }] } };
    const lines = params.start_date === '2000-01-01'
      ? [['2026-07-01', 'Bill', '1', 'Signalwise Insights Inc.', 'Annual', 12000, 0], ['2026-08-31', 'Journal Entry', '2', '', 'Amortisation for Signalwise Insights Inc. for Aug 26', 0, 1000]]
      : [['2026-09-02', 'Bill', '3', 'HubSpot, Inc.', 'Annual renewal', 24000, 0],
        ['2026-09-30', 'Journal Entry', '4', '', 'Hubspot-Amortization for the month of Sep-26', 0, 2000],
        ['2026-09-30', 'Journal Entry', '5', '', 'Amortisation for Signalwise Insights Inc. for Sep 26', 0, 1000]];
    return gl([['123', '1310 Prepaid – Service Subscriptions', lines]]);
  };
  const out = plain(g.buildRollForward_({ realmId: '1', rollforwardBy: 'prepaid', period: 'Month', layout: 'schedule', accountingMethod: 'Accrual', filters: {} },
    { start: '2026-09-01', end: '2026-09-30' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  assert.equal(calls[0].account, '123', 'only prepaid accounts are read');
  assert.deepEqual(out.header, ['Vendor', 'Beginning Balance', 'Additions', 'Amortization', 'Ending Balance']);
  assert.deepEqual(out.rows, [
    ['HubSpot, Inc.', 0, 24000, 2000, 22000],
    ['Signalwise Insights Inc.', 11000, 0, 1000, 10000],
    ['Total', 11000, 24000, 3000, 32000]
  ]);
  assert.match(out.warning, /differs from the Trial Balance 30000.00/);
});

test('vendor override reports the vendor under another account; tie-out still checks posted accounts', () => {
  const g = load();
  const accts = [
    { Id: '714', AcctNum: '7410', Name: 'Legal Fees', AccountType: 'Expense', Classification: 'Expense' },
    { Id: '742', AcctNum: '7420', Name: 'Audit/Accounting', AccountType: 'Expense', Classification: 'Expense' }
  ];
  const companions = [];
  g.qboQueryAll_ = () => accts;
  g.qboGet_ = () => ({});
  g.qboReport_ = (realm, name) => name === 'ProfitAndLoss' ? {
    Columns: { Column: [col('account', '', 'Account'), { ColTitle: 'Sep 2026', ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: '2026-09-01' }] }] },
    Rows: { Row: [{ ColData: [cell('7410 Legal Fees', '714'), cell('1300.00')] }] }
  } : gl([['714', '7410 Legal Fees', [
    ['2026-09-15', 'Bill', 'B1', 'Ledger Assist Services Inc.', 'Inv LASI-0412', 400, 0],
    ['2026-09-30', 'Journal Entry', '3241', '', 'LASI-0434', 0, 100],
    ['2026-09-20', 'Bill', 'B2', 'Hartwell & Lowe LLP', 'Sept legal', 1000, 0]]]]);
  g.syncAccountGroups_ = () => g.buildGroupLookup_([['7410', '', 'G&A', ''], ['7420', '', 'G&A', '']]);
  const vendors = g.buildVendorIndex_(['Ledger Assist Services Inc.', 'Hartwell & Lowe LLP']);
  const rows = [['LASI', 'Ledger Assist Services Inc.', '7420 Audit/Accounting']];
  g.loadVendorContext_ = () => ({ aliases: g.parseAliasRows_(rows), vendors, mentions: [], overrides: g.buildVendorOverrides_(rows, vendors) });
  g.writeActualsCompanions_ = (...a) => companions.push(plain(a));
  const run = (layout) => plain(g.buildActuals_({ realmId: '1', period: 'Month', layout, accountingMethod: 'Accrual', sheetName: 'GL', filters: {} },
    { start: '2026-09-01', end: '2026-09-30' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  const sched = run('schedule');
  const lines = sched.rows.filter((r, i) => sched.rowKinds[i] === 'data').map((r) => [r[1], r[2], r[3]]);
  assert.deepEqual(lines, [['7410 Legal Fees', 'Hartwell & Lowe LLP', 1000], ['7420 Audit/Accounting', 'Ledger Assist Services Inc.', 300]]);
  assert.equal(companions[0][1].totalAbsDiff, 0, 'tie-out compares posted accounts, so the move does not break it');
  assert.equal(sched.warning, '');
  const detail = run('detail');
  const lasi = detail.rows.filter((r) => r[8] === 'Ledger Assist Services Inc.');
  assert.deepEqual(lasi.map((r) => [r[4], r[11], r[12]]), [['7420 Audit/Accounting', 400, '7410 Legal Fees'], ['7420 Audit/Accounting', -100, '7410 Legal Fees']]);
});
