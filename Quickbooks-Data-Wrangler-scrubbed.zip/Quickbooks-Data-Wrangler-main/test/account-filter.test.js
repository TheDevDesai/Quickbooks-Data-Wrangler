const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');
const { fixture } = load;

const plain = (x) => JSON.parse(JSON.stringify(x));
// Account labels and amounts from the "report" layout, indentation removed.
const lines = (report) => plain(load().flattenReport(report, 'report')).rows.map((r) => [r[0].trim(), r[1], r[2], r[3]]);

test('picking a parent account keeps its sub-accounts and recalculates totals', () => {
  const g = load();
  const out = g.filterReportByAccounts(fixture('pnl_by_month.json'), ['60']); // 6000 Payroll
  assert.deepEqual(lines(out), [
    ['Expenses', '', '', ''],
    ['6000 Payroll', 50, '', 50],          // parent's own postings stay because it was chosen
    ['6010 Wages', 400, 400, 800],
    ['Total 6000 Payroll', 450, 400, 850],
    ['Total Expenses', 450, 400, 850]      // only the chosen accounts; Income, Gross Profit, Net Income dropped
  ]);
});

test('picking only a sub-account drops the parent own postings', () => {
  const g = load();
  const out = g.filterReportByAccounts(fixture('pnl_by_month.json'), ['61']); // 6010 Wages
  assert.deepEqual(lines(out), [
    ['Expenses', '', '', ''],
    ['6000 Payroll', '', '', ''],
    ['6010 Wages', 400, 400, 800],
    ['Total 6000 Payroll', 400, 400, 800],
    ['Total Expenses', 400, 400, 800]
  ]);
});

test('accounts from different sections, in table layout, with the original untouched', () => {
  const g = load();
  const original = fixture('pnl_by_month.json');
  const before = JSON.stringify(original);
  const out = g.filterReportByAccounts(original, ['45', '65']);
  assert.equal(JSON.stringify(original), before);
  const table = plain(g.flattenReport(out, 'table'));
  assert.deepEqual(table.rows, [
    ['Income', '4000 Services', '45', 1000, 1500.5, 2500.5],
    ['Expenses', '6500 Rent', '65', -25, 300, 275]
  ]);
  assert.deepEqual(lines(out).filter((r) => r[0].startsWith('Total')), [
    ['Total Income', 1000, 1500.5, 2500.5],
    ['Total Expenses', -25, 300, 275]
  ]);
});

test('no matching accounts gives an empty report', () => {
  const g = load();
  assert.deepEqual(plain(g.flattenReport(g.filterReportByAccounts(fixture('pnl_by_month.json'), ['999']), 'table')).rows, []);
});

test('account filter is applied in the sheet, not sent to QuickBooks, for the P&L', () => {
  const g = load();
  const pull = { report: 'ProfitAndLoss', accountingMethod: 'Accrual', filters: { account: ['60'], class: ['3'] } };
  const params = plain(g.buildReportParams_(pull, { start: '2026-09-01', end: '2026-09-30' }, '2026-10-26'));
  assert.equal(params.account, undefined);
  assert.equal(params.class, '3');
  // General Ledger still sends it to QuickBooks.
  const gl = plain(g.buildReportParams_({ report: 'GeneralLedger', filters: { account: ['60'] } }, { start: '2026-09-01', end: '2026-09-30' }, '2026-10-26'));
  assert.equal(gl.account, '60');
});
