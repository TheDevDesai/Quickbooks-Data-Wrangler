const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');
const { fixture } = load;

const g = load();
// Values created inside the VM have that realm's prototypes; normalize before deep comparisons.
const plain = (x) => JSON.parse(JSON.stringify(x));

test('date presets', () => {
  const r = (preset, today, fsm) => plain(g.resolveDateRange({ preset }, today, fsm));
  assert.deepEqual(r('last_month', '2026-03-15'), { start: '2026-02-01', end: '2026-02-28' });
  assert.deepEqual(r('last_month', '2026-01-10'), { start: '2025-12-01', end: '2025-12-31' });
  assert.deepEqual(r('this_quarter', '2026-11-02'), { start: '2026-10-01', end: '2026-12-31' });
  assert.deepEqual(r('last_quarter', '2026-02-02'), { start: '2025-10-01', end: '2025-12-31' });
  assert.deepEqual(r('this_year_to_date', '2026-05-09'), { start: '2026-01-01', end: '2026-05-09' });
  assert.deepEqual(r('last_12_months', '2026-03-15'), { start: '2025-03-01', end: '2026-02-28' });
  assert.deepEqual(r('trailing_12_months', '2026-03-15'), { start: '2025-04-01', end: '2026-03-15' });
  assert.deepEqual(r('this_month', '2024-02-10'), { start: '2024-02-01', end: '2024-02-29' });
  // Fiscal year starting July
  assert.deepEqual(r('this_fiscal_year', '2026-03-15', 7), { start: '2025-07-01', end: '2026-06-30' });
  assert.deepEqual(r('this_fiscal_year', '2026-07-01', 7), { start: '2026-07-01', end: '2027-06-30' });
  assert.deepEqual(r('last_fiscal_year', '2026-03-15', 7), { start: '2024-07-01', end: '2025-06-30' });
  assert.deepEqual(r('this_fiscal_year_to_date', '2026-03-15', 7), { start: '2025-07-01', end: '2026-03-15' });
  assert.deepEqual(r('all_dates', '2026-03-15'), { start: '', end: '' });
  assert.deepEqual(plain(g.resolveDateRange({ preset: 'custom', start: '2026-01-01', end: '2026-01-31' }, '2026-03-15')),
    { start: '2026-01-01', end: '2026-01-31' });
  assert.throws(() => g.resolveDateRange({ preset: 'custom', start: '2026-02-01', end: '2026-01-31' }, '2026-03-15'));
  assert.equal(g.monthNameToNumber_('October'), 10);
});

test('report layout keeps QuickBooks structure with totals', () => {
  const out = plain(g.flattenReport(fixture('pnl_by_month.json'), 'report', { companyName: 'Acme' }));
  assert.deepEqual(out.header, ['Account', 'Jan 2026', 'Feb 2026', 'Total']);
  assert.deepEqual(out.types, ['text', 'number', 'number', 'number']);
  assert.deepEqual(out.title, ['Profit And Loss', 'Acme', '2026-01-01 to 2026-02-28', 'Accrual basis']);
  const labels = out.rows.map((r) => r[0]);
  assert.deepEqual(labels, [
    'Income', '    4000 Services', '    4100 Product Sales', 'Total Income', 'Gross Profit',
    'Expenses', '    6000 Payroll', '        6010 Wages', '    Total 6000 Payroll', '    6500 Rent',
    'Total Expenses', 'Net Income'
  ]);
  assert.deepEqual(out.rows[1], ['    4000 Services', 1000, 1500.5, 2500.5]);
  assert.deepEqual(out.rows[2], ['    4100 Product Sales', '', 200, 200]);
  assert.equal(out.rowKinds[3], 'summary');
  assert.equal(out.rowKinds[0], 'header');
});

test('table layout has section paths, ids, and no subtotals', () => {
  const out = plain(g.flattenReport(fixture('pnl_by_month.json'), 'table'));
  assert.deepEqual(out.header, ['Level 1', 'Level 2', 'Account', 'Account ID', 'Jan 2026', 'Feb 2026', 'Total']);
  assert.deepEqual(out.rows, [
    ['Income', '', '4000 Services', '45', 1000, 1500.5, 2500.5],
    ['Income', '', '4100 Product Sales', '46', '', 200, 200],
    ['Expenses', '', '6000 Payroll', '60', 50, '', 50], // parent account's own postings
    ['Expenses', '6000 Payroll', '6010 Wages', '61', 400, 400, 800],
    ['Expenses', '', '6500 Rent', '65', -25, 300, 275]
  ]);
  // Totals of the table equal QuickBooks' Net Income only for income minus expenses; check expense sum.
  const expenseTotal = out.rows.filter((r) => r[0] === 'Expenses').reduce((s, r) => s + r[6], 0);
  assert.equal(expenseTotal, 1125);
});

test('long layout unpivots periods and skips Total and blanks', () => {
  const out = plain(g.flattenReport(fixture('pnl_by_month.json'), 'long'));
  assert.deepEqual(out.header, ['Level 1', 'Level 2', 'Account', 'Account ID', 'Column', 'Period Start', 'Period End', 'Value']);
  assert.deepEqual(out.rows[0], ['Income', '', '4000 Services', '45', 'Jan 2026', '2026-01-01', '2026-01-31', 1000]);
  assert.equal(out.rows.length, 8); // 10 cells minus 2 blanks
  assert.equal(out.rows.reduce((s, r) => s + r[7], 0), 2700.5 + 1125);
  assert.equal(out.rows.some((r) => r[4] === 'Total'), false);
});

test('general ledger table keeps account as level and text doc numbers', () => {
  const out = plain(g.flattenReport(fixture('general_ledger.json'), 'table'));
  assert.deepEqual(out.header, ['Level 1', 'Date', 'Transaction Type', 'Transaction Type ID', 'Num', 'Name', 'Name ID', 'Amount', 'Balance']);
  assert.deepEqual(out.types, ['text', 'date', 'text', 'text', 'text', 'text', 'text', 'number', 'number']);
  assert.deepEqual(out.rows[1], ['1000 Checking', '2026-01-05', 'Deposit', '130', '00123', 'Acme Co', '7', 250, 5250]);
  assert.equal(out.rows[0][1], 'Beginning Balance');
});

test('empty report', () => {
  const out = plain(g.flattenReport({ Header: { ReportName: 'ProfitAndLoss', Option: [{ Name: 'NoReportData', Value: 'true' }] }, Columns: { Column: [] }, Rows: {} }, 'table'));
  assert.deepEqual(out.rows, []);
});

test('entities flatten with refs, custom fields and expanded lines', () => {
  const records = fixture('journal_entries.json');
  const collapsed = plain(g.flattenEntities(records, {}));
  assert.equal(collapsed.rows.length, 1);
  assert.ok(collapsed.header.includes('Line[1].JournalEntryLineDetail.AccountRef.name'));

  const out = plain(g.flattenEntities(records, { expandLines: true }));
  assert.equal(out.rows.length, 2);
  assert.deepEqual(out.header.slice(0, 3), ['Id', 'TxnDate', 'DocNumber']);
  assert.ok(!out.header.includes('SyncToken') && !out.header.includes('domain'));
  const col = (name) => out.header.indexOf(name);
  assert.equal(out.rows[0][col('CustomField.Project')], 'Alpha');
  assert.equal(out.rows[1][col('Line.JournalEntryLineDetail.AccountRef.name')], '2100 Accrued Liabilities');
  assert.equal(out.rows[1][col('Line.JournalEntryLineDetail.PostingType')], 'Credit');
  assert.equal(out.types[col('DocNumber')], 'text');
  assert.equal(out.rows[0][col('DocNumber')], '0042');
  assert.equal(out.types[col('Line.Amount')], 'number');
  assert.equal(out.types[col('TxnDate')], 'date');
  assert.equal(out.types[col('Line.JournalEntryLineDetail.AccountRef.value')], 'text');
  assert.ok(col('MetaData.CreateTime') > col('Line.Amount'));
});

test('entity query building', () => {
  assert.equal(g.buildEntityQuery('Invoice', { start: '2026-01-01', end: '2026-01-31' }),
    "SELECT * FROM Invoice WHERE TxnDate >= '2026-01-01' AND TxnDate <= '2026-01-31'");
  assert.equal(g.buildEntityQuery('Account', { start: '2026-01-01', where: 'WHERE Active IN (true, false)' }),
    'SELECT * FROM Account WHERE Active IN (true, false)');
  assert.equal(g.buildEntityQuery('Customer', {}), 'SELECT * FROM Customer');
});

test('report params', () => {
  const pull = {
    report: 'ProfitAndLoss', accountingMethod: 'Cash', summarizeBy: 'Month',
    filters: { class: ['1', '2'], account: ['9'] }
  };
  assert.deepEqual(plain(g.buildReportParams_(pull, { start: '2026-01-01', end: '2026-03-31' }, '2026-04-02')), {
    start_date: '2026-01-01', end_date: '2026-03-31', accounting_method: 'Cash', summarize_column_by: 'Month', class: '1,2'
  });
  assert.deepEqual(plain(g.buildReportParams_({ report: 'AgedReceivables', filters: {} }, { start: '2026-03-01', end: '2026-03-31' }, '2026-04-02')),
    { report_date: '2026-03-31' });
  const gl = plain(g.buildReportParams_({ report: 'GeneralLedger', filters: {} }, { start: '', end: '' }, '2026-04-02'));
  assert.equal(gl.start_date, '1900-01-01');
  assert.equal(gl.end_date, '2026-04-02');
  assert.match(gl.columns, /^tx_date,/);
});

test('pull validation', () => {
  const base = { realmId: '123', source: 'report', report: 'BalanceSheet', dateRange: { preset: 'last_month' }, sheetName: 'BS' };
  const p = plain(g.normalizePull_(base));
  assert.equal(p.layout, 'report');
  assert.equal(p.name, 'Balance Sheet - Last month (Accrual)');
  assert.equal(p.accountingMethod, 'Accrual');
  assert.equal(plain(g.normalizePull_({ ...base, accountingMethod: 'Cash' })).accountingMethod, 'Cash');
  // Reports without a basis option (aging) and data lists carry no basis.
  assert.equal(plain(g.normalizePull_({ ...base, report: 'AgedPayables', accountingMethod: 'Cash' })).accountingMethod, '');
  assert.equal(plain(g.normalizePull_({ ...base, source: 'entity', entity: 'Bill', accountingMethod: 'Cash' })).accountingMethod, '');
  assert.throws(() => g.normalizePull_({ ...base, sheetName: 'a/b' }), /Tab names/);
  assert.throws(() => g.normalizePull_({ ...base, realmId: '' }), /company/);
  assert.equal(plain(g.normalizePull_({ ...base, source: 'entity', entity: 'Invoice', layout: 'long' })).layout, 'table');
});
