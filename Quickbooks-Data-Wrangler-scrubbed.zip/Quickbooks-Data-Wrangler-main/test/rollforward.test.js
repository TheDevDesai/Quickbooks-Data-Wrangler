const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const col = (key, title, type) => ({ ColTitle: title, ColType: type || 'Money', MetaData: [{ Name: 'ColKey', Value: key }] });
const cell = (value, id) => (id ? { value, id } : { value });

// --- Fixture builders shaped like QuickBooks Reports API JSON ---------------

const GL_COLUMNS = [col('tx_date', 'Date', 'Date'), col('name', 'Name', 'String'), col('debt_amt', 'Debit'), col('credit_amt', 'Credit')];

/** sections: [{id, name, lines: [[date, name, nameId, debit, credit]], children: [...]}] */
function glReport(sections) {
  const toRow = (s) => ({
    Header: { ColData: [cell(s.name, s.id), cell(''), cell(''), cell('')] },
    Rows: { Row: [
      { ColData: [cell('Beginning Balance'), cell(''), cell(''), cell('')], type: 'Data' },
      ...(s.lines || []).map(([d, n, nid, dr, cr]) => ({
        ColData: [cell(d), cell(n, nid), cell(dr ? dr.toFixed(2) : ''), cell(cr ? cr.toFixed(2) : '')], type: 'Data'
      })),
      ...(s.children || []).map(toRow)
    ] },
    Summary: { ColData: [cell('Total for ' + s.name), cell(''), cell(''), cell('')] },
    type: 'Section'
  });
  return { Header: { ReportName: 'GeneralLedger' }, Columns: { Column: GL_COLUMNS }, Rows: { Row: sections.map(toRow) } };
}

function tbReport(balances) {
  return {
    Header: { ReportName: 'TrialBalance' },
    Columns: { Column: [col('account', '', 'Account'), col('Debit', 'Debit'), col('Credit', 'Credit')] },
    Rows: { Row: [
      ...Object.entries(balances).map(([id, [name, bal]]) => ({
        ColData: [cell(name, id), cell(bal > 0 ? bal.toFixed(2) : ''), cell(bal < 0 ? (-bal).toFixed(2) : '')], type: 'Data'
      })),
      { Summary: { ColData: [cell('TOTAL'), cell(''), cell('')] }, type: 'Section', group: 'GrandTotal' }
    ] }
  };
}

function nameBalanceReport(rows) {
  return {
    Header: { ReportName: 'VendorBalance' },
    Columns: { Column: [col('vendor', '', 'Vendor'), col('total', 'Total')] },
    Rows: { Row: [
      ...rows.map(([id, name, bal]) => ({ ColData: [cell(name, id), cell(bal.toFixed(2))], type: 'Data' })),
      { Summary: { ColData: [cell('TOTAL'), cell('')] }, type: 'Section', group: 'GrandTotal' }
    ] }
  };
}

// --- Pure helpers ------------------------------------------------------------

test('periods follow calendar and fiscal boundaries', () => {
  const g = load();
  assert.deepEqual(plain(g.buildPeriods_('2026-01-01', '2026-03-31', 'Month', 1)).map((p) => [p.label, p.start, p.end, p.fiscalYearStart]), [
    ['Jan 2026', '2026-01-01', '2026-01-31', true],
    ['Feb 2026', '2026-02-01', '2026-02-28', false],
    ['Mar 2026', '2026-03-01', '2026-03-31', false]
  ]);
  // Fiscal year starting July, range starting mid-quarter: first period is clipped.
  assert.deepEqual(plain(g.buildPeriods_('2026-05-15', '2026-12-31', 'Quarter', 7)).map((p) => [p.label, p.start, p.end, p.fiscalYearStart]), [
    ['FY2026 Q4', '2026-05-15', '2026-06-30', false],
    ['FY2027 Q1', '2026-07-01', '2026-09-30', true],
    ['FY2027 Q2', '2026-10-01', '2026-12-31', false]
  ]);
  assert.deepEqual(plain(g.buildPeriods_('2025-01-01', '2026-06-30', 'Year', 1)).map((p) => p.label), ['FY2025', 'FY2026']);
  assert.equal(g.buildPeriods_('2026-01-01', '2026-03-31', 'Total', 1).length, 1);
  assert.equal(g.addDays_('2026-03-01', -1), '2026-02-28');
  assert.equal(g.fiscalYearStart_('2026-03-15', 7), '2025-07-01');
});

test('GL lines: nested accounts, beginning balance rows skipped', () => {
  const g = load();
  const lines = plain(g.parseGeneralLedgerLines_(glReport([
    { id: '60', name: '6000 Payroll', lines: [['2026-01-03', 'Gusto', '9', 10, 0]],
      children: [{ id: '61', name: '6010 Wages', lines: [['2026-01-15', 'Gusto', '9', 400, 0]] }] }
  ])));
  assert.deepEqual(lines.map((l) => [l.accountId, l.nameId, l.debit, l.credit]), [['60', '9', 10, 0], ['61', '9', 400, 0]]);
});

test('trial balance and name balance parsing', () => {
  const g = load();
  assert.deepEqual(plain(g.parseTrialBalance_(tbReport({ 35: ['Checking', 5000], 33: ['Accounts Payable', -1200] }))), { 35: 5000, 33: -1200 });
  // Rows without ids are resolved by name.
  const noIds = tbReport({ 35: ['Checking', 5000] });
  delete noIds.Rows.Row[0].ColData[0].id;
  assert.deepEqual(plain(g.parseTrialBalance_(noIds, (n) => (n === 'Checking' ? '35' : ''))), { 35: 5000 });
  assert.deepEqual(plain(g.parseNameBalances_(nameBalanceReport([['5', 'Acme', 100.5]]))), { 5: { name: 'Acme', balance: 100.5 } });
});

test('roll forward ties and closes P&L to retained earnings at fiscal year start', () => {
  const g = load();
  const periods = [
    { label: 'Dec 2025', start: '2025-12-01', end: '2025-12-31', fiscalYearStart: false, activity: { inc: { inc: 0, dec: 300 } } },
    { label: 'Jan 2026', start: '2026-01-01', end: '2026-01-31', fiscalYearStart: true, activity: { inc: { inc: 0, dec: 50 }, cash: { inc: 50, dec: 0 } } }
  ];
  const res = plain(g.computeRollForward_({
    entities: { inc: { pnl: true }, re: { retainedEarnings: true }, cash: {} },
    beginning: { inc: -1000, re: -5000, cash: 2000 },
    periods,
    closeYears: true
  }));
  // Income account (credit balance, negative): -1000 - 300 = -1300, then closes to 0, then -50.
  assert.deepEqual(res.inc.map((r) => [r.beginning, r.close, r.increases, r.decreases, r.ending]), [[-1000, 0, 0, 300, -1300], [-1300, 1300, 0, 50, -50]]);
  assert.deepEqual(res.re.map((r) => [r.beginning, r.close, r.ending]), [[-5000, 0, -5000], [-5000, -1300, -6300]]);
  assert.deepEqual(res.cash.map((r) => r.ending), [2000, 2050]);
  // Every row ties: beginning + close + increases - decreases = ending; next beginning = prior ending.
  Object.values(res).forEach((rows) => rows.forEach((r, i) => {
    assert.equal(Math.round((r.beginning + r.close + r.increases - r.decreases) * 100) / 100, r.ending);
    if (i) assert.equal(r.beginning, rows[i - 1].ending);
  }));
});

test('schedule and long layouts', () => {
  const g = load();
  const periods = plain(g.buildPeriods_('2026-01-01', '2026-02-28', 'Month', 1));
  periods[0].activity = { a: { inc: 100, dec: 40 } };
  periods[1].activity = { a: { inc: 10, dec: 0 }, b: { inc: 5, dec: 0 } };
  const results = g.computeRollForward_({ entities: {}, beginning: { a: 1000, z: 0 }, periods, closeYears: false });
  const entities = { a: { cols: ['Acme', 'a'], sort: 'acme' }, b: { cols: ['Beta', 'b'], sort: 'beta' }, z: { cols: ['Zero', 'z'], sort: 'zero' } };
  const spec = { dimension: 'vendor', entityHeader: ['Vendor', 'Vendor ID'], entities, results, periods, title: ['t'] };

  const sched = plain(g.layoutRollForward_({ ...spec, layout: 'schedule' }));
  assert.deepEqual(sched.header, ['Vendor', 'Vendor ID', 'Beginning Balance', 'Jan 2026 Net Change', 'Feb 2026 Net Change',
    'Bills & Charges (Credits)', 'Payments & Credits (Debits)', 'Ending Balance']);
  assert.deepEqual(sched.rows, [
    ['Acme', 'a', 1000, 60, 10, 110, 40, 1070],
    ['Beta', 'b', 0, 0, 5, 5, 0, 5],
    ['Total', '', 1000, 60, 15, 115, 40, 1075]
  ]); // "Zero" has no balance or activity and is dropped
  assert.deepEqual(sched.rowKinds, ['data', 'data', 'summary']);

  const long = plain(g.layoutRollForward_({ ...spec, layout: 'long', includeZero: true }));
  assert.deepEqual(long.header, ['Vendor', 'Vendor ID', 'Period', 'Period Start', 'Period End', 'Beginning Balance',
    'Bills & Charges (Credits)', 'Payments & Credits (Debits)', 'Net Change', 'Ending Balance']);
  assert.equal(long.rows.length, 6);
  assert.deepEqual(long.rows[1], ['Acme', 'a', 'Feb 2026', '2026-02-01', '2026-02-28', 1060, 10, 0, 10, 1070]);
});

// --- End to end with a mocked QuickBooks API ---------------------------------

function mockQbo(g, { accounts, names, gl, tb, nameBalances, calls }) {
  g.qboQueryAll_ = (realm, entity) => (entity === 'Account' ? accounts : names);
  g.qboGet_ = () => ({ Preferences: { CurrencyPrefs: { MultiCurrencyEnabled: false } } });
  g.qboReport_ = (realm, name, params) => {
    calls.push([name, plain(params)]);
    if (name === 'GeneralLedger') return gl(params);
    if (name === 'TrialBalance') return tb(params);
    return nameBalances(params);
  };
}

test('vendor (A/P) roll forward from QuickBooks reports', () => {
  const g = load();
  const calls = [];
  mockQbo(g, {
    calls,
    accounts: [{ Id: '33', Name: 'Accounts Payable', AccountType: 'Accounts Payable', Classification: 'Liability' },
      { Id: '35', Name: 'Checking', AccountType: 'Bank', Classification: 'Asset' }],
    names: [{ Id: '7', DisplayName: 'Acme Supplies' }, { Id: '8', DisplayName: 'Brightline' }],
    nameBalances: (p) => nameBalanceReport(p.report_date === '2025-12-31' ? [['7', 'Acme Supplies', 500]] : [['7', 'Acme Supplies', 200], ['8', 'Brightline', 900]]),
    gl: (p) => glReport([{ id: '33', name: 'Accounts Payable', lines: p.start_date === '2026-01-01'
      ? [['2026-01-04', 'Acme Supplies', '7', 0, 1000], ['2026-01-20', 'Acme Supplies', '7', 1300, 0]]
      : [['2026-02-02', 'Brightline', '8', 0, 900]] }]),
    tb: () => { throw new Error('not used'); }
  });
  const pull = { realmId: '1', rollforwardBy: 'vendor', period: 'Month', layout: 'schedule', filters: {} };
  const out = plain(g.buildRollForward_(pull, { start: '2026-01-01', end: '2026-02-28' }, { companyName: 'Acme Inc', fiscalStartMonth: 1 }));

  // GL is limited to A/P accounts and always accrual.
  const glCall = calls.find((c) => c[0] === 'GeneralLedger')[1];
  assert.equal(glCall.account, '33');
  assert.equal(glCall.accounting_method, 'Accrual');
  assert.equal(glCall.columns, 'tx_date,name,debt_amt,credit_amt');
  assert.deepEqual(out.rows, [
    ['Acme Supplies', '7', 500, -300, 0, 1000, 1300, 200],
    ['Brightline', '8', 0, 0, 900, 900, 0, 900],
    ['Total', '', 500, -300, 900, 1900, 1300, 1100]
  ]);
  assert.equal(out.warning, '');
  assert.equal(out.title[0], 'Accounts Payable Roll Forward by Vendor');
});

test('GL account roll forward reports differences from QuickBooks', () => {
  const g = load();
  const calls = [];
  mockQbo(g, {
    calls,
    accounts: [{ Id: '35', Name: 'Checking', AcctNum: '1000', AccountType: 'Bank', Classification: 'Asset' },
      { Id: '45', Name: 'Services', AcctNum: '4000', AccountType: 'Income', Classification: 'Revenue' },
      { Id: '30', Name: 'Retained Earnings', AccountType: 'Equity', AccountSubType: 'RetainedEarnings', Classification: 'Equity' }],
    names: [],
    nameBalances: () => { throw new Error('not used'); },
    // Header without ids exercises the name fallback ("1000 Checking").
    gl: () => {
      const r = glReport([{ id: '', name: '1000 Checking', lines: [['2026-01-05', 'Client', '3', 250, 0]] },
        { id: '45', name: '4000 Services', lines: [['2026-01-05', 'Client', '3', 0, 250]] }]);
      delete r.Rows.Row[0].Header.ColData[0].id;
      return r;
    },
    tb: (p) => (p.end_date === '2025-12-31'
      ? tbReport({ 35: ['1000 Checking', 5000], 45: ['4000 Services', -5000] })
      : tbReport({ 35: ['1000 Checking', 5250], 45: ['4000 Services', -250], 30: ['Retained Earnings', -4000] }))
  });
  const pull = { realmId: '1', rollforwardBy: 'account', period: 'Total', layout: 'schedule', accountingMethod: 'Accrual', filters: {} };
  const out = plain(g.buildRollForward_(pull, { start: '2026-01-01', end: '2026-01-31' }, { companyName: 'Acme Inc', fiscalStartMonth: 1 }));
  const tbCalls = calls.filter((c) => c[0] === 'TrialBalance').map((c) => c[1]);
  assert.deepEqual(tbCalls[0], { start_date: '2025-01-01', end_date: '2025-12-31', accounting_method: 'Accrual' });
  assert.deepEqual(out.header, ['Account Number', 'Account', 'Account Type', 'Account ID', 'Beginning Balance', 'Year-end Close', 'Debits', 'Credits', 'Ending Balance']);
  assert.deepEqual(out.rows, [
    ['1000', 'Checking', 'Bank', '35', 5000, 0, 250, 0, 5250],
    ['4000', 'Services', 'Income', '45', -5000, 5000, 0, 250, -250],
    ['', 'Retained Earnings', 'Equity', '30', 0, -5000, 0, 0, -5000],
    ['Total', '', '', '', 0, 0, 250, 250, 0]
  ]);
  // QuickBooks says Retained Earnings is -4000 (e.g. a prior-period adjustment), so it is flagged.
  assert.match(out.warning, /Retained Earnings: roll forward -5000.00 vs QuickBooks -4000.00/);
});

test('pull validation for roll forwards', () => {
  const g = load();
  const base = { realmId: '1', source: 'rollforward', rollforwardBy: 'bank', dateRange: { preset: 'last_quarter' }, sheetName: 'Bank RF',
    filters: { bankAccount: ['35'], class: ['1'] } };
  const p = plain(g.normalizePull_(base));
  assert.equal(p.layout, 'schedule');
  assert.equal(p.period, 'Month');
  assert.deepEqual(p.filters, { bankAccount: ['35'] });
  assert.equal(p.name, 'Roll forward by Bank & credit card account - Last quarter (Accrual)');
  assert.equal(plain(g.normalizePull_({ ...base, rollforwardBy: 'vendor', accountingMethod: 'Cash' })).accountingMethod, 'Cash');
  assert.throws(() => g.normalizePull_({ ...base, dateRange: { preset: 'all_dates' } }), /start date/);
  assert.throws(() => g.normalizePull_({ ...base, rollforwardBy: 'class' }), /roll forward by/);
});

test('vendor cash view: cash paid from bank and card accounts, fiscal YTD', () => {
  const g = load();
  const calls = [];
  mockQbo(g, {
    calls,
    accounts: [{ Id: '33', Name: 'Accounts Payable', AccountType: 'Accounts Payable', Classification: 'Liability' },
      { Id: '35', Name: 'Checking', AccountType: 'Bank', Classification: 'Asset' },
      { Id: '41', Name: 'Amex', AccountType: 'Credit Card', Classification: 'Liability' }],
    names: [{ Id: '7', DisplayName: 'Acme Supplies' }],
    nameBalances: () => { throw new Error('cash view must not use A/P balances'); },
    gl: (p) => {
      const col = GL_COLUMNS.map((c) => (c.MetaData[0].Value === 'name' ? { ...c, MetaData: [{ Name: 'ColKey', Value: 'vend_name' }] } : c));
      const lines = {
        '2026-01-01': [['2026-01-10', 'Acme Supplies', '', 0, 100]],                     // YTD before start
        '2026-03-01': [['2026-03-05', 'Acme Supplies', '', 0, 400], ['2026-03-06', '', '', 0, 25]], // fee: no vendor
        '2026-04-01': [['2026-04-09', 'Acme Supplies', '', 30, 0]]                       // refund
      }[p.start_date];
      const r = glReport([{ id: '35', name: 'Checking', lines }]);
      r.Columns.Column = col;
      return r;
    },
    tb: () => { throw new Error('not used'); }
  });
  const pull = { realmId: '1', rollforwardBy: 'vendor', accountingMethod: 'Cash', period: 'Month', layout: 'long', filters: {} };
  const out = plain(g.buildRollForward_(pull, { start: '2026-03-01', end: '2026-04-30' }, { companyName: 'Acme Inc', fiscalStartMonth: 1 }));

  const gl = calls.filter((c) => c[0] === 'GeneralLedger').map((c) => c[1]);
  assert.deepEqual(gl.map((p) => [p.start_date, p.end_date]), [['2026-03-01', '2026-03-31'], ['2026-04-01', '2026-04-30'], ['2026-01-01', '2026-02-28']]);
  assert.ok(gl.every((p) => p.account === '35,41' && p.accounting_method === 'Cash' && p.columns === 'tx_date,vend_name,debt_amt,credit_amt'));
  assert.deepEqual(out.header, ['Vendor', 'Vendor ID', 'Period', 'Period Start', 'Period End', 'Paid Fiscal YTD (Beginning)',
    'Cash Paid', 'Refunds Received', 'Net Change', 'Paid Fiscal YTD (Ending)']);
  assert.deepEqual(out.rows, [
    ['Acme Supplies', '7', 'Mar 2026', '2026-03-01', '2026-03-31', 100, 400, 0, 400, 500],
    ['Acme Supplies', '7', 'Apr 2026', '2026-04-01', '2026-04-30', 500, 0, 30, -30, 470]
  ]);
  assert.equal(out.title[0], 'Cash Paid by Vendor');
  assert.match(out.title[3], /^Cash basis/);
  assert.equal(out.warning, '');
});

test('customer cash view resets at fiscal year start', () => {
  const g = load();
  const calls = [];
  mockQbo(g, {
    calls,
    accounts: [{ Id: '35', Name: 'Checking', AccountType: 'Bank', Classification: 'Asset' }],
    names: [{ Id: '3', DisplayName: 'Client Co' }],
    nameBalances: () => { throw new Error('not used'); },
    gl: (p) => glReport([{ id: '35', name: 'Checking', lines: {
      '2026-06-01': [['2026-06-10', 'Client Co', '3', 800, 0]],
      '2026-07-01': [['2026-07-10', 'Client Co', '3', 200, 0]],
      '2025-07-01': [['2025-08-10', 'Client Co', '3', 1000, 0]]
    }[p.start_date] }])
  });
  const pull = { realmId: '1', rollforwardBy: 'customer', accountingMethod: 'Cash', period: 'Month', layout: 'schedule', filters: {} };
  const out = plain(g.buildRollForward_(pull, { start: '2026-06-01', end: '2026-07-31' }, { companyName: 'Acme Inc', fiscalStartMonth: 7 }));
  assert.deepEqual(out.header, ['Customer', 'Customer ID', 'Received Fiscal YTD (Beginning)', 'Year-end Close',
    'Jun 2026 Net Change', 'Jul 2026 Net Change', 'Cash Received', 'Refunds Paid', 'Received Fiscal YTD (Ending)']);
  // 1000 received earlier in FY2026 + 800 in June, then the new fiscal year starts in July.
  assert.deepEqual(out.rows[0], ['Client Co', '3', 1000, -1800, 800, 200, 1000, 0, 200]);
});
