const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));
const col = (key, title, type) => ({ ColTitle: title, ColType: type || 'Money', MetaData: [{ Name: 'ColKey', Value: key }] });
const cell = (value, id) => (id ? { value, id } : { value });

const ACCOUNTS = [
  { Id: '530', AcctNum: '5300', Name: 'Events COGS', AccountType: 'Cost of Goods Sold', Classification: 'Expense' },
  { Id: '604', AcctNum: '6400', Name: 'Demand Generation / Paid Media', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '718', AcctNum: '7820', Name: 'Collaboration & Productivity Tools', AccountType: 'Expense', Classification: 'Expense' },
  { Id: '35', AcctNum: '1010', Name: 'Checking', AccountType: 'Bank', Classification: 'Asset' }
];

/** GL report with [accountId, name, [[date, type, vendor, debit, credit]]] sections. */
function gl(sections) {
  return {
    Header: { ReportName: 'GeneralLedger' },
    Columns: { Column: [col('tx_date', 'Date', 'Date'), col('txn_type', 'Type', 'String'), col('name', 'Name', 'String'), col('debt_amt', 'Debit'), col('credit_amt', 'Credit')] },
    Rows: { Row: sections.map(([id, name, lines]) => ({
      Header: { ColData: [cell(name, id), cell(''), cell(''), cell(''), cell('')] },
      Rows: { Row: lines.map(([d, t, v, dr, cr]) => ({ ColData: [cell(d), cell(t), cell(v), cell(dr ? dr.toFixed(2) : ''), cell(cr ? cr.toFixed(2) : '')], type: 'Data' })) },
      Summary: { ColData: [cell('Total'), cell(''), cell(''), cell(''), cell('')] }, type: 'Section'
    })) }
  };
}

const SEP = [['530', '5300 Events COGS', [['2026-09-03', 'Bill', 'Sample Caterer', 1200, 0], ['2026-09-30', 'Journal Entry', '', 500, 0]]],
  ['604', '6400 Demand Generation / Paid Media', [['2026-09-10', 'Expense', 'LinkedIn', 800, 0], ['2026-09-12', 'Expense', 'Google Ads', 300, 0]]],
  ['718', '7820 Collaboration & Productivity Tools', [['2026-09-01', 'Expense', 'Slack', 90, 0], ['2026-09-20', 'Credit Card Credit', 'Slack', 0, 10]]]];
const OCT = [['604', '6400 Demand Generation / Paid Media', [['2026-10-10', 'Expense', 'LinkedIn', 900, 0]]],
  ['718', '7820 Collaboration & Productivity Tools', [['2026-10-01', 'Expense', 'Slack', 90, 0]]]];

/** QuickBooks P&L by month for the same accounts, so the tie-out has something to check against. */
function pnl(values) {
  const month = (label, start, end) => ({ ColTitle: label, ColType: 'Money', MetaData: [{ Name: 'StartDate', Value: start }, { Name: 'EndDate', Value: end }] });
  return {
    Header: { ReportName: 'ProfitAndLoss' },
    Columns: { Column: [col('account', '', 'Account'), month('Sep 2026', '2026-09-01', '2026-09-30'), month('Oct 2026', '2026-10-01', '2026-10-31'), col('total', 'Total')] },
    Rows: { Row: Object.entries(values).map(([id, [sep, oct]]) => ({
      ColData: [cell('acct', id), cell(sep.toFixed(2)), cell(oct.toFixed(2)), cell((sep + oct).toFixed(2))], type: 'Data' })) }
  };
}
const PNL_MATCHING = { 530: [1700, 0], 604: [1100, 900], 718: [80, 90] };

function run(g, pull, groupRows, pnlValues) {
  const calls = [], companions = [];
  g.qboQueryAll_ = () => ACCOUNTS;
  g.qboGet_ = () => ({ Preferences: { CurrencyPrefs: { MultiCurrencyEnabled: false } } });
  g.qboReport_ = (realm, name, params) => {
    calls.push(Object.assign({ report: name }, plain(params)));
    if (name === 'ProfitAndLoss') return pnl(pnlValues || PNL_MATCHING);
    return gl(params.start_date === '2026-09-01' ? SEP : OCT);
  };
  g.syncAccountGroups_ = () => g.buildGroupLookup_(groupRows);
  g.loadVendorContext_ = () => ({ aliases: [], vendors: [], mentions: [] });
  g.writeActualsCompanions_ = (...a) => companions.push(plain(a));
  const out = plain(g.buildActuals_(Object.assign({ realmId: '1', period: 'Month', layout: 'schedule', filters: {} }, pull),
    { start: '2026-09-01', end: '2026-10-31' }, { companyName: 'Sample Company Inc.', fiscalStartMonth: 1 }));
  return { out, calls, companions };
}

const SAMPLE_GROUPS = [['5300', '', 'COGS', ''], ['6400', '', 'Sales & Marketing', ''], ['7820', '', 'G&A', '']];

test('grouped by GL group, account and vendor with months across and totals', () => {
  const g = load();
  const { out, calls, companions } = run(g, { accountingMethod: 'Accrual', sheetName: 'GL actuals' }, SAMPLE_GROUPS);
  assert.equal(calls[0].account, '530,604,718', 'only expense accounts are requested');
  assert.equal(calls[0].accounting_method, 'Accrual');
  assert.equal(calls[0].columns, 'tx_date,txn_type,doc_num,name,memo,debt_amt,credit_amt');
  assert.deepEqual(calls[calls.length - 1], { report: 'ProfitAndLoss', start_date: '2026-09-01', end_date: '2026-10-31', accounting_method: 'Accrual', summarize_column_by: 'Month' });
  assert.equal(companions[0][0], 'GL actuals');
  assert.equal(companions[0][1].totalAbsDiff, 0, 'tie-out passes');
  assert.equal(out.warning, '');
  assert.deepEqual(out.header, ['GL Group', 'GL Account', 'Vendor', 'Sep 2026', 'Oct 2026', 'Total']);
  assert.deepEqual(out.rows, [
    ['COGS', '', '', '', '', ''],
    ['', '5300 Events COGS', 'Sample Caterer', 1200, 0, 1200],
    ['', '', 'Unresolved JE', 500, 0, 500],
    ['', 'Total 5300 Events COGS', '', 1700, 0, 1700],
    ['Total COGS', '', '', 1700, 0, 1700],
    ['Sales & Marketing', '', '', '', '', ''],
    ['', '6400 Demand Generation / Paid Media', 'Google Ads', 300, 0, 300],
    ['', '', 'LinkedIn', 800, 900, 1700],
    ['', 'Total 6400 Demand Generation / Paid Media', '', 1100, 900, 2000],
    ['Total Sales & Marketing', '', '', 1100, 900, 2000],
    ['G&A', '', '', '', '', ''],
    ['', '7820 Collaboration & Productivity Tools', 'Slack', 80, 90, 170],
    ['', 'Total 7820 Collaboration & Productivity Tools', '', 80, 90, 170],
    ['Total G&A', '', '', 80, 90, 170],
    ['Grand total', '', '', 2880, 990, 3870],
    ['Check vs QuickBooks P&L (should be 0)', '', '', 0, 0, 0]
  ]);
  assert.equal(out.rowKinds[0], 'header');
  assert.equal(out.rowKinds[3], 'subtotal');
  assert.equal(out.rowKinds[14], 'summary');
  assert.equal(out.rowKinds[15], 'subtotal');
});

test('spend view leaves out journal entries; accounts only, no vendors', () => {
  const g = load();
  const { out } = run(g, { accountingMethod: 'Accrual', excludeJournalEntries: true, byVendor: false }, SAMPLE_GROUPS);
  assert.deepEqual(out.header, ['GL Group', 'GL Account', 'Sep 2026', 'Oct 2026', 'Total']);
  assert.deepEqual(out.rows.filter((r, i) => out.rowKinds[i] !== 'header'), [
    ['', '5300 Events COGS', 1200, 0, 1200],
    ['Total COGS', '', 1200, 0, 1200],
    ['', '6400 Demand Generation / Paid Media', 1100, 900, 2000],
    ['Total Sales & Marketing', '', 1100, 900, 2000],
    ['', '7820 Collaboration & Productivity Tools', 80, 90, 170],
    ['Total G&A', '', 80, 90, 170],
    ['Grand total', '', 2380, 990, 3370]
  ]);
  assert.match(out.title[3], /journal entries left out/);
});

test('unmapped accounts fall back to Ungrouped, last; long layout skips zeros', () => {
  const g = load();
  const { out } = run(g, { accountingMethod: 'Cash', layout: 'long' }, [['6400', '', 'Sales & Marketing', '']]);
  assert.deepEqual(out.header, ['GL Group', 'Account Number', 'GL Account', 'Account ID', 'Vendor', 'Period', 'Period Start', 'Period End', 'Amount']);
  assert.deepEqual(out.rows[0], ['Sales & Marketing', '6400', 'Demand Generation / Paid Media', '604', 'Google Ads', 'Sep 2026', '2026-09-01', '2026-09-30', 300]);
  assert.equal(out.rows[out.rows.length - 1][0], 'Ungrouped');
  assert.ok(out.rows.every((r) => r[8] !== 0));
});

test('group lookup matches by id, account number or name; default groups', () => {
  const g = load();
  const lookup = g.buildGroupLookup_([['', '', 'Ignored (no group)', ''], ['', '5300 Events COGS', 'COGS', ''], ['7820', 'x', 'G&A', ''], ['', '', 'R&D', '604']]);
  assert.deepEqual(plain(lookup.order), ['COGS', 'G&A', 'R&D']);
  assert.equal(g.groupFor_(lookup, ACCOUNTS[0]), 'COGS');
  assert.equal(g.groupFor_(lookup, ACCOUNTS[2]), 'G&A');
  assert.equal(g.groupFor_(lookup, ACCOUNTS[1]), 'R&D');
  assert.equal(g.groupFor_(lookup, ACCOUNTS[3]), '');
  assert.equal(g.defaultGroup_(ACCOUNTS[0]), 'COGS');
  assert.equal(g.defaultGroup_(ACCOUNTS[1]), 'Operating Expenses');
});

test('pull options for GL actuals', () => {
  const g = load();
  const p = plain(g.normalizePull_({ realmId: '1', source: 'rollforward', rollforwardBy: 'actuals', dateRange: { preset: 'last_12_months' }, sheetName: 'GL actuals', filters: { account: ['604'], vendor: ['9'] } }));
  assert.equal(p.byVendor, true);
  assert.equal(p.excludeJournalEntries, false);
  assert.equal(p.accountingMethod, 'Accrual');
  assert.deepEqual(p.filters, { account: ['604'] });
  assert.equal(p.name, 'GL actuals by month - Last 12 full months (Accrual)');
});
