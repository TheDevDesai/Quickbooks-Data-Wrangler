const test = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load');

const plain = (x) => JSON.parse(JSON.stringify(x));

test('admin list parsing', () => {
  const g = load();
  assert.deepEqual(plain(g.parseAdminList_(' Dev@Example.com, ops@example.com;dev@example.com\nnot-an-email ')),
    ['dev@example.com', 'ops@example.com']);
  assert.deepEqual(plain(g.parseAdminList_('')), []);
  assert.deepEqual(plain(g.parseAdminList_(null)), []);
});

test('who can change the shared setup', () => {
  const g = load();
  const admins = ['dev@example.com'];
  assert.equal(g.canAdminister_([], false, 'anyone@example.com'), true, 'anyone can do the first setup');
  assert.equal(g.canAdminister_([], true, ''), true, 'older installs without admins stay editable');
  assert.equal(g.canAdminister_(admins, true, 'Dev@Example.com'), true);
  assert.equal(g.canAdminister_(admins, true, 'cfo@example.com'), false);
  assert.equal(g.canAdminister_(admins, true, ''), false, 'unknown user cannot change keys');
});
