// Loads the Apps Script sources into a Node VM context so the pure functions can be tested.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = path.join(__dirname, '..', 'src');
const FILES = ['Config.gs', 'Dates.gs', 'ReportParser.gs', 'EntityParser.gs', 'RollForward.gs', 'VendorResolver.gs', 'Actuals.gs', 'Consolidation.gs', 'Prepaid.gs', 'Pulls.gs', 'Auth.gs'];

module.exports = function load() {
  const context = vm.createContext({ console });
  for (const f of FILES) {
    vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8'), context, { filename: f });
  }
  return context;
};

module.exports.fixture = (name) =>
  JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', name), 'utf8'));
